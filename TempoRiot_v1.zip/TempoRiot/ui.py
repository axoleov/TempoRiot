"""Menu widgets and scenes."""
import math
import random

import pygame
from pygame import (K_BACKSPACE, K_DOWN, K_ESCAPE, K_KP_ENTER, K_LEFT, K_RETURN, K_RIGHT, K_SPACE, K_UP, K_a, K_d, K_j, K_k,
                    K_s, K_w, K_x, K_z)

import gfx
from core import *
from gfx import POSES, lerp_pose, draw_stick, blit_glow
from stages import STAGES, ABILITY_NAMES, ABILITY_UNLOCK

GOLD = (255, 214, 80)
CYAN = (60, 230, 255)
MAG = (255, 60, 190)


class MenuList:
    def __init__(self, app, items, x=W // 2, y=300, gap=56, size=34, align='center'):
        self.app, self.items, self.x, self.y, self.gap, self.size, self.align = app, items, x, y, gap, size, align
        self.sel = 0

    def _lab(self, it):
        l = it['label']() if callable(it['label']) else it['label']
        if 'get' in it and 'opts' in it:
            return f"{l}   < {it['opts'][it['get']()]} >"
        if 'get' in it:
            v = it['get']()
            return f"{l}   < {it.get('fmt', '{}').format(v)} >"
        return l

    def event(self, ev):
        if ev.type != pygame.KEYDOWN:
            return None
        k = ev.key
        a = self.app
        it = self.items[self.sel]
        if k in (K_UP, K_w):
            self.sel = (self.sel - 1) % len(self.items)
            a.audio.play('ui_move', .6)
        elif k in (K_DOWN, K_s):
            self.sel = (self.sel + 1) % len(self.items)
            a.audio.play('ui_move', .6)
        elif k in (K_LEFT, K_a, K_RIGHT, K_d):
            d = -1 if k in (K_LEFT, K_a) else 1
            self.adjust(it, d)
        elif k in (K_RETURN, K_KP_ENTER, K_SPACE, K_j, K_z):
            if it.get('enabled', True) is False:
                a.audio.play('ui_back', .6)
            elif 'fn' in it:
                a.audio.play('ui_ok', .8)
                it['fn']()
            elif 'get' in it:
                self.adjust(it, 1)
        elif k in (K_ESCAPE, K_BACKSPACE, K_k, K_x):
            a.audio.play('ui_back', .6)
            return 'back'
        return None

    def adjust(self, it, d):
        if 'get' not in it:
            return
        if 'opts' in it:
            it['set']((it['get']() + d) % len(it['opts']))
        else:
            v = it['get']() + d * it.get('step', 1)
            it['set'](type(it['get']())(clamp(v, it['min'], it['max'])) if isinstance(it['get'](), int) else round(clamp(v, it['min'], it['max']), 3))
        self.app.audio.play('ui_move', .6)

    def draw(self, s, now, phase):
        pulse = (1 - phase) ** 3
        for i, it in enumerate(self.items):
            y = self.y + i * self.gap
            sel = i == self.sel
            en = it.get('enabled', True) is not False
            col = WHITE_ if sel else (150, 150, 180)
            if not en:
                col = (80, 80, 100)
            lab = self._lab(it)
            sz = self.size + (int(4 * pulse) if sel else 0)
            if sel:
                r = gfx.text(s, lab, sz, GOLD if en else (120, 100, 60), (self.x, y), self.align if self.align != 'center' else 'center')
                pygame.draw.polygon(s, GOLD, [(r.left - 34, y), (r.left - 18, y - 9), (r.left - 18, y + 9)])
                pygame.draw.polygon(s, GOLD, [(r.right + 34, y), (r.right + 18, y - 9), (r.right + 18, y + 9)])
            else:
                gfx.text(s, lab, sz, col, (self.x, y), self.align if self.align != 'center' else 'center')
        it = self.items[self.sel]
        if it.get('desc'):
            gfx.text(s, it['desc'], 18, (170, 170, 200), (W // 2 + (300 if self.align != 'center' else 0), H - 30))


WHITE_ = (255, 255, 255)


class MenuBG:
    def __init__(self):
        self.bg = pygame.Surface((W, H))
        for y in range(H):
            self.bg.fill(mix((14, 6, 34), (60, 10, 70), (y / H) ** 1.4), (0, y, W, 1))
        self.fx = pygame.Surface((W, H))
        self.p = gfx.Particles()
        self.pose = dict(POSES['idle'])
        self.cycle = ['h_jab', 'h_cross', 'h_hook', 'h_kick', 'h_up', 'h_round', 'h_spin', 'h_axe']
        self.last = -1
        self.vig = gfx.make_vignette()

    def draw(self, s, audio, t, dancer=True, dancer_x=1000):
        ph = audio.phase()
        bf = audio.bf()
        s.blit(self.bg, (0, 0))
        fx = self.fx
        fx.fill((0, 0, 0))
        pulse = (1 - ph) ** 3
        cx, cy = 900, 340
        for i in range(5):
            r = 120 + i * 90 + pulse * 26
            pygame.draw.circle(fx, shade((255, 60, 190), .18 - i * .025 + .12 * pulse), (cx, cy), int(r), 3)
        for i in range(12):
            a = t * .3 + i * math.pi / 6
            pygame.draw.line(fx, shade((60, 230, 255), .10 + .1 * pulse), (cx, cy), (cx + math.cos(a) * 900, cy + math.sin(a) * 900), 2)
        for i in range(0, W, 80):
            pygame.draw.line(fx, shade((255, 60, 190), .15), (i, GROUND), (i * 1.6 - W * .3, H), 1)
        for i in range(1, 6):
            y = GROUND + int((H - GROUND) * (i / 6) ** 1.7)
            pygame.draw.line(fx, shade((255, 60, 190), .15), (0, y), (W, y), 1)
        pygame.draw.line(fx, shade((255, 60, 190), .6 + .4 * pulse), (0, GROUND), (W, GROUND), 2)
        bi = int(bf)
        if bi != self.last:
            self.last = bi
            self.tgt = POSES[self.cycle[bi % len(self.cycle)]]
            self.punch = 1.0
            self.p.burst(dancer_x + 40, GROUND - 90, (255, 214, 80), 8, 400, 0, 1.4, .4, 3)
        if random.random() < .3:
            self.p.add(random.uniform(0, W), H + 10, random.uniform(-20, 20), random.uniform(-120, -50), 4, (255, 60, 190), 4, 3)
        self.p.update(1 / 60)
        if dancer:
            tgt = self.tgt if hasattr(self, 'tgt') else POSES['idle']
            k = .5 if ph < .3 else .1
            self.pose = lerp_pose(self.pose, tgt if ph < .5 else POSES['idle'], .25)
            draw_stick(s, dancer_x, GROUND, -1, self.pose, CYAN, 1.6)
            blit_glow(fx, dancer_x, GROUND - 100, 140, shade(CYAN, .25 + .25 * pulse))
        self.p.draw(fx, 0)
        s.blit(fx, (0, 0), special_flags=pygame.BLEND_ADD)
        s.blit(self.vig, (0, 0))


class Scene:
    overlay = False

    def event(self, ev):
        pass

    def update(self, dt):
        pass

    def draw(self, s):
        pass


def logo(s, audio, x, y, size=96):
    ph = audio.phase()
    p = (1 - ph) ** 3
    gfx.text(s, 'TEMPO', size + int(6 * p), (255, 255, 255), (x, y), 'midleft', shadow=MAG, sh=5)
    gfx.text(s, 'RIOT', size + int(6 * p), GOLD, (x, y + size * .95), 'midleft', shadow=(160, 60, 20), sh=5)


class TitleScene(Scene):
    def __init__(self, app):
        self.app = app
        self.bg = MenuBG()
        self.t = 0

    def event(self, ev):
        if ev.type == pygame.KEYDOWN and ev.key != pygame.K_F11:
            self.app.audio.play('ui_ok')
            self.app.replace(MainMenu(self.app, self.bg))

    def update(self, dt):
        self.t += dt

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t)
        logo(s, self.app.audio, 90, 200, 120)
        gfx.text(s, 'FIGHT TO THE BEAT', 28, (200, 200, 240), (96, 440), 'midleft')
        a = 140 + 110 * math.sin(self.t * 4)
        gfx.text(s, 'PRESS ANY KEY', 30, GOLD, (96, 560), 'midleft', alpha=int(a))


class MainMenu(Scene):
    def __init__(self, app, bg=None):
        self.app = app
        self.bg = bg or MenuBG()
        self.t = 0
        sv = app.save
        u = lambda: sv.d['unlocked']
        items = [
            dict(label='CAMPAIGN', fn=self.campaign, desc='Fight through six stages and three bosses.'),
            dict(label='STAGE SELECT', fn=lambda: app.push(StageSelect(app, self.bg)), desc='Replay stages to chase better ranks.'),
            dict(label=lambda: 'GAUNTLET' if u() >= 4 else 'GAUNTLET  (CLEAR STAGE 3)', fn=lambda: self.start('gauntlet'), enabled=None, desc='Endless waves. How far can you groove?'),
            dict(label=lambda: 'BOSS RUSH' if u() >= 7 else 'BOSS RUSH  (CLEAR THE GAME)', fn=lambda: self.start('bossrush'), enabled=None, desc='All three bosses back to back.'),
            dict(label='UPGRADES', fn=lambda: app.push(UpgradeScene(app, self.bg)), desc='Spend Groove Points on permanent boosts.'),
            dict(label='DIFFICULTY', get=lambda: sv.s['difficulty'], set=lambda v: sv.s.__setitem__('difficulty', v), opts=[d['name'] for d in DIFFS],
                 desc='Chill: wide timing windows.  Hardcore: tight windows, more enemies.'),
            dict(label='STATS', fn=lambda: app.push(StatsScene(app, self.bg))),
            dict(label='CONTROLS', fn=lambda: app.push(ControlsScene(app, self.bg))),
            dict(label='SETTINGS', fn=lambda: app.push(SettingsScene(app, self.bg))),
            dict(label='QUIT', fn=app.quit),
        ]
        self.menu = MenuList(app, items, x=90, y=280, gap=41, size=28, align='midleft')
        for it in items:
            if it['label'] is not None and it.get('enabled', True) is None:
                it['enabled'] = True
        self.items = items

    def campaign(self):
        from game import Gameplay
        idx = min(self.app.save.d['unlocked'], 6) - 1
        self.app.audio.stop(200)
        self.app.replace(Gameplay(self.app, 'campaign', idx))

    def start(self, mode):
        u = self.app.save.d['unlocked']
        if (mode == 'gauntlet' and u < 4) or (mode == 'bossrush' and u < 7):
            return
        from game import Gameplay
        self.app.audio.stop(200)
        self.app.replace(Gameplay(self.app, mode, 0))

    def event(self, ev):
        self.menu.event(ev)

    def update(self, dt):
        self.t += dt
        u = self.app.save.d['unlocked']
        self.items[2]['enabled'] = u >= 4
        self.items[3]['enabled'] = u >= 7

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t)
        logo(s, self.app.audio, 90, 90, 70)
        self.menu.draw(s, self.t, self.app.audio.phase())
        sv = self.app.save.d
        gfx.text(s, f"GROOVE POINTS  {sv['points']}", 20, GOLD, (W - 40, 40), 'midright')


class StageSelect(Scene):
    def __init__(self, app, bg):
        self.app, self.bg, self.t = app, bg, 0
        items = []
        for st in STAGES:
            items.append(dict(label=(lambda st=st: self.lab(st)), fn=(lambda st=st: self.go(st)), enabled=None))
        items.append(dict(label='BACK', fn=lambda: app.pop()))
        self.menu = MenuList(app, items, x=W // 2, y=200, gap=64, size=32)
        self.upd()

    def lab(self, st):
        b = self.app.save.d['best'].get(str(st.idx))
        r = f"   [{b['rank']}  {b['score']:,}]" if b else ''
        u = self.app.save.d['unlocked']
        return f"{st.idx + 1}. {st.name}{r}" if st.idx < u else f"{st.idx + 1}. ???  LOCKED"

    def upd(self):
        u = self.app.save.d['unlocked']
        for i, st in enumerate(STAGES):
            self.menu.items[i]['enabled'] = st.idx < u

    def go(self, st):
        from game import Gameplay
        self.app.audio.stop(200)
        self.app.replace(Gameplay(self.app, 'select', st.idx))

    def event(self, ev):
        if self.menu.event(ev) == 'back':
            self.app.pop()

    def update(self, dt):
        self.t += dt
        self.upd()

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t, dancer=False)
        gfx.text(s, 'STAGE SELECT', 56, WHITE_, (W // 2, 90))
        self.menu.draw(s, self.t, self.app.audio.phase())
        i = self.menu.sel
        if i < len(STAGES):
            st = STAGES[i]
            gfx.text(s, f"{st.sub}   -   {[a for a in ['s1','s2','s3','s4','s5','s6']][i] and ''}", 18, (170, 170, 200), (W // 2, H - 50))


class UpgradeScene(Scene):
    def __init__(self, app, bg):
        self.app, self.bg, self.t = app, bg, 0
        items = []
        for k, n, d in UPGRADES:
            items.append(dict(label=(lambda k=k, n=n: self.lab(k, n)), fn=(lambda k=k: self.buy(k)), desc=d))
        items.append(dict(label='BACK', fn=lambda: app.pop()))
        self.menu = MenuList(app, items, y=230, gap=62, size=30)
        self.msg = ''

    def cost(self, k):
        return 3 + 2 * self.app.save.d['upgrades'][k]

    def lab(self, k, n):
        lv = self.app.save.d['upgrades'][k]
        pips = '#' * lv + '-' * (UPGRADE_MAX - lv)
        return f"{n}  [{pips}]   " + ('MAX' if lv >= UPGRADE_MAX else f"{self.cost(k)} PTS")

    def buy(self, k):
        sv = self.app.save.d
        lv = sv['upgrades'][k]
        if lv >= UPGRADE_MAX:
            self.msg = 'ALREADY MAXED'
            return
        c = self.cost(k)
        if sv['points'] < c:
            self.msg = 'NOT ENOUGH GROOVE POINTS'
            self.app.audio.play('ui_back')
            return
        sv['points'] -= c
        sv['upgrades'][k] += 1
        self.msg = 'UPGRADED!'
        self.app.audio.play('pickup')
        self.app.save.store()

    def event(self, ev):
        if self.menu.event(ev) == 'back':
            self.app.pop()

    def update(self, dt):
        self.t += dt

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t, dancer=False)
        gfx.text(s, 'UPGRADES', 56, WHITE_, (W // 2, 90))
        gfx.text(s, f"GROOVE POINTS: {self.app.save.d['points']}", 28, GOLD, (W // 2, 150))
        self.menu.draw(s, self.t, self.app.audio.phase())
        if self.msg:
            gfx.text(s, self.msg, 22, WHITE_, (W // 2, 620))


class StatsScene(Scene):
    def __init__(self, app, bg):
        self.app, self.bg, self.t = app, bg, 0

    def event(self, ev):
        if ev.type == pygame.KEYDOWN:
            self.app.audio.play('ui_back', .6)
            self.app.pop()

    def update(self, dt):
        self.t += dt

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t, dancer=False)
        d = self.app.save.d
        st = d['stats']
        gfx.text(s, 'STATISTICS', 56, WHITE_, (W // 2, 80))
        rows = [('PLAY TIME', f"{int(st['play_time'] // 3600)}h {int(st['play_time'] % 3600 // 60)}m"), ('HITS LANDED', f"{st['hits']:,}"),
                ('PERFECT-TIMED ACTIONS', f"{st['perfects']:,}"), ('KILLS', f"{st['kills']:,}"), ('PARRIES', f"{st['parries']:,}"),
                ('EVADES', f"{st['evades']:,}"), ('DEATHS', f"{st['deaths']:,}"), ('LONGEST COMBO', f"{st['max_combo']:,}"),
                ('STAGES CLEARED', f"{st['stages']:,}"), ('GAUNTLET BEST WAVE', f"{d['gauntlet']}"),
                ('BOSS RUSH BEST', f"{int(d['bossrush'] // 60)}:{int(d['bossrush'] % 60):02d}" if d['bossrush'] else '-')]
        for i, (a, b) in enumerate(rows):
            y = 150 + i * 38
            gfx.text(s, a, 22, (190, 190, 220), (360, y), 'midleft')
            gfx.text(s, b, 22, GOLD, (920, y), 'midright')
        y0 = 150 + len(rows) * 38 + 20
        for i, sg in enumerate(STAGES):
            b = d['best'].get(str(i))
            gfx.text(s, f"{i + 1}. {sg.name}", 18, (150, 150, 180), (360 + (i % 2) * 320, y0 + (i // 2) * 26), 'midleft')
            gfx.text(s, b['rank'] if b else '-', 18, GOLD if b else (90, 90, 110), (560 + (i % 2) * 320, y0 + (i // 2) * 26), 'midleft')
        gfx.text(s, 'PRESS ANY KEY', 18, (150, 150, 180), (W // 2, H - 40))


class ControlsScene(Scene):
    def __init__(self, app, bg):
        self.app, self.bg, self.t = app, bg, 0

    def event(self, ev):
        if ev.type == pygame.KEYDOWN:
            self.app.audio.play('ui_back', .6)
            self.app.pop()

    def update(self, dt):
        self.t += dt

    def draw(self, s):
        self.bg.draw(s, self.app.audio, self.t, dancer=False)
        gfx.text(s, 'CONTROLS', 56, WHITE_, (W // 2, 70))
        rows = [('MOVE', 'A / D   or   LEFT / RIGHT'), ('JUMP  (x2)', 'SPACE   -   DOWN + SPACE drops through platforms'),
                ('LIGHT ATTACK', 'J  or  Z    (chain up to 4 hits)'), ('HEAVY ATTACK', 'K  or  X    (chain into J for combos)'),
                ('LAUNCHER', 'W + J   then jump and juggle in the air'), ('SWEEP', 'S + K  (ground)'),
                ('DIVE KICK', 'S + K  (in air)'), ('DODGE', 'L  or  C   (i-frames; dodge attacks to EVADE)'),
                ('BLOCK / PARRY', 'HOLD I / V / SHIFT   -   TAP ON THE BEAT AS THE RING CLOSES'),
                ('DROP THE BASS', 'O  or  E  or  F   (when HEAT is full)'), ('PAUSE', 'ESC  or  P'), ('FULLSCREEN', 'F11')]
        for i, (a, b) in enumerate(rows):
            y = 130 + i * 38
            gfx.text(s, a, 22, GOLD, (150, y), 'midleft')
            gfx.text(s, b, 20, (220, 220, 240), (400, y), 'midleft')
        tips = ['TIMING: every action is judged against the beat. PERFECT = big damage, faster attacks, heat.',
                'Enemy attacks always land ON the beat. Watch the ring close - block or dodge as it does.',
                'WHITE ring = parryable.  RED ring = unblockable: dodge or jump.']
        for i, t in enumerate(tips):
            gfx.text(s, t, 18, (170, 220, 255), (W // 2, 610 + i * 26))
        gfx.text(s, 'PRESS ANY KEY', 16, (150, 150, 180), (W // 2, H - 18))


class SettingsScene(Scene):
    overlay = True

    def __init__(self, app, bg=None):
        self.app = app
        self.bg = bg
        self.t = 0
        sv = app.save.s

        def setter(k):
            def f(v):
                sv[k] = v
                app.audio.apply_volume()
            return f

        def tog(v):
            sv['fullscreen'] = bool(v)
            app.set_fullscreen(bool(v))

        items = [
            dict(label='MASTER VOLUME', get=lambda: sv['master'], set=setter('master'), min=0, max=1, step=.05, fmt='{:.0%}'),
            dict(label='MUSIC VOLUME', get=lambda: sv['music'], set=setter('music'), min=0, max=1, step=.05, fmt='{:.0%}'),
            dict(label='SFX VOLUME', get=lambda: sv['sfx'], set=setter('sfx'), min=0, max=1, step=.05, fmt='{:.0%}'),
            dict(label='SCREEN SHAKE', get=lambda: sv['shake'], set=setter('shake'), min=0, max=1.5, step=.25, fmt='{:.0%}'),
            dict(label='TIMING OFFSET', get=lambda: sv['offset'], set=setter('offset'), min=-200, max=200, step=5, fmt='{} ms',
                 desc='Audio latency compensation. If you feel you hit LATE, raise this. If EARLY, lower it.'),
            dict(label='FLASH EFFECTS', get=lambda: int(sv['flashes']), set=lambda v: sv.__setitem__('flashes', bool(v)), opts=['OFF', 'ON']),
            dict(label='FULLSCREEN', get=lambda: int(sv['fullscreen']), set=tog, opts=['OFF', 'ON']),
            dict(label='DIFFICULTY', get=lambda: sv['difficulty'], set=lambda v: sv.__setitem__('difficulty', v), opts=[d['name'] for d in DIFFS]),
            dict(label='BACK', fn=self.back),
        ]
        self.menu = MenuList(app, items, y=170, gap=54, size=28)

    def back(self):
        self.app.save.store()
        self.app.pop()

    def event(self, ev):
        if self.menu.event(ev) == 'back':
            self.back()

    def update(self, dt):
        self.t += dt

    def draw(self, s):
        if self.bg:
            self.bg.draw(s, self.app.audio, self.t, dancer=False)
        else:
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((6, 4, 20, 235))
            s.blit(ov, (0, 0))
        gfx.text(s, 'SETTINGS', 56, WHITE_, (W // 2, 80))
        self.menu.draw(s, self.t, self.app.audio.phase())
