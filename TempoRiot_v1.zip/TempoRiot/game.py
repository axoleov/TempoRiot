"""Gameplay scene: arena flow, combat orchestration, HUD, pause / game-over / results."""
import math
import random
import time

import pygame
from pygame import K_a, K_b, K_c, K_d, K_e, K_f, K_i, K_j, K_k, K_l, K_o, K_s, K_v, K_w, K_x, K_z
from pygame import K_DOWN, K_LEFT, K_RIGHT, K_UP, K_SPACE, K_LSHIFT, K_RSHIFT, K_ESCAPE, K_p, K_RETURN

import gfx
from core import *
from entities import Player, Enemy, ET, POINTS, Pickup, Projectile, Hazard, GOLD, WHITE, RED, CYAN, MAG
from bosses import BOSSES
from stages import STAGES, StageDef, Arena, Background, make_arena_state, ABILITY_UNLOCK, ABILITY_NAMES, ARENA_STEP, wv
import ui

KEYS = dict(
    light=(K_j, K_z), heavy=(K_k, K_x), dodge=(K_l, K_c), block=(K_i, K_v, K_LSHIFT, K_RSHIFT),
    special=(K_o, K_f, K_e), jump=(K_SPACE, K_b),
    left=(K_a, K_LEFT), right=(K_d, K_RIGHT), up=(K_w, K_UP), down=(K_s, K_DOWN),
)
PRESS = ('light', 'heavy', 'dodge', 'block', 'special', 'jump')
RANK_COL = {'S': (255, 214, 80), 'A': (120, 255, 160), 'B': (90, 200, 255), 'C': (200, 200, 220), 'D': (255, 100, 100)}


def gauntlet_stage():
    return StageDef(-1, 'GAUNTLET', 'Survive endless waves', 'club', 's4', [Arena(0, [], platforms=[(200, GROUND - 125, 220), (860, GROUND - 125, 220)],
                                                                                   hazards=[('vent', 640, dict(w=70, period=4, phase=0, active=.6, dmg=12, h=120))], props=[640])])


def bossrush_stage():
    return StageDef(-2, 'BOSS RUSH', 'Three bosses. No mercy.', 'stage', 's6', [
        Arena(0, boss='metronome', props=[160]), Arena(1, boss='dj', platforms=[(200, GROUND - 125, 200), (880, GROUND - 125, 200)]),
        Arena(2, boss='conductor', platforms=[(140, GROUND - 125, 220), (920, GROUND - 125, 220)])])


class Cam:
    x = 0.0
    zoom = 1.0


class Gameplay:
    overlay = False

    def __init__(self, app, mode='campaign', stage_idx=0):
        self.app = app
        self.save = app.save
        self.music = app.audio
        self.mode = mode
        self.diff = DIFFS[self.save.s['difficulty']]
        if mode == 'gauntlet':
            self.stage = gauntlet_stage()
        elif mode == 'bossrush':
            self.stage = bossrush_stage()
        else:
            self.stage = STAGES[stage_idx]
        self.stage_idx = stage_idx
        app.loading('GENERATING MUSIC...')
        self.music.prepare(self.stage.music)
        for a in self.stage.arenas:
            if a.boss:
                for tr in BOSSES[a.boss].tracks:
                    self.music.prepare(tr)
        self.bg = Background(self.stage.theme)
        self.vig = gfx.make_vignette()
        self.scene = pygame.Surface((W, H))
        self.fx = pygame.Surface((W, H))
        self.reset_run()

    # ------------------------------------------------------------ setup
    def reset_run(self):
        self.now = time.perf_counter()
        self.cam = Cam()
        self.particles = gfx.Particles()
        self.floaters = []
        self.enemies, self.projs, self.pickups = [], [], []
        self.platforms, self.hazards, self.props = [], [], []
        for a in self.stage.arenas:
            p, h, s = make_arena_state(self, self.stage, a)
            self.platforms += p
            self.hazards += h
            self.props += s
        self.bounds = (30, self.stage.width)
        self.player = Player(self, 120 if self.mode in ('campaign', 'select') else self.stage.arenas[0].x0 + 300)
        self.player.f = 1
        self.hp_scale = 1.0 + (self.stage.idx if self.stage.idx > 0 else 0) * .05
        self.stats = dict(hits=0, judged=0, perfect=0, good=0, off=0, parries=0, evades=0, dmg=0.0, kills=0, kills_total=0)
        self.score = 0
        self.combo = 0
        self.combo_t = 0.0
        self.max_combo = 0
        self.groove = 0
        self.time = 0.0
        self.continues = 0
        self.shake_amt = 0.0
        self.flash_col = (255, 255, 255)
        self.flash_a = 0.0
        self.freeze_t = 0.0
        self.state = 'intro'
        self.state_t = 0.0
        self.tokens = {}
        self.arena_i = 0
        self.arena_state = 'walk'
        self.wave = 0
        self.spawn_q = []
        self.wave_gap = 0.0
        self.boss = None
        self.boss_dead_t = 0.0
        self.hint_i = 0
        self.hint_t = 0.0
        self.hint_on = False
        self.banner = None
        self.last_judge = ('good', 0.0, 0.0)
        self.judge_show = None
        self.snap = None
        self.kp = pygame.key.get_pressed()
        self.pause_menu = None
        self.dead_menu = None
        self.gwave = 0
        self.end_t = 0.0
        self.beat_prev = 0
        self.music.start(self.stage.music)
        self.max_m = 1
        self.max_r = 1
        self.set_tokens()
        self.hints_enabled = self.stage.idx in (0, 1) and str(self.stage.idx) not in self.save.d['best']
        self.bosstrack = None

    def set_tokens(self):
        s = max(self.stage.idx, 0) if self.mode != 'gauntlet' else self.gwave // 4
        self.max_m = int(clamp([1, 1, 2, 2, 3, 3, 3][min(s, 6)] + self.diff['tok'], 1, 4))
        self.max_r = int(clamp(1 + (1 if s >= 3 else 0) + (1 if self.diff['tok'] > 0 else 0), 1, 3))

    # ------------------------------------------------------------ helpers used by entities
    def held(self, name):
        return any(self.kp[k] for k in KEYS[name])

    def held_dir(self):
        return (1 if self.held('right') else 0) - (1 if self.held('left') else 0)

    def win(self):
        m = self.diff['win'] * (1 + .08 * self.save.d['upgrades']['syn'])
        return .06 * m, .12 * m

    def unlocked(self, ab):
        if self.mode in ('gauntlet', 'bossrush'):
            return True
        return self.save.d['unlocked'] >= ABILITY_UNLOCK[ab] or self.mode == 'select' and self.save.d['unlocked'] >= ABILITY_UNLOCK[ab]

    def sfx(self, name, vol=1.0):
        self.music.play(name, vol)

    def shake(self, a):
        self.shake_amt = min(26, max(self.shake_amt, a * self.save.s['shake']))

    def flash(self, col, a):
        if self.save.s['flashes']:
            self.flash_col = col
            self.flash_a = max(self.flash_a, a)

    def zoom_punch(self, a):
        self.cam.zoom = min(1.12, self.cam.zoom + a)

    def freeze(self, t):
        self.freeze_t = max(self.freeze_t, t)

    def popup(self, txt, x, y, col, size=24, vy=-60):
        if len(self.floaters) > 14:
            self.floaters.pop(0)
        self.floaters.append([txt, x + random.uniform(-6, 6), y, col, size, vy, .8, .8])

    def score_add(self, pts, x=None, y=None):
        m = self.mult()
        v = int(pts * m * self.diff['pts'])
        self.score += v
        if x is not None:
            self.popup(f'+{v}', x, y, (255, 240, 200), 16, -40)

    def mult(self):
        return 1 + min(self.groove // 3, 7)

    def rhythm(self, grade, x, y, kind):
        st = self.stats
        st['judged'] += 1
        st[grade] += 1
        self.save.d['stats']['perfects'] += 1 if grade == 'perfect' else 0
        if grade == 'off':
            if self.groove >= 6:
                self.popup('GROOVE LOST', x, y - 30, (160, 160, 180), 18)
            self.groove = 0
        else:
            self.groove += 2 if grade == 'perfect' else 1
        if kind in ('atk', 'dodge'):
            label, col, sz = {'perfect': ('PERFECT', GOLD, 26), 'good': ('GOOD', CYAN, 20), 'off': ('OFF', (150, 150, 170), 18)}[grade]
            self.popup(label, x, y, col, sz, vy=-50)
        self.judge_show = (grade, self.last_judge[1], self.now)
        if grade == 'perfect':
            self.flash(GOLD, 14)

    def hit_fx(self, x, y, ang, heavy, perfect, col):
        p = self.particles
        n = 14 if heavy else 8
        p.burst(x, y, col, n + (8 if perfect else 0), 620 if heavy else 440, ang, 1.6, .4, 3)
        p.ring(x, y, col, 8, 70 if heavy else 46, .25, 3)
        p.glow(x, y, col, 90 if heavy else 60, .15)
        if perfect:
            p.ring(x, y, WHITE, 6, 110, .3, 4)
            for i in range(6):
                a = i * math.pi / 3
                p.spark(x, y, a, 700, GOLD, .3, 3, 0)

    def register_hit(self, killed, grade, dmg, x, y):
        self.combo += 1
        self.combo_t = 2.4
        self.max_combo = max(self.max_combo, self.combo)
        self.stats['hits'] += 1
        self.save.d['stats']['hits'] += 1
        pts = dmg * 10 * (1 + self.combo * .03)
        self.score_add(pts)
        if self.combo in (10, 25, 50, 100, 150):
            self.popup(f'{self.combo} HIT COMBO!', self.player.x, self.player.y - 190, GOLD, 34)
            self.sfx('ping3')
            self.particles.ring(self.player.x, self.player.y - 60, GOLD, 10, 160, .4, 4)
        elif self.combo % 5 == 0:
            self.sfx(f'ping{min(3, self.combo // 10)}', .5)

    def combo_break_soft(self):
        pass

    def hurt_fx(self, pl, d):
        self.sfx('hurt')
        self.shake(10)
        self.flash(RED, 90)
        self.combo = 0
        self.groove = 0
        self.stats['dmg'] += d
        self.particles.burst(pl.x, pl.y - 70, (255, 80, 90), 16, 500)
        self.particles.ring(pl.x, pl.y - 70, RED, 8, 80, .3, 4)
        self.popup(f'-{int(d)}', pl.x, pl.y - 130, RED, 26, -70)
        self.zoom_punch(.02)

    def player_died(self):
        self.state = 'dying'
        self.state_t = 0
        self.sfx('gameover')
        self.save.d['stats']['deaths'] += 1
        self.flash(RED, 140)
        self.music.stop(1200)

    def do_special(self, pl):
        mult = 1.5 if getattr(pl, 'special_grade', 'good') == 'perfect' else 1.0
        self.sfx('drop')
        self.flash(WHITE, 200)
        self.shake(22)
        self.zoom_punch(.06)
        for r in (100, 220, 380, 560):
            self.particles.ring(pl.x, pl.y - 40, GOLD if r % 2 else WHITE, 10, r, .5 + r / 900, 8)
        self.particles.burst(pl.x, pl.y - 40, GOLD, 60, 900)
        for e in list(self.enemies):
            if e.state in ('dead', 'spawn') or abs(e.x - pl.x) > 800:
                continue
            h = dict(dmg=45 * mult * (.3 if e.is_boss else 1), kb=(sign(e.x - pl.x or 1) * 500, -520), stun=1.6, kind='heavy', gb=True,
                     launch=True, down=False, poise=999, grade='good', perfect=False, counter=False, from_x=pl.x, f=1, reflected=True)
            res = e.receive(self, h)
            if res != 'miss':
                e.popup_dmg(self, h['dmg'], True)
                self.register_hit(res == 'dead', 'good', h['dmg'], e.x, e.y - 70)
        for p in self.projs:
            if not p.friendly:
                p.dead = True

    def shockwave(self, x, y, r, dmg, src):
        self.particles.ring(x, y - 4, WHITE, 10, r, .35, 6)
        self.particles.burst(x, y - 4, GOLD, 24, 600, -math.pi / 2, math.pi, .5)
        for e in self.enemies:
            if e.state not in ('dead', 'spawn') and abs(e.x - x) < r and e.y > GROUND - 60:
                h = dict(dmg=dmg, kb=(sign(e.x - x or 1) * 300, -520), stun=.9, kind='heavy', gb=True, launch=True, down=False,
                         poise=99, grade='good', perfect=False, counter=False, from_x=x, f=1)
                res = e.receive(self, h)
                if res != 'miss':
                    self.register_hit(res == 'dead', 'good', dmg, e.x, e.y - 60)
                    e.popup_dmg(self, dmg, False)

    def slowfreeze(self, src):
        self.flash((120, 255, 220), 60)
        for e in self.enemies:
            if e.is_boss or e.state in ('dead', 'spawn', 'air', 'down'):
                continue
            if abs(e.x - self.player.x) < 380:
                e.release(self)
                e.plan = None
                e.charge_end = 0
                e.armor_plan = False
                e.state = 'stagger'
                e.st = .8
                e.vx = 0

    def enemy_killed(self, e):
        self.stats['kills'] += 1
        self.save.d['stats']['kills'] += 1
        pts = 5000 if e.is_boss else POINTS.get(e.code, 100)
        self.score_add(pts, e.x, e.y - 150)
        col = e.col
        self.particles.burst(e.x, e.y - 60, col, 30, 700)
        self.particles.ring(e.x, e.y - 60, col, 10, 130, .4, 5)
        self.particles.glow(e.x, e.y - 60, col, 160, .3)
        self.sfx('bossdie' if e.is_boss else 'die')
        self.shake(14 if e.is_boss else 8)
        self.zoom_punch(.03)
        self.flash(WHITE, 60)
        if not e.is_boss:
            r = random.random()
            if r < .13:
                self.pickups.append(Pickup(e.x, e.y - 60, 'hp'))
            elif r < .26:
                self.pickups.append(Pickup(e.x, e.y - 60, 'heat'))
        else:
            self.boss_dead_t = 3.6
            self.state_t = 0
            self.freeze(.55)
            for o in self.enemies:
                if o is not e and o.state not in ('dead',):
                    o.hp = 0
                    o.die(self, dict(kb=(0, 0), from_x=o.x))
            self.projs = [p for p in self.projs if False]
            self.hazards = [h for h in self.hazards if not getattr(h, 'boss', False)]
            self.music.stop(1500)

    def request_token(self, e):
        pool = 'r' if e.cfg.get('ranged') else 'm'
        cap = self.max_r if pool == 'r' else self.max_m
        if e in self.tokens:
            return True
        if sum(1 for v in self.tokens.values() if v == pool) < cap:
            self.tokens[e] = pool
            return True
        return False

    def release_token(self, e):
        self.tokens.pop(e, None)

    def spawn_enemy(self, code, x, boss=False):
        e = BOSSES[code](self, x) if boss else Enemy(self, code, x)
        self.enemies.append(e)
        self.sfx('spawn', .5)
        self.particles.ring(x, GROUND - 4, e.col, 10, 70, .4, 3)
        return e

    def boss_phase(self, b):
        self.sfx('crash', .7)
        self.flash(WHITE, 120)
        self.shake(16)
        self.zoom_punch(.05)
        self.popup(f'PHASE {b.phase + 1}', b.x, b.y - 240, GOLD, 34)
        tr = b.tracks[min(b.phase, len(b.tracks) - 1)]
        self.music.start(tr)
        for e in self.enemies:
            if e is not b and e.state == 'attack':
                e.plan = None
                e.charge_end = 0
                e.armor_plan = False
                e.state = 'idle'
                e.release(self)
        for p in self.projs:
            if not p.friendly:
                p.dead = True

    def set_boss_lasers(self, phase):
        self.hazards = [h for h in self.hazards if not getattr(h, 'boss', False)]
        a = self.stage.arenas[self.arena_i]
        x0 = a.x0
        spec = [(x0 + 380, 4, 0), (x0 + 900, 4, 2)] if phase == 1 else [(x0 + 260, 2, 0), (x0 + 640, 2, 1), (x0 + 1020, 2, 0)]
        for x, per, ph in spec:
            h = Hazard('laser', x, w=46, period=per, phase=ph, active=.5, dmg=15)
            h.boss = True
            self.hazards.append(h)

    # ------------------------------------------------------------ flow
    def lock_arena(self):
        a = self.stage.arenas[self.arena_i]
        self.arena_state = 'fight'
        self.bounds = (a.x0 + 30, a.x0 + W - 30)
        self.wave = 0
        self.snap = (self.score, dict(self.stats), self.max_combo)
        self.hint_i, self.hint_t, self.hint_on = 0, 0, bool(a.hints) and self.hints_enabled
        if a.boss:
            self.start_boss(a)
        else:
            self.begin_wave()

    def start_boss(self, a):
        cls = BOSSES[a.boss]
        lo, hi = self.bounds
        self.music.start(cls.tracks[0])
        b = self.spawn_enemy(a.boss, hi - 200, boss=True)
        self.boss = b
        self.banner = (cls.name, cls.title, 0.0, 3.2)
        self.sfx('crash', .5)
        self.shake(8)
        self.player.x = clamp(self.player.x, lo + 60, lo + 400)

    def wave_list(self):
        a = self.stage.arenas[self.arena_i]
        if self.mode == 'gauntlet':
            return self.gen_wave(self.gwave)
        return a.waves[self.wave]

    def gen_wave(self, n):
        budget = 3 + n * 1.3
        types = ['g', 'r']
        if n >= 2:
            types += ['d', 's']
        if n >= 5:
            types += ['y', 'c']
        cost = dict(g=1, r=1.5, d=2, s=1.5, y=2, c=3, e=5)
        out = {}
        if n >= 4 and n % 4 == 0:
            out['e'] = 1 + n // 12
            budget -= 5
        while budget > 0:
            t = random.choice(types)
            out[t] = out.get(t, 0) + 1
            budget -= cost[t]
        return list(out.items())

    def begin_wave(self):
        self.spawn_q = []
        lst = self.wave_list()
        cmul = {'CHILL': .75, 'STANDARD': 1.0, 'HARDCORE': 1.25}[self.diff['name']]
        seq = []
        for code, n in lst:
            for _ in range(max(1, round(n * cmul)) if n > 1 else n):
                seq.append(code)
        random.shuffle(seq)
        t = .3
        for i, c in enumerate(seq):
            self.spawn_q.append([t, c, i % 2])
            t += random.uniform(.25, .7)
        self.wave_gap = 0
        self.banner = None
        if self.mode == 'gauntlet':
            self.gwave += 1
            self.set_tokens()
            self.hp_scale = 1 + self.gwave * .05
            self.banner = (f'WAVE {self.gwave}', '', 0.0, 1.6)

    def alive_enemies(self):
        return [e for e in self.enemies if e.state != 'dead']

    def update_arena(self, dt):
        a = self.stage.arenas[self.arena_i]
        pl = self.player
        if self.arena_state == 'walk':
            if pl.x >= a.x0 + 220:
                self.lock_arena()
        elif self.arena_state == 'fight':
            lo, hi = self.bounds
            for q in self.spawn_q:
                q[0] -= dt
            due = [q for q in self.spawn_q if q[0] <= 0]
            self.spawn_q = [q for q in self.spawn_q if q[0] > 0]
            for q in due:
                x = lo + 40 if q[2] == 0 else hi - 40
                if abs(pl.x - x) < 120:
                    x = hi - 40 if q[2] == 0 else lo + 40
                self.spawn_enemy(q[1], x)
            if not self.spawn_q and not self.alive_enemies() and not a.boss:
                self.wave_gap += dt
                if self.wave_gap > .9:
                    self.wave += 1
                    if self.mode == 'gauntlet':
                        self.begin_wave()
                    elif self.wave >= len(a.waves):
                        self.arena_clear()
                    else:
                        self.begin_wave()
            if a.boss and self.boss and self.boss.state == 'dead':
                self.boss_dead_t -= dt
                if self.boss_dead_t <= 0 and self.arena_state == 'fight':
                    self.arena_clear()
        elif self.arena_state == 'clear':
            pass

    def arena_clear(self):
        pl = self.player
        self.arena_state = 'clear'
        last = self.arena_i >= len(self.stage.arenas) - 1
        self.sfx('ping3')
        self.tokens.clear()
        self.hazards = [h for h in self.hazards if not getattr(h, 'boss', False)]
        if last:
            self.state = 'victory'
            self.state_t = 0
            self.banner = ('STAGE CLEAR', '', 0.0, 2.5)
            self.flash(WHITE, 120)
        else:
            self.banner = ('ARENA CLEAR', '', 0.0, 1.8)
            pl.hp = min(pl.maxhp, pl.hp + pl.maxhp * .12)
            self.bounds = (30, self.stage.width)
            self.arena_i += 1
            self.arena_state = 'walk'
            if self.boss:
                self.boss = None
                self.music.start(self.stage.music)
            self.go_t = 0

    # ------------------------------------------------------------ events / update
    def event(self, ev):
        if self.state in ('pause', 'dead') and self.menu_event(ev):
            return
        if ev.type == pygame.WINDOWFOCUSLOST and self.state == 'play':
            self.pause()
        if ev.type == pygame.KEYDOWN:
            if ev.key in (K_ESCAPE, K_p) and self.state in ('play', 'intro'):
                self.pause()
                return
            if self.state == 'play' or self.state == 'intro' and False:
                for act in PRESS:
                    if ev.key in KEYS[act]:
                        self.now = time.perf_counter()
                        if act in ('light', 'heavy', 'dodge', 'block', 'special'):
                            pl = self.player
                            pl.press(self, act)
                            self.last_judge = pl.buf[act]
                        else:
                            self.player.buf['jump'] = ('good', 0, self.now)

    def pause(self):
        self.state = 'pause'
        self.music.pause()
        self.pause_menu = ui.MenuList(self.app, [
            dict(label='RESUME', fn=self.resume),
            dict(label='RESTART STAGE', fn=self.restart),
            dict(label='SETTINGS', fn=lambda: self.app.push(ui.SettingsScene(self.app))),
            dict(label='QUIT TO MENU', fn=self.quit),
        ], y=300)
        self.sfx('ui_ok')

    def resume(self):
        self.state = 'play'
        self.music.resume()

    def restart(self):
        self.music.resume()
        self.app.replace(Gameplay(self.app, self.mode, self.stage_idx))

    def quit(self):
        self.music.resume()
        self.app.audio.start('menu')
        self.app.replace(ui.MainMenu(self.app))

    def menu_event(self, ev):
        m = self.pause_menu if self.state == 'pause' else self.dead_menu
        if m is None:
            return False
        r = m.event(ev)
        if r == 'back' and self.state == 'pause':
            self.resume()
        return True

    def retry_arena(self):
        self.continues += 1
        pl = self.player
        a = self.stage.arenas[self.arena_i]
        self.enemies.clear()
        self.projs.clear()
        self.tokens.clear()
        self.spawn_q.clear()
        self.hazards = [h for h in self.hazards if not getattr(h, 'boss', False)]
        if self.snap:
            self.score, st, self.max_combo = self.snap
            self.stats.update(st)
        pl.dead = False
        pl.hp = pl.maxhp * .7
        pl.act = None
        pl.inv = 1.5
        pl.x = a.x0 + 200
        pl.y = GROUND
        pl.vx = pl.vy = 0
        self.combo = self.groove = 0
        self.boss = None
        self.state = 'play'
        self.dead_menu = None
        self.music.start(self.stage.music)
        self.lock_arena()

    def finish(self):
        from results import Results
        self.music.stop(600)
        self.app.replace(Results(self.app, self))

    def update(self, dt):
        self.now = time.perf_counter()
        self.kp = pygame.key.get_pressed()
        st = self.state
        self.state_t += dt
        if st == 'intro':
            if self.state_t > 2.4:
                self.state = 'play'
                self.state_t = 0
            self.update_world(dt * .0, idle=True)
            return
        if st == 'pause':
            return
        if st == 'dead':
            self.update_fx(dt)
            return
        if st == 'dying':
            self.update_world(dt * .35)
            if self.state_t > 1.6:
                self.show_dead()
            return
        if st == 'victory':
            self.update_world(dt)
            if self.state_t > 2.6:
                self.finish()
            return
        self.time += dt
        self.save.d['stats']['play_time'] += dt
        self.update_world(dt)

    def show_dead(self):
        self.state = 'dead'
        items = []
        if self.mode in ('campaign', 'select', 'bossrush') and self.arena_state != 'walk':
            items.append(dict(label='RETRY ARENA', fn=self.retry_arena))
        if self.mode == 'gauntlet':
            items.append(dict(label='SEE RESULTS', fn=self.finish))
        items += [dict(label='RESTART STAGE', fn=self.restart), dict(label='QUIT TO MENU', fn=self.quit)]
        self.dead_menu = ui.MenuList(self.app, items, y=380)
        self.save.store()

    def update_fx(self, dt):
        self.particles.update(dt)
        self.shake_amt = max(0, self.shake_amt - dt * 60)
        self.flash_a = max(0, self.flash_a - dt * 420)
        self.cam.zoom += (1 - self.cam.zoom) * min(1, dt * 8)
        for f in self.floaters:
            f[2] += f[5] * dt
            f[6] -= dt
        self.floaters = [f for f in self.floaters if f[6] > 0]

    def update_world(self, dt, idle=False):
        if idle:
            dt = 0
        self.update_fx(1 / 60 if idle else dt)
        if self.freeze_t > 0:
            self.freeze_t -= max(dt, 1 / 120)
            self.camera(dt)
            return
        pl = self.player
        if dt > 0:
            self.combo_t -= dt
            if self.combo_t <= 0:
                self.combo = 0
            if self.state == 'play':
                self.update_arena(dt)
            pl.update(self, dt)
            for e in self.enemies:
                e.update(self, dt)
            keep = []
            for e in self.enemies:
                if e.state == 'dead' and e.dead_t <= 0:
                    self.particles.burst(e.x, e.y - 40, e.col, 12, 300)
                    continue
                keep.append(e)
            self.enemies = keep
            for p in self.projs:
                p.update(self, dt)
            self.projs = [p for p in self.projs if not p.dead]
            for h in self.hazards:
                h.update(self, dt)
            for s in self.props:
                s.update(self, dt)
            for pk in self.pickups:
                pk.update(self, dt)
            self.pickups = [p for p in self.pickups if not p.dead]
            self.tokens = {e: v for e, v in self.tokens.items() if e in self.enemies and e.state != 'dead'}
            if self.hint_on:
                self.hint_t += dt
                a = self.stage.arenas[self.arena_i]
                if self.hint_t > 5.5:
                    self.hint_t = 0
                    self.hint_i += 1
                    if self.hint_i >= len(a.hints):
                        self.hint_on = False
            if self.banner:
                b = self.banner
                self.banner = (b[0], b[1], b[2] + dt, b[3]) if b[2] + dt < b[3] else None
        # beat pulse
        bi = int(self.music.bf())
        if bi != self.beat_prev:
            self.beat_prev = bi
            self.zoom_punch(.004)
        self.camera(dt)

    def camera(self, dt):
        pl = self.player
        if self.arena_state in ('fight',) or (self.arena_state == 'clear' and self.state == 'victory'):
            tx = self.stage.arenas[self.arena_i].x0
        else:
            tx = pl.x - W / 2 + pl.f * 90
        tx = clamp(tx, 0, self.stage.width - W)
        self.cam.x += (tx - self.cam.x) * min(1, dt * (4 if self.arena_state == 'fight' else 6) + (.02 if dt == 0 else 0))

    # ------------------------------------------------------------ draw
    def draw(self, screen):
        sc, fx = self.scene, self.fx
        fx.fill((0, 0, 0))
        m = self.music
        phase = m.phase()
        bf = m.bf()
        cam = self.cam.x
        prog = clamp(cam / max(1, self.stage.width - W), 0, 1)
        tint = self.stage_tint()
        self.bg.draw(sc, fx, cam, self.time + self.state_t * 0, phase, bf, prog, tint)
        self.draw_platforms(sc, fx, cam, phase)
        for h in self.hazards:
            h.draw(sc, fx, cam, phase)
        for s in self.props:
            s.draw(sc, fx, cam, phase)
        for pk in self.pickups:
            pk.draw(sc, fx, cam)
        for e in sorted(self.enemies, key=lambda e: e.sc):
            e.draw(sc, fx, cam, m.t(), phase)
        self.player.draw(sc, fx, cam, m.t(), phase)
        for p in self.projs:
            p.draw(sc, fx, cam)
        self.particles.draw(fx, cam)
        sc.blit(fx, (0, 0), special_flags=pygame.BLEND_ADD)
        for txt, x, y, col, size, vy, life, ml in self.floaters:
            gfx.text(sc, txt, size, col, (x - cam, y), alpha=int(255 * clamp(life / ml * 1.6, 0, 1)))
        if self.arena_state == 'fight' and self.hint_on:
            a = self.stage.arenas[self.arena_i]
            if self.hint_i < len(a.hints):
                gfx.text(sc, a.hints[self.hint_i], 24, (255, 255, 255), (W // 2, 200), alpha=int(255 * clamp(min(self.hint_t, 5.5 - self.hint_t) * 2, 0, 1)))
        # compose
        z = self.cam.zoom
        ox = oy = 0
        if self.shake_amt > .1:
            ox = int(random.uniform(-1, 1) * self.shake_amt)
            oy = int(random.uniform(-1, 1) * self.shake_amt)
            screen.fill((0, 0, 0))
        if z > 1.002:
            zs = pygame.transform.scale(sc, (int(W * z), int(H * z)))
            screen.blit(zs, (-(zs.get_width() - W) // 2 + ox, -(zs.get_height() - H) // 2 + oy))
        else:
            screen.blit(sc, (ox, oy))
        screen.blit(self.vig, (0, 0))
        if self.flash_a > 1:
            fs = pygame.Surface((W, H))
            fs.fill(self.flash_col)
            fs.set_alpha(int(self.flash_a))
            screen.blit(fs, (0, 0))
        self.draw_hud(screen, phase)
        self.draw_overlay(screen)

    def draw_platforms(self, sc, fx, cam, phase):
        acc = self.bg.th['acc'][1]
        for px, py, pw in self.platforms:
            x = px - cam
            if x > W or x + pw < 0:
                continue
            pygame.draw.rect(sc, (10, 8, 22), (x, py, pw, 14), border_radius=4)
            pygame.draw.rect(sc, shade(acc, .5), (x, py, pw, 14), 2, border_radius=4)
            pygame.draw.line(fx, shade(acc, .5 + .5 * (1 - phase) ** 3), (x + 4, py), (x + pw - 4, py), 3)
            for k in range(int(pw // 40)):
                pygame.draw.line(sc, shade(acc, .25), (x + 20 + k * 40, py + 14), (x + 20 + k * 40, py + 26), 2)

    def stage_tint(self):
        return None

    # ---------------- HUD
    def draw_hud(self, s, phase):
        pl = self.player
        m = self.music
        pulse = (1 - phase) ** 3
        # health
        x, y, w, h = 36, 30, 380, 24
        pygame.draw.polygon(s, (8, 8, 20), [(x - 4, y - 4), (x + w + 4, y - 4), (x + w - 14, y + h + 4), (x - 4, y + h + 4)])
        fill = clamp(pl.hp / pl.maxhp, 0, 1)
        col = mix((255, 60, 80), (80, 255, 170), fill)
        pygame.draw.polygon(s, col, [(x, y), (x + w * fill, y), (x + w * fill - 12, y + h), (x, y + h)])
        gfx.text(s, f'{int(pl.hp)} / {int(pl.maxhp)}', 16, (255, 255, 255), (x + 10, y + h / 2), 'midleft')
        # heat
        hx, hy, hw = 36, 66, 280
        pygame.draw.rect(s, (8, 8, 20), (hx - 3, hy - 3, hw + 6, 16))
        full = pl.heat >= 100
        hc = GOLD if not full or int(self.now * 8) % 2 else WHITE
        pygame.draw.rect(s, hc, (hx, hy, hw * pl.heat / 100, 10))
        if full and self.unlocked('special'):
            gfx.text(s, 'DROP THE BASS  [O]', 16, GOLD, (hx + hw + 14, hy + 5), 'midleft')
        else:
            gfx.text(s, 'HEAT', 14, (200, 190, 140), (hx + hw + 14, hy + 5), 'midleft')
        # guard
        if pl.guard < 99:
            pygame.draw.rect(s, (8, 8, 20), (hx - 3, 84, 130, 10))
            pygame.draw.rect(s, (150, 200, 255), (hx, 86, 124 * pl.guard / 100, 6))
        # score/combo
        gfx.text(s, f'{self.score:,}', 44, (255, 255, 255), (W - 36, 34), 'midright')
        gfx.text(s, self.stage.name, 16, (170, 170, 200), (W - 36, 68), 'midright')
        if self.combo > 1:
            sz = int(46 + 14 * pulse + min(30, self.combo * .5))
            gfx.text(s, f'{self.combo}', sz, GOLD, (W - 36, 128), 'midright')
            gfx.text(s, 'HITS', 18, GOLD, (W - 36, 168), 'midright')
            pygame.draw.rect(s, (60, 50, 20), (W - 176, 184, 140, 5))
            pygame.draw.rect(s, GOLD, (W - 176, 184, 140 * clamp(self.combo_t / 2.4, 0, 1), 5))
        if self.groove >= 3:
            gfx.text(s, f'GROOVE x{self.mult()}', 26, CYAN, (W - 36, 212), 'midright')
        # arena info
        if self.mode == 'gauntlet':
            gfx.text(s, f'WAVE {self.gwave}', 22, WHITE, (W // 2, 30))
        elif self.arena_state == 'fight' and not self.stage.arenas[self.arena_i].boss:
            a = self.stage.arenas[self.arena_i]
            gfx.text(s, f'ARENA {self.arena_i + 1}/{len(self.stage.arenas)}   WAVE {min(self.wave + 1, len(a.waves))}/{len(a.waves)}', 18, (200, 200, 230), (W // 2, 30))
        if self.arena_state == 'walk' and self.state == 'play' and self.arena_i > 0:
            k = .5 + .5 * math.sin(self.now * 6)
            gfx.text(s, 'GO  >>>', 40, mix((90, 90, 120), WHITE, k), (W - 160, 330))
        elif self.arena_state == 'walk' and self.state == 'play' and self.player.x < 500:
            gfx.text(s, 'GO  >>>', 40, WHITE, (W - 160, 330), alpha=int(140 + 100 * math.sin(self.now * 6)))
        # boss bar
        b = self.boss
        if b and b.state != 'dead' or (b and b.state == 'dead' and self.boss_dead_t > 0):
            bw = 620
            bx, by = W // 2 - bw // 2, 66
            gfx.text(s, b.name, 24, b.color, (W // 2, 50))
            pygame.draw.rect(s, (8, 8, 20), (bx - 3, by - 3, bw + 6, 20))
            pygame.draw.rect(s, b.color, (bx, by, bw * clamp(b.hp / b.maxhp, 0, 1), 14))
            for t in b.thresholds:
                pygame.draw.line(s, (255, 255, 255), (bx + bw * t, by - 3), (bx + bw * t, by + 17), 2)
            if b.trans > 0:
                gfx.text(s, 'INVULNERABLE', 16, (255, 255, 255), (W // 2, by + 32))
        # rhythm track
        self.draw_track(s, phase)
        # banner
        if self.banner:
            t, sub, e, dur = self.banner
            k = clamp(min(e * 4, (dur - e) * 4, 1), 0, 1)
            gfx.text(s, t, 72, WHITE, (W // 2, 250 - 10 * (1 - k)), alpha=int(255 * k))
            if sub:
                gfx.text(s, sub, 24, GOLD, (W // 2, 310), alpha=int(255 * k))

    def draw_track(self, s, phase):
        m = self.music
        cx, cy = W // 2, H - 44
        beat = m.beat
        pw, gw = self.win()
        pps = 300
        t = m.t() - self.save.s['offset'] / 1000.0
        pygame.draw.rect(s, (8, 8, 22), (cx - 380, cy - 20, 760, 40), border_radius=20)
        pygame.draw.rect(s, (30, 30, 60), (cx - 380, cy - 20, 760, 40), 2, border_radius=20)
        pygame.draw.rect(s, (30, 60, 80), (cx - gw * pps, cy - 14, gw * pps * 2, 28), border_radius=8)
        pygame.draw.rect(s, (90, 80, 20), (cx - pw * pps, cy - 14, pw * pps * 2, 28), border_radius=8)
        k = math.floor(t / beat)
        for i in range(-1, 4):
            for half in (0, 1):
                bt = (k + i + half * .5) * beat
                d = bt - t
                if -.12 < d < 1.2:
                    xx = d * pps
                    a = clamp(1 - abs(d) / 1.3, 0, 1)
                    for sgn in (-1, 1):
                        px = cx + sgn * xx
                        if abs(xx) > 370:
                            continue
                        if half == 0:
                            c = mix((60, 60, 100), WHITE, a)
                            pygame.draw.circle(s, c, (int(px), cy), 9)
                        else:
                            pygame.draw.circle(s, mix((40, 40, 70), (150, 150, 200), a), (int(px), cy), 4)
        ring = 22 + 8 * (1 - phase) ** 3
        pygame.draw.circle(s, mix((80, 80, 120), GOLD, (1 - phase) ** 4), (cx, cy), int(ring), 3)
        js = self.judge_show
        if js:
            grade, off, t0 = js
            age = self.now - t0
            if age < .7:
                col = {'perfect': GOLD, 'good': CYAN, 'off': (150, 150, 170)}[grade]
                px = cx + clamp(off * pps, -370, 370)
                pygame.draw.line(s, col, (px, cy - 22), (px, cy + 22), 4)
                if grade != 'perfect':
                    gfx.text(s, 'EARLY' if off < 0 else 'LATE', 16, col, (cx, cy - 36), alpha=int(255 * (1 - age / .7)))
                else:
                    gfx.text(s, 'PERFECT', 18, col, (cx, cy - 36), alpha=int(255 * (1 - age / .7)))
        gfx.text(s, f'{m.bpm} BPM', 14, (120, 120, 160), (cx + 340, cy + 30), 'midright')

    def draw_overlay(self, s):
        st = self.state
        if st == 'intro':
            k = clamp(self.state_t / .4, 0, 1) * clamp((2.4 - self.state_t) / .4, 0, 1)
            bar = int(120 * k)
            pygame.draw.rect(s, (0, 0, 0), (0, 0, W, bar))
            pygame.draw.rect(s, (0, 0, 0), (0, H - bar, W, bar))
            if k > 0:
                lab = f'STAGE {self.stage.idx + 1}' if self.stage.idx >= 0 else self.mode.upper()
                gfx.text(s, lab, 22, GOLD, (W // 2, 300), alpha=int(255 * k))
                gfx.text(s, self.stage.name, 84, WHITE, (W // 2, 360), alpha=int(255 * k))
                gfx.text(s, f'{self.stage.sub.upper()}   -   {self.music.bpm} BPM', 22, (200, 200, 230), (W // 2, 425), alpha=int(255 * k))
        elif st in ('pause', 'dead', 'dying'):
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 10, 170 if st != 'dying' else int(min(150, self.state_t * 100))))
            s.blit(ov, (0, 0))
            if st == 'pause':
                gfx.text(s, 'PAUSED', 72, WHITE, (W // 2, 170))
                self.pause_menu.draw(s, self.now, self.music.phase())
            elif st == 'dead':
                gfx.text(s, 'DOWN', 90, RED, (W // 2, 210))
                gfx.text(s, 'Score {:,}   Max combo {}'.format(self.score, self.max_combo), 22, (220, 220, 240), (W // 2, 290))
                self.dead_menu.draw(s, self.now, self.music.phase())
