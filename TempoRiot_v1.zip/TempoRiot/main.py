"""TEMPO RIOT - rhythm-driven stickman action game.  Run:  python main.py"""
import os
import sys

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pygame

from core import W, H, Save
import gfx


class App:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        pygame.display.set_caption("TEMPO RIOT")
        self.save = Save()
        flags = pygame.SCALED | pygame.RESIZABLE
        if self.save.s['fullscreen']:
            flags |= pygame.FULLSCREEN
        try:
            self.screen = pygame.display.set_mode((W, H), flags, vsync=1)
        except Exception:
            self.screen = pygame.display.set_mode((W, H), flags)
        self.clock = pygame.time.Clock()
        self.loading('LOADING...')
        from audio import Audio
        self.audio = Audio(self.save)
        self.audio.start('menu')
        self.scenes = []
        self.running = True

    def loading(self, msg):
        self.screen.fill((8, 4, 20))
        gfx.text(self.screen, msg, 36, (255, 214, 80), (W // 2, H // 2))
        pygame.display.flip()
        pygame.event.pump()

    def set_fullscreen(self, on):
        try:
            if bool(self.screen.get_flags() & pygame.FULLSCREEN) != on:
                pygame.display.toggle_fullscreen()
        except Exception:
            pass

    def push(self, s):
        self.scenes.append(s)

    def pop(self):
        if len(self.scenes) > 1:
            self.scenes.pop()

    def replace(self, s):
        if self.scenes:
            self.scenes.pop()
        self.scenes.append(s)

    def quit(self):
        self.save.store()
        self.running = False

    def run(self, first):
        self.scenes = [first]
        while self.running:
            dt = min(self.clock.tick(60) / 1000.0, 1 / 30)
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.quit()
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_F11:
                    self.save.s['fullscreen'] = not self.save.s['fullscreen']
                    self.set_fullscreen(self.save.s['fullscreen'])
                elif self.scenes:
                    self.scenes[-1].event(ev)
            if not self.scenes:
                break
            top = self.scenes[-1]
            top.update(dt)
            base = self.scenes[-2] if top.overlay and len(self.scenes) > 1 else None
            if base is not None:
                base.draw(self.screen)
            top.draw(self.screen)
            pygame.display.flip()
        self.save.store()
        pygame.quit()


def main():
    app = App()
    from ui import TitleScene
    app.run(TitleScene(app))


if __name__ == "__main__":
    main()
