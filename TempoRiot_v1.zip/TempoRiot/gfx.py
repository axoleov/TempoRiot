"""Rendering primitives: fonts, glow sprites, particles, procedural stickman."""
import math
import random

import numpy as np
import pygame

from core import *

pygame.font.init()

# ------------------------------------------------------------------ text
_FONT_NAMES = "bahnschrift,segoeuiblack,impact,arialblack,verdana,arial"
_fonts = {}


def font(sz):
    f = _fonts.get(sz)
    if f is None:
        f = pygame.font.SysFont(_FONT_NAMES, sz, bold=True)
        _fonts[sz] = f
    return f


_tc = {}


def _img(s, sz, col):
    k = (s, sz, col)
    im = _tc.get(k)
    if im is None:
        if len(_tc) > 700:
            _tc.clear()
        im = font(sz).render(s, True, col)
        _tc[k] = im
    return im


def text(surf, s, sz, col, pos, anchor="center", shadow=(0, 0, 0), alpha=255, sh=2):
    im = _img(s, sz, col)
    r = im.get_rect(**{anchor: (int(pos[0]), int(pos[1]))})
    if shadow:
        sm = _img(s, sz, shadow)
        if alpha < 255:
            sm.set_alpha(alpha)
        surf.blit(sm, (r.x + sh, r.y + sh))
        if alpha < 255:
            sm.set_alpha(255)
    if alpha < 255:
        im.set_alpha(alpha)
    surf.blit(im, r)
    if alpha < 255:
        im.set_alpha(255)
    return r


# ------------------------------------------------------------------ glow
_gl = {}


def glow(r, col):
    r = max(4, int(r) // 4 * 4)
    key = (r, col)
    s = _gl.get(key)
    if s is None:
        if len(_gl) > 500:
            _gl.clear()
        s = pygame.Surface((r * 2, r * 2))
        n = max(4, min(r // 2, 20))
        for i in range(n):
            k = (i + 1) / n
            pygame.draw.circle(s, shade(col, k * k * .85), (r, r), int(r * (1 - i / n)))
        _gl[key] = s
    return s


def blit_glow(fx, x, y, r, col):
    g = glow(r, col)
    fx.blit(g, (int(x) - g.get_width() // 2, int(y) - g.get_height() // 2), special_flags=pygame.BLEND_ADD)


_sh = {}


def shadow(surf, x, y, w, a=1.0):
    w = max(8, int(w) // 8 * 8)
    key = (w, int(a * 4))
    s = _sh.get(key)
    if s is None:
        s = pygame.Surface((w, max(4, int(w * .2))), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (0, 0, 0, int(120 * a)), s.get_rect())
        _sh[key] = s
    surf.blit(s, (int(x - w / 2), int(y - s.get_height() / 2)))


def make_vignette():
    w, h = 160, 90
    yy, xx = np.mgrid[0:h, 0:w]
    d = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    a = np.clip((d - .55) / .75, 0, 1) ** 1.5 * 210
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((0, 0, 0, 0))
    pygame.surfarray.pixels_alpha(s)[:] = a.T.astype(np.uint8)
    return pygame.transform.smoothscale(s, (W, H))


# ------------------------------------------------------------------ poses
DEFAULT = dict(lean=6, head=0, fa=35, fa2=90, ba=15, ba2=100, fl=14, fl2=-14, bl=-20, bl2=-2)


def P(**k):
    d = dict(DEFAULT)
    d.update(k)
    return d


POSES = {
    'idle': P(),
    'jump': P(lean=4, fa=70, fa2=60, ba=-10, ba2=50, fl=55, fl2=-75, bl=-25, bl2=-45),
    'fall': P(lean=0, fa=115, fa2=15, ba=95, ba2=20, fl=18, fl2=-35, bl=-14, bl2=-30),
    'dodge': P(lean=48, head=8, fa=-40, fa2=25, ba=-55, ba2=15, fl=75, fl2=-100, bl=-45, bl2=-60),
    'block': P(lean=12, fa=75, fa2=115, ba=60, ba2=125, fl=20, fl2=-22, bl=-26, bl2=-6),
    'parry': P(lean=-6, fa=110, fa2=40, ba=40, ba2=110, fl=22, fl2=-20, bl=-30, bl2=-8),
    'hurt': P(lean=-24, head=-22, fa=85, fa2=30, ba=105, ba2=25, fl=22, fl2=-24, bl=-8, bl2=-22),
    'stagger': P(lean=-16, head=-14, fa=20, fa2=30, ba=30, ba2=20, fl=8, fl2=-8, bl=-14, bl2=-10),
    'down': P(lean=-84, head=-10, fa=-45, fa2=15, ba=-75, ba2=10, fl=72, fl2=-5, bl=62, bl2=-8),
    'flail': P(lean=-40, head=-30, fa=140, fa2=20, ba=-100, ba2=30, fl=60, fl2=-40, bl=-40, bl2=-40),
    'getup': P(lean=45, fa=30, fa2=40, ba=20, ba2=40, fl=60, fl2=-90, bl=-50, bl2=-80),
    'spawn': P(lean=0, fa=170, fa2=0, ba=170, ba2=0, fl=6, fl2=-6, bl=-6, bl2=-6),
    # attacks (w = windup, h = hit)
    'w_jab': P(lean=-2, fa=-15, fa2=110, fl=18, fl2=-16, bl=-24),
    'h_jab': P(lean=16, fa=88, fa2=2, ba=25, ba2=100, fl=26, fl2=-22, bl=-26, bl2=-2),
    'w_cross': P(lean=-6, ba=-25, ba2=105, fa=40, fa2=95, fl=20, fl2=-14),
    'h_cross': P(lean=26, ba=90, ba2=0, fa=35, fa2=100, fl=26, fl2=-24, bl=-32, bl2=-4),
    'w_hook': P(lean=-12, ba=-50, ba2=70, fa=35, fa2=100),
    'h_hook': P(lean=28, ba=100, ba2=-25, fa=40, fa2=100, fl=28, fl2=-26, bl=-36),
    'w_spin': P(lean=30, head=10, fa=-20, fa2=60, ba=-40, ba2=60, fl=50, fl2=-70, bl=-40, bl2=-40),
    'h_spin': P(lean=-30, head=-6, fa=140, fa2=10, ba=-110, ba2=10, fl=98, fl2=-6, bl=-10, bl2=-8),
    'w_kick': P(lean=-6, fa=30, fa2=100, ba=20, ba2=100, fl=45, fl2=-115, bl=-8, bl2=-6),
    'h_kick': P(lean=-24, fa=70, fa2=60, ba=-30, ba2=40, fl=86, fl2=-4, bl=-8, bl2=-8),
    'w_axe': P(lean=-30, fa=60, fa2=60, ba=30, ba2=60, fl=175, fl2=-4, bl=-6, bl2=-6),
    'h_axe': P(lean=22, fa=60, fa2=50, ba=40, ba2=60, fl=62, fl2=-4, bl=-30, bl2=-30),
    'w_round': P(lean=6, fa=40, fa2=90, fl=30, fl2=-130, bl=-8, bl2=-6),
    'h_round': P(lean=-38, head=-10, fa=110, fa2=10, ba=-100, ba2=10, fl=98, fl2=-3, bl=-4, bl2=-6),
    'w_break': P(lean=-14, fa=170, fa2=5, ba=170, ba2=5, fl=8, fl2=-8, bl=-10, bl2=-6),
    'h_break': P(lean=46, fa=45, fa2=10, ba=40, ba2=10, fl=58, fl2=-80, bl=-50, bl2=-60),
    'w_up': P(lean=22, fa=-25, fa2=70, ba=10, ba2=100, fl=45, fl2=-70, bl=-40, bl2=-60),
    'h_up': P(lean=-10, fa=158, fa2=-6, ba=30, ba2=100, fl=22, fl2=-30, bl=-36, bl2=-12),
    'w_sweep': P(lean=26, fa=40, fa2=70, ba=30, ba2=70, fl=15, fl2=-50, bl=-80, bl2=-90),
    'h_sweep': P(lean=36, fa=50, fa2=60, ba=-30, ba2=40, fl=92, fl2=0, bl=-80, bl2=-100),
    'w_air': P(lean=2, fa=-10, fa2=100, ba=20, ba2=100, fl=40, fl2=-70, bl=-20, bl2=-50),
    'h_air': P(lean=14, fa=90, fa2=0, ba=100, ba2=-10, fl=50, fl2=-60, bl=-25, bl2=-50),
    'w_airk': P(lean=8, fa=60, fa2=80, ba=30, ba2=80, fl=40, fl2=-120, bl=-20, bl2=-60),
    'h_airk': P(lean=-24, fa=110, fa2=10, ba=-40, ba2=30, fl=88, fl2=-2, bl=-20, bl2=-60),
    'h_dive': P(lean=-52, head=-10, fa=150, fa2=10, ba=-120, ba2=10, fl=52, fl2=-2, bl=40, bl2=-10),
    'w_counter': P(lean=-30, fa=-40, fa2=110, ba=-60, ba2=90, fl=50, fl2=-100, bl=-40, bl2=-40),
    'h_counter': P(lean=34, fa=90, fa2=0, ba=90, ba2=0, fl=60, fl2=-40, bl=-50, bl2=-50),
    'w_special': P(lean=-10, fa=160, fa2=10, ba=-160, ba2=-10, fl=30, fl2=-40, bl=-30, bl2=-40),
    'h_special': P(lean=10, fa=175, fa2=0, ba=175, ba2=0, fl=40, fl2=-60, bl=-40, bl2=-60),
    'w_bash': P(lean=-10, fa=35, fa2=85, fl=20, fl2=-20, bl=-26),
    'h_bash': P(lean=22, fa=88, fa2=2, ba=80, ba2=8, fl=30, fl2=-24, bl=-32),
    'w_gun': P(lean=0, fa=60, fa2=50, ba=30, ba2=80),
    'h_gun': P(lean=-6, fa=90, fa2=0, ba=85, ba2=5, fl=16, fl2=-14, bl=-22),
    'w_charge': P(lean=40, head=10, fa=-30, fa2=30, ba=-40, ba2=30, fl=60, fl2=-90, bl=-40, bl2=-40),
    'h_charge': P(lean=50, head=10, fa=-60, fa2=20, ba=-70, ba2=20, fl=70, fl2=-30, bl=-50, bl2=-20),
    'guard': P(lean=8, fa=88, fa2=6, ba=70, ba2=60),
}


def lerp_pose(a, b, t):
    return {k: a[k] + (b[k] - a[k]) * t for k in a}


def run_pose(ph, spd=1.0, lean=16):
    s = math.sin(ph)
    c = math.cos(ph)
    return dict(lean=lean * spd, head=0,
                fa=-45 * s * spd + 20, fa2=85, ba=45 * s * spd + 10, ba2=95,
                fl=52 * s * spd, fl2=-25 - 55 * max(0, c) * spd,
                bl=-52 * s * spd, bl2=-25 - 55 * max(0, -c) * spd)


# ------------------------------------------------------------------ skeleton
def skel(p, f, sc):
    L = p['lean'] * DEG
    tl = 34 * sc
    sh = (math.sin(L) * f * tl, -math.cos(L) * tl)
    hr = 11 * sc
    hd = (p['lean'] + p['head']) * DEG
    hc = (sh[0] + math.sin(hd) * f * (hr + 4 * sc), sh[1] - math.cos(hd) * (hr + 4 * sc))
    so = (sh[0] * .9, sh[1] * .9)

    def limb(o, a1, a2, l1, l2):
        A = a1 * DEG
        B = (a1 + a2) * DEG
        m = (o[0] + math.sin(A) * f * l1, o[1] + math.cos(A) * l1)
        e = (m[0] + math.sin(B) * f * l2, m[1] + math.cos(B) * l2)
        return m, e

    fe, fh = limb(so, p['fa'], p['fa2'], 19 * sc, 19 * sc)
    be, bh = limb(so, p['ba'], p['ba2'], 19 * sc, 19 * sc)
    fk, ff = limb((0, 0), p['fl'], p['fl2'], 26 * sc, 26 * sc)
    bk, bf = limb((0, 0), p['bl'], p['bl2'], 26 * sc, 26 * sc)
    return dict(so=so, sh=sh, hc=hc, fe=fe, fh=fh, be=be, bh=bh, fk=fk, ff=ff, bk=bk, bf=bf), hr


def draw_stick(surf, x, y, f, pose, col, sc=1.0, flash=0.0, dark=(6, 6, 16), width=1.0):
    k, hr = skel(pose, f, sc)
    low = max(k['ff'][1], k['bf'][1], k['hc'][1] + hr, k['fh'][1], k['bh'][1], k['fk'][1], k['bk'][1])
    ox, oy = x, y - low
    Pt = {n: (ox + v[0], oy + v[1]) for n, v in k.items()}
    Pt['pel'] = (ox, oy)
    c = mix(col, (255, 255, 255), flash) if flash > 0 else col
    cb = shade(c, .6)
    w = max(3, int(5.5 * sc * width))

    def seg(a, b, cc, ww):
        pygame.draw.line(surf, dark, a, b, ww + 4)
        pygame.draw.circle(surf, dark, b, (ww + 4) // 2)
        pygame.draw.line(surf, cc, a, b, ww)
        pygame.draw.circle(surf, cc, b, ww // 2)

    seg(Pt['so'], Pt['be'], cb, w)
    seg(Pt['be'], Pt['bh'], cb, w)
    seg(Pt['pel'], Pt['bk'], cb, w)
    seg(Pt['bk'], Pt['bf'], cb, w)
    seg(Pt['pel'], Pt['sh'], c, w + 1)
    hc = Pt['hc']
    pygame.draw.circle(surf, dark, hc, int(hr) + 2)
    pygame.draw.circle(surf, c, hc, int(hr) + 2, 3)
    vx = hc[0] + f * hr * .35
    pygame.draw.line(surf, (255, 255, 255), (vx, hc[1] - 1), (vx + f * hr * .55, hc[1] - 1), 3)
    seg(Pt['pel'], Pt['fk'], c, w)
    seg(Pt['fk'], Pt['ff'], c, w)
    seg(Pt['so'], Pt['fe'], c, w)
    seg(Pt['fe'], Pt['fh'], c, w)
    Pt['hr'] = hr
    return Pt


# ------------------------------------------------------------------ particles
class Particles:
    def __init__(self):
        self.p = []

    def add(self, x, y, vx, vy, life, col, size, kind=0, grav=0.0, drag=0.0):
        if len(self.p) < 1000:
            self.p.append([x, y, vx, vy, life, life, col, size, kind, grav, drag])

    def spark(self, x, y, ang, spd, col, life=.35, size=3, grav=600):
        self.add(x, y, math.cos(ang) * spd, math.sin(ang) * spd, life, col, size, 0, grav, 1.5)

    def burst(self, x, y, col, n, spd=400, ang=0.0, spread=math.tau, life=.4, size=3, grav=500):
        for _ in range(n):
            a = ang + (random.random() - .5) * spread
            s = spd * (.3 + random.random() * .7)
            self.spark(x, y, a, s, col, life * (.6 + random.random() * .6), size, grav)

    def ring(self, x, y, col, r0, r1, life=.3, w=4):
        self.add(x, y, r0, r1, life, col, w, 2)

    def glow(self, x, y, col, size, life=.2):
        self.add(x, y, 0, 0, life, col, size, 1)

    def dust(self, x, y, n=4, col=(90, 90, 120)):
        for _ in range(n):
            self.add(x + random.uniform(-14, 14), y, random.uniform(-70, 70), random.uniform(-60, -10),
                     random.uniform(.25, .5), col, random.uniform(4, 8), 3, 0, 2)

    def update(self, dt):
        out = []
        for p in self.p:
            p[4] -= dt
            if p[4] <= 0:
                continue
            if p[8] != 2:
                p[0] += p[2] * dt
                p[1] += p[3] * dt
                p[3] += p[9] * dt
                if p[10]:
                    d = max(0, 1 - p[10] * dt)
                    p[2] *= d
            out.append(p)
        self.p = out

    def draw(self, fx, camx):
        for x, y, vx, vy, life, ml, col, size, kind, grav, drag in self.p:
            a = life / ml
            sx = x - camx
            if kind == 0:
                c = shade(col, a)
                pygame.draw.line(fx, c, (sx, y), (sx - vx * .04, y - vy * .04), max(1, int(size * a)))
            elif kind == 1:
                blit_glow(fx, sx, y, size * (.5 + a * .5), shade(col, a))
            elif kind == 2:
                r = vx + (vy - vx) * ease_out(1 - a)
                pygame.draw.circle(fx, shade(col, a), (int(sx), int(y)), max(2, int(r)), max(1, int(size * a)))
            else:
                pygame.draw.circle(fx, shade(col, a * .5), (int(sx), int(y)), max(1, int(size * a)))
