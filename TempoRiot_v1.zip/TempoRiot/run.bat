@echo off
cd /d "%~dp0"
py -3.12 -m pip install -r requirements.txt --quiet
py -3.12 main.py
pause
