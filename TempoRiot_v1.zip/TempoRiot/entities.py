"""Game entities: Fighter base, Player, Enemy, Projectile, Hazard, Speaker, Pickup."""
import math
import random

import pygame

import gfx
from core import *
from gfx import POSES, lerp_pose, run_pose, draw_stick, blit_glow

CYAN = (60, 230, 255)
GOLD = (255, 214, 80)
WHITE = (255, 255, 255)
RED = (255, 60, 70)
MAG = (255, 60, 190)


# ============================================================ attack tables
def A(**k):
    d = dict(su=.08, ac=.07, rc=.14, dmg=8, hb=(10, -90, 60, 40), kb=(150, 0), stun=.3, lunge=0,
             kind='light', gb=False, launch=False, down=False, air=False, hs=.05, shake=3, aoe=0,
             poses=('w_jab', 'h_jab'), cf=.55, tip='fh', snd='whoosh', fin=False, dive=False, ring=False)
    d.update(k)
    return d


ATK = {
    'jab': A(su=.055, ac=.06, rc=.10, dmg=7, hb=(8, -92, 62, 34), kb=(130, 0), stun=.30, lunge=170, poses=('w_jab', 'h_jab'), hs=.04, shake=2),
    'cross': A(su=.065, ac=.06, rc=.11, dmg=9, hb=(8, -90, 70, 36), kb=(190, 0), stun=.32, lunge=210, poses=('w_cross', 'h_cross'), hs=.045, shake=3),
    'hook': A(su=.08, ac=.07, rc=.13, dmg=11, hb=(0, -95, 78, 46), kb=(260, -60), stun=.36, lunge=230, poses=('w_hook', 'h_hook'), hs=.055, shake=4),
    'spin': A(su=.11, ac=.09, rc=.22, dmg=15, hb=(-70, -98, 148, 54), kb=(560, -260), stun=.6, lunge=200, poses=('w_spin', 'h_spin'), hs=.08, shake=6, kind='heavy', fin=True, tip='ff', snd='whoosh_h'),
    'kick': A(su=.10, ac=.08, rc=.20, dmg=13, hb=(6, -70, 92, 40), kb=(430, -90), stun=.5, lunge=240, gb=True, poses=('w_kick', 'h_kick'), kind='heavy', hs=.07, shake=5, tip='ff', snd='whoosh_h'),
    'axe': A(su=.16, ac=.08, rc=.24, dmg=17, hb=(0, -125, 74, 100), kb=(160, 120), stun=.7, gb=True, kind='heavy', poses=('w_axe', 'h_axe'), hs=.09, shake=7, tip='ff', snd='whoosh_h'),
    'round': A(su=.13, ac=.09, rc=.22, dmg=16, hb=(-30, -98, 130, 50), kb=(520, -180), stun=.65, gb=True, kind='heavy', poses=('w_round', 'h_round'), hs=.09, shake=7, tip='ff', snd='whoosh_h'),
    'breaker': A(su=.22, ac=.10, rc=.36, dmg=24, aoe=160, kb=(560, -360), stun=1.0, gb=True, kind='heavy', launch=True, poses=('w_break', 'h_break'), hs=.12, shake=12, ring=True, fin=True, snd='whoosh_h'),
    'launcher': A(su=.11, ac=.08, rc=.26, dmg=9, hb=(6, -150, 68, 130), kb=(60, -860), stun=1.1, launch=True, poses=('w_up', 'h_up'), hs=.06, shake=4, fin=True),
    'sweep': A(su=.12, ac=.09, rc=.30, dmg=10, hb=(0, -36, 124, 36), kb=(140, -250), stun=.8, down=True, poses=('w_sweep', 'h_sweep'), lunge=260, kind='heavy', hs=.06, shake=4, tip='ff', fin=True),
    'air_a': A(air=True, su=.05, ac=.07, rc=.09, dmg=6, hb=(4, -98, 66, 62), kb=(70, -200), stun=.6, poses=('w_air', 'h_air'), hs=.04, shake=2),
    'air_b': A(air=True, su=.06, ac=.07, rc=.10, dmg=7, hb=(4, -98, 70, 62), kb=(90, -220), stun=.6, poses=('w_air', 'h_air'), hs=.045, shake=3),
    'air_c': A(air=True, su=.08, ac=.08, rc=.14, dmg=10, hb=(0, -110, 84, 90), kb=(120, 620), stun=.8, poses=('w_axe', 'h_axe'), hs=.08, shake=6, kind='heavy', fin=True, tip='ff'),
    'air_kick': A(air=True, su=.09, ac=.08, rc=.16, dmg=11, hb=(6, -74, 86, 56), kb=(360, -80), stun=.5, poses=('w_airk', 'h_airk'), kind='heavy', hs=.07, shake=5, tip='ff', fin=True, snd='whoosh_h'),
    'dive': A(air=True, su=.09, ac=2.0, rc=.22, dmg=16, hb=(-14, -50, 96, 76), kb=(220, 300), stun=.8, poses=('w_airk', 'h_dive'), kind='heavy', hs=.1, shake=10, tip='ff', dive=True, fin=True, snd='whoosh_h'),
    'counter': A(su=.07, ac=.12, rc=.28, dmg=30, hb=(-30, -104, 160, 106), kb=(700, -380), stun=1.2, launch=True, gb=True, kind='heavy', poses=('w_counter', 'h_counter'), hs=.16, shake=14, lunge=520, ring=True, fin=True, snd='whoosh_h'),
}
FINISH = {k for k, v in ATK.items() if v['fin']}


# ============================================================ fighter base
class Fighter:
    def __init__(self, x, y, col, sc=1.0):
        self.x, self.y = x, y
        self.vx = self.vy = 0.0
        self.f = 1
        self.col = col
        self.sc = sc
        self.on_ground = True
        self.hp = self.maxhp = 100
        self.pose = dict(POSES['idle'])
        self.t = random.random() * 5
        self.hitstop = 0.0
        self.flash = 0.0
        self.drop = 0.0
        self.grav = 1.0
        self.pts = None
        self.trail = []
        self.walk = 0.0

    def hurtbox(self):
        return (self.x - 18 * self.sc, self.y - 102 * self.sc, 36 * self.sc, 102 * self.sc)

    def center(self):
        return (self.x, self.y - 62 * self.sc)

    def physics(self, g, dt):
        self.vy = min(self.vy + 2400 * self.grav * dt, 1700)
        self.x += self.vx * dt
        ny = self.y + self.vy * dt
        self.drop -= dt
        target = GROUND
        if self.vy >= 0 and self.drop <= 0:
            for px, py, pw in g.platforms:
                if px - 6 <= self.x <= px + pw + 6 and self.y <= py + 3 and ny >= py and py < target:
                    target = py
        landed = False
        if ny >= target and self.vy >= 0:
            ny = target
            landed = True
            self.vy = 0
        was = self.on_ground
        self.y = ny
        self.on_ground = landed
        lo, hi = g.bounds
        self.x = clamp(self.x, lo + self.bx, hi - self.bx)
        return landed and not was

    bx = 30

    def pose_to(self, target, dt, k=26):
        a = 1 - math.exp(-dt * k)
        self.pose = lerp_pose(self.pose, target, a)

    def draw_trail(self, fx, camx, col):
        n = len(self.trail)
        for i in range(1, n):
            a = i / n
            x0, y0 = self.trail[i - 1]
            x1, y1 = self.trail[i]
            pygame.draw.line(fx, shade(col, a * .9), (x0 - camx, y0), (x1 - camx, y1), max(2, int(9 * a)))


# ============================================================ player
class Player(Fighter):
    bx = 34

    def __init__(self, g, x):
        super().__init__(x, GROUND, CYAN)
        self.up = g.save.d['upgrades']
        self.maxhp = 100 + 15 * self.up['vit']
        self.hp = self.maxhp
        self.heat = 0.0
        self.guard = 100.0
        self.act = None
        self.act_t = 0.0
        self.atk = None
        self.atk_j = 'good'
        self.hit_ids = set()
        self.hit_any = False
        self.step = 0
        self.air_step = 0
        self.chain = 0.0
        self.buf = {}
        self.inv = 0.0
        self.counter_t = 0.0
        self.dodge_cd = 0.0
        self.par_t = 0.0
        self.par_cd = 0.0
        self.par_grade = 'good'
        self.block = False
        self.jumps = 2
        self.coyote = 0.0
        self.air_dodge = True
        self.dead = False
        self.hurt_t = 0.0
        self.ghosts = []
        self.ghost_t = 0.0
        self.scarf = [(x, GROUND - 90)] * 7
        self.special_done = False
        self.su = self.ac = self.rc = 0.1
        self.dive_landed = False
        self.bob = 0.0
        self.prev_ground = True

    # ---- input
    def press(self, g, action):
        ct = g.music.t() - g.save.s['offset'] / 1000.0
        pw, gw = g.win()
        grade, off = g.music.judge(ct, pw, gw)
        self.buf[action] = (grade, off, g.now)

    # ---- helpers
    def hurtbox(self):
        return (self.x - 16, self.y - 102, 32, 102)

    def can_act(self):
        return self.act is None

    def start_dodge(self, g, grade, dirx):
        self.act = 'dodge'
        self.act_t = 0
        d = dirx or -self.f
        perfect = grade == 'perfect'
        self.vx = d * (720 if perfect else 620)
        self.inv = .2 + (.1 if perfect else 0)
        self.dodge_cd = .2 if perfect else .38
        self.par_t = 0
        if not self.on_ground:
            self.air_dodge = False
            self.vy = -120
        g.sfx('pdodge' if perfect else 'dodge', .8)
        g.rhythm(grade, self.x, self.y - 130, 'dodge')
        g.particles.dust(self.x, self.y, 5)
        self.ghost_t = 0

    def start_attack(self, g, name, grade, chained):
        a = ATK[name]
        self.act = 'atk'
        self.atk = name
        self.act_t = 0
        self.atk_j = grade
        self.hit_ids = set()
        self.hit_any = False
        self.dive_landed = False
        self.su = a['su'] * {'perfect': .75, 'good': 1.0, 'off': 1.1}[grade]
        self.ac = a['ac']
        self.rc = a['rc'] * {'perfect': .85, 'good': 1.0, 'off': 1.4}[grade]
        # face intent / nearest enemy assist
        dx = g.held_dir()
        if dx:
            self.f = dx
        else:
            best = None
            for e in g.enemies:
                d = e.x - self.x
                if e.state not in ('dead', 'spawn') and abs(d) < 240 and (best is None or abs(d) < abs(best)):
                    best = d
            if best is not None:
                self.f = sign(best)
        if a['air']:
            self.vy = min(self.vy, -40) if not a['dive'] else 950
            self.vx = self.f * (a['lunge'] or 60) if not a['dive'] else self.f * 260
        else:
            self.vx = self.f * a['lunge']
        if name == 'counter':
            tgt = None
            for e in g.enemies:
                if e.state not in ('dead', 'spawn') and (tgt is None or abs(e.x - self.x) < abs(tgt.x - self.x)):
                    tgt = e
            if tgt and abs(tgt.x - self.x) < 520:
                self.f = sign(tgt.x - self.x) or self.f
                self.x = tgt.x - self.f * 70
            self.counter_t = 0
        if a['air']:
            self.air_step += 1
        else:
            self.step += 1
        if grade == 'perfect':
            g.particles.ring(self.x + self.f * 30, self.y - 80, GOLD, 8, 40, .25, 3)
        g.sfx(a['snd'], .7 + (.2 if grade == 'perfect' else 0))
        g.rhythm(grade, self.x, self.y - 135, 'atk')

    def pick_attack(self, g, kind, up, down):
        if self.counter_t > 0:
            return 'counter'
        if not self.on_ground:
            if kind == 'heavy':
                return 'dive' if (down and g.unlocked('dive')) else 'air_kick'
            return ('air_a', 'air_b', 'air_c')[min(self.air_step, 2)]
        if kind == 'light':
            if up and g.unlocked('launcher'):
                return 'launcher'
            return ('jab', 'cross', 'hook', 'spin')[min(self.step, 3)]
        if down:
            return 'sweep'
        return ('kick', 'axe', 'round', 'breaker')[min(self.step, 3)]

    def try_attack(self, g, kind, up, down):
        grade = self.buf[kind][0]
        chained = self.act == 'atk' or self.chain > 0
        if not chained:
            self.step = 0
            if self.on_ground:
                self.air_step = 0
        name = self.pick_attack(g, kind, up, down)
        del self.buf[kind]
        self.start_attack(g, name, grade, chained)

    def do_jump(self, g):
        if self.jumps <= 0:
            return False
        if self.on_ground or self.coyote > 0:
            self.vy = -830
            g.particles.dust(self.x, self.y, 4)
        else:
            self.vy = -740
            g.particles.ring(self.x, self.y - 10, (150, 200, 255), 6, 34, .25, 2)
        self.jumps -= 1
        self.on_ground = False
        self.coyote = 0
        self.drop = 0
        g.sfx('jump', .6)
        self.buf.pop('jump', None)
        return True

    # ---- update
    def update(self, g, dt):
        self.t += dt
        now = g.now
        for k in [k for k, v in self.buf.items() if now - v[2] > .16]:
            del self.buf[k]
        self.inv = max(0, self.inv - dt)
        self.counter_t -= dt
        self.dodge_cd -= dt
        self.chain -= dt
        self.flash -= dt
        self.par_t -= dt
        self.par_cd -= dt
        self.coyote -= dt
        self.hurt_t -= dt
        self.ghost_t -= dt
        if self.dead:
            self.vx *= .96
            self.physics(g, dt)
            self.pose_to(POSES['down'] if self.on_ground else POSES['flail'], dt, 12)
            return
        if self.hitstop > 0:
            self.hitstop -= dt
            return
        dirx = g.held_dir()
        up, down = g.held('up'), g.held('down')
        holdb = g.held('block')
        self.guard = min(100, self.guard + (14 if self.block else 30) * dt)

        if self.act == 'atk':
            self.upd_atk(g, dt, dirx, up, down)
        elif self.act == 'dodge':
            self.act_t += dt
            if self.ghost_t <= 0:
                self.ghosts.append([self.x, self.y, self.f, dict(self.pose), .35])
                self.ghost_t = .04
            if self.act_t >= .26:
                self.act = None
                self.vx *= .25
                # a buffered attack after dodge is allowed instantly
        elif self.act == 'hurt':
            self.act_t -= dt
            self.vx = approach(self.vx, 0, 1500 * dt)
            if self.act_t <= 0:
                self.act = None
        elif self.act == 'special':
            self.act_t += dt
            self.vx = 0
            self.vy = min(self.vy, 0) * .5
            if self.act_t >= .42 and not self.special_done:
                self.special_done = True
                g.do_special(self)
            if self.act_t >= .95:
                self.act = None
        if self.act is None:
            self.free(g, dt, dirx, up, down, holdb)
        landed = self.physics(g, dt)
        if self.on_ground:
            self.coyote = .09
            if landed or not self.prev_ground:
                self.jumps = 2
                self.air_dodge = True
                self.air_step = 0
                if landed:
                    g.sfx('land', .5)
                    g.particles.dust(self.x, self.y, 5)
        self.prev_ground = self.on_ground
        self.update_pose(g, dt)
        self.update_scarf(dt)
        # trail
        if self.act == 'atk' and self.pts and self.act_t > self.su * .5:
            tip = self.pts.get(ATK[self.atk]['tip'])
            if tip:
                self.trail.append((tip[0] + g.cam.x, tip[1]))
        if self.trail and (len(self.trail) > 7 or self.act != 'atk'):
            self.trail.pop(0)
        for gh in self.ghosts:
            gh[4] -= dt
        self.ghosts = [gh for gh in self.ghosts if gh[4] > 0]

    def free(self, g, dt, dirx, up, down, holdb):
        b = self.buf
        self.block = bool(holdb and self.on_ground)
        if 'block' in b and self.on_ground and self.par_cd <= 0:
            grade, off, t0 = b.pop('block')
            win = {'perfect': .27, 'good': .2, 'off': .13}[grade]
            self.par_t = max(.06, win - (g.now - t0))
            self.par_cd = .42
            self.par_grade = grade
            g.particles.ring(self.x + self.f * 26, self.y - 80, WHITE if grade != 'perfect' else GOLD, 6, 30, .2, 2)
            g.sfx('tick', .3)
        elif 'block' in b:
            b.pop('block', None)
        blocking = self.block or self.par_t > 0
        if dirx and not blocking:
            self.f = dirx
        maxv = 330 * (.45 if blocking else 1)
        acc = 3200 if self.on_ground else 1900
        if dirx:
            self.vx = approach(self.vx, dirx * maxv, acc * dt)
            self.walk += abs(self.vx) * dt * .045
        else:
            self.vx = approach(self.vx, 0, (3000 if self.on_ground else 700) * dt)
        # actions (priority)
        if 'dodge' in b and self.dodge_cd <= 0 and (self.on_ground or self.air_dodge):
            grade = b.pop('dodge')[0]
            self.start_dodge(g, grade, dirx)
            return
        if 'special' in b:
            grade = b.pop('special')[0]
            if self.heat >= 100 and g.unlocked('special'):
                self.act = 'special'
                self.act_t = 0
                self.inv = 1.2
                self.heat = 0
                self.special_done = False
                self.special_grade = grade
                g.sfx('special')
                g.rhythm(grade, self.x, self.y - 135, 'special')
                g.freeze(.12)
                return
        for kind in ('light', 'heavy'):
            if kind in b:
                self.try_attack(g, kind, up, down)
                return
        if 'jump' in b:
            if down and self.on_ground and any(px - 6 <= self.x <= px + pw + 6 and abs(self.y - py) < 4 for px, py, pw in g.platforms):
                self.drop = .25
                self.y += 4
                self.on_ground = False
                b.pop('jump', None)
            else:
                self.do_jump(g)
        if not g.held('jump') and self.vy < -320:
            self.vy *= .55

    def upd_atk(self, g, dt, dirx, up, down):
        a = ATK[self.atk]
        self.act_t += dt
        t = self.act_t
        su, ac, rc = self.su, self.ac, self.rc
        b = self.buf
        if a['dive']:
            if t < su:
                self.vy = min(self.vy, 60)
            elif not self.dive_landed:
                self.vy = 1000
                self.vx = self.f * 240
                if self.on_ground and t > su + .03:
                    self.dive_landed = True
                    self.act_t = su + ac
                    t = self.act_t
                    g.shockwave(self.x, self.y, 150, 12, self)
                    g.shake(14)
                    g.sfx('boom', .8)
        if a['air']:
            self.grav = .35 if (t < su + ac and not a['dive']) else 1.0
            if self.on_ground and t > su + .02 and not a['dive']:
                self.act = None
                self.grav = 1.0
                return
        else:
            self.grav = 1.0
        if t >= su + ac + rc:
            self.act = None
            self.grav = 1.0
            self.chain = .42
            if self.atk in FINISH:
                self.step = 0
                self.chain = 0
            return
        if t < su:
            phase = 0
        elif t < su + ac:
            phase = 1
            self.check_hits(g, a)
        else:
            phase = 2
        if phase >= 1 and not a['dive']:
            self.vx = approach(self.vx, 0, 2200 * dt)
        # cancels
        if 'dodge' in b and self.dodge_cd <= 0 and (phase == 2 or (phase == 1 and self.hit_any)) and (self.on_ground or self.air_dodge):
            self.grav = 1.0
            self.start_dodge(g, b.pop('dodge')[0], dirx)
            return
        if phase == 2 and 'block' in b and self.on_ground:
            self.act = None
            self.grav = 1.0
            return
        if self.hit_any and 'jump' in b and phase >= 1 and self.jumps > 0:
            self.act = None
            self.grav = 1.0
            self.do_jump(g)
            return
        if phase == 2 and (t - su - ac) >= rc * a['cf']:
            for kind in ('light', 'heavy'):
                if kind in b:
                    self.grav = 1.0
                    self.try_attack(g, kind, up, down)
                    return

    def check_hits(self, g, a):
        if a['aoe']:
            cx, cy = self.x, self.y - 50
            r = a['aoe']
            targets = [e for e in g.enemies if id(e) not in self.hit_ids and e.state not in ('dead', 'spawn')
                       and abs(e.center()[0] - cx) < r and abs(e.center()[1] - cy) < r * .8]
            if not self.hit_ids and a['ring']:
                g.particles.ring(self.x, self.y - 10, GOLD, 10, r, .35, 6)
                g.particles.ring(self.x, self.y - 10, WHITE, 6, r * .7, .25, 3)
        else:
            hb = hbox(self.x, self.y, self.f, a['hb'])
            targets = [e for e in g.enemies if id(e) not in self.hit_ids and e.state not in ('dead', 'spawn') and ov(hb, e.hurtbox())]
            for p in g.projs:
                if not p.friendly and p.kind in ('bullet', 'disc', 'note') and id(p) not in self.hit_ids and ov(hb, p.rect()):
                    self.hit_ids.add(id(p))
                    p.reflect(g, self)
                    g.sfx('reflect')
            for pr in g.props:
                if id(pr) not in self.hit_ids and ov(hb, pr.rect()):
                    self.hit_ids.add(id(pr))
                    pr.hit(g, self.atk_j == 'perfect')
                    self.hit_any = True
        for e in targets:
            self.hit_ids.add(id(e))
            self.land_hit(g, e, a)

    def land_hit(self, g, e, a):
        grade = self.atk_j
        perfect = grade == 'perfect'
        jm = {'perfect': 1.5, 'good': 1.1, 'off': .75}[grade]
        counter = self.atk == 'counter'
        dmg = a['dmg'] * (1 + .08 * self.up['pow']) * jm * (1 + min(g.groove, 20) * .01)
        heavy = a['kind'] == 'heavy'
        sgn = sign(e.x - self.x) or self.f
        hit = dict(dmg=dmg, kb=(a['kb'][0] * (sgn if a['aoe'] else self.f), a['kb'][1]), stun=a['stun'] * (1.25 if perfect else 1),
                   kind=a['kind'], gb=a['gb'], launch=a['launch'], down=a['down'],
                   poise=a['dmg'] * (3 if heavy else 1.6) * (1.5 if perfect else 1), grade=grade, perfect=perfect,
                   counter=counter, from_x=self.x, f=self.f, spike=a['kb'][1] > 400)
        res = e.receive(g, hit)
        cx, cy = e.center()
        if res == 'miss':
            return
        self.hit_any = True
        ang = math.atan2(a['kb'][1] * .2, a['kb'][0] * self.f + .001)
        if res == 'blocked':
            self.hitstop = .05
            g.sfx('block', .8)
            g.particles.burst(cx + sgn * -20, cy - 10, (200, 220, 255), 8, 300, ang + (math.pi if sgn > 0 else 0), 1.4, .25, 2)
            g.shake(3)
            g.combo_break_soft()
            return
        hs = a['hs'] * (1.6 if perfect else 1) * (1.5 if counter else 1)
        self.hitstop = hs
        col = GOLD if perfect else (WHITE if heavy else CYAN)
        g.hit_fx(cx, cy, ang, heavy, perfect, col)
        g.sfx('hit_p' if perfect else ('hit_h' if heavy else random.choice(('hit_l', 'hit_l2'))), 1.0)
        g.shake(a['shake'] * (1.4 if perfect else 1))
        if heavy or perfect:
            g.zoom_punch(.012 if not counter else .03)
        if a['kind'] == 'heavy' and perfect:
            g.flash(GOLD, 40)
        g.register_hit(res == 'dead', grade, dmg, cx, cy)
        gain = {'perfect': 7, 'good': 3.5, 'off': 1.2}[grade] * (1 + .15 * self.up['grv'])
        self.heat = min(100, self.heat + gain * (1.5 if counter else 1))
        e.popup_dmg(g, dmg, perfect)

    # ---- taking damage
    def take_hit(self, g, src, h):
        if self.dead or self.act == 'special':
            return None
        if self.inv > 0:
            if self.act == 'dodge':
                self.evade_reward(g, src, h)
                return 'evade'
            return None
        sx = getattr(src, 'x', self.x)
        front = (sx - self.x) * self.f >= -24
        kbdir = sign(self.x - sx) or -self.f
        if self.par_t > 0 and h['parry'] and front and self.on_ground and self.act is None:
            self.parry_reward(g, src, h)
            return 'parry'
        if self.block and h['blockable'] and front and self.act is None:
            dmg = h['dmg'] * .2 * g.diff['edmg']
            self.hp -= dmg
            self.guard -= h['dmg'] * 2.6
            self.vx = kbdir * 260
            self.hitstop = .05
            g.sfx('block', .9)
            g.shake(3)
            cx = self.x + self.f * 26
            g.particles.burst(cx, self.y - 80, (200, 220, 255), 8, 320, 0 if kbdir > 0 else math.pi, 1.6, .25, 2)
            if self.guard <= 0:
                self.guard = 60
                self.hurt(g, h, kbdir, dmg=0, guardbreak=True)
                g.popup('GUARD BREAK', self.x, self.y - 140, RED, 26)
            if self.hp <= 0:
                self.die(g)
            return 'block'
        self.hurt(g, h, kbdir)
        return 'hit'

    def hurt(self, g, h, kbdir, dmg=None, guardbreak=False):
        d = h['dmg'] * g.diff['edmg'] if dmg is None else dmg
        self.hp -= d
        self.act = 'hurt'
        self.act_t = h.get('stun', .3) + .05
        self.atk = None
        self.grav = 1.0
        self.inv = .85
        self.block = False
        self.par_t = 0
        self.vx = kbdir * h['kb'][0] * .8
        if h['kb'][1] < -200 or not self.on_ground:
            self.vy = min(h['kb'][1] * .7, -260)
            self.on_ground = False
        self.hitstop = .09
        self.flash = .12
        g.hurt_fx(self, d)
        if self.hp <= 0:
            self.die(g)

    def die(self, g):
        if self.dead:
            return
        self.dead = True
        self.hp = 0
        self.act = None
        self.vy = -500
        g.player_died()

    def evade_reward(self, g, src, h):
        g.stats['evades'] += 1
        self.counter_t = 1.0
        self.heat = min(100, self.heat + 10 * (1 + .15 * self.up['grv']))
        g.popup('EVADE!', self.x, self.y - 160, (140, 255, 200), 30)
        g.sfx('pdodge')
        g.particles.ring(self.x, self.y - 60, (140, 255, 200), 10, 90, .35, 3)
        g.rhythm('perfect', self.x, self.y - 135, 'evade')
        g.score_add(150, self.x, self.y - 180)
        g.zoom_punch(.02)
        g.slowfreeze(src)

    def parry_reward(self, g, src, h):
        perfect = self.par_grade == 'perfect'
        g.stats['parries'] += 1
        self.par_t = 0
        self.counter_t = 1.2
        self.hitstop = .12
        self.heat = min(100, self.heat + (14 if perfect else 8) * (1 + .15 * self.up['grv']))
        heal = self.up['rec'] * 2
        if heal:
            self.hp = min(self.maxhp, self.hp + heal)
        g.sfx('pparry' if perfect else 'parry')
        px = self.x + self.f * 34
        g.particles.burst(px, self.y - 85, GOLD if perfect else WHITE, 22, 520, 0, math.tau, .4, 3, 100)
        g.particles.ring(px, self.y - 85, WHITE, 6, 90 if perfect else 60, .3, 4)
        g.popup('PERFECT PARRY!' if perfect else 'PARRY!', self.x, self.y - 165, GOLD if perfect else WHITE, 32)
        g.shake(6)
        g.zoom_punch(.02)
        g.flash(WHITE, 60 if perfect else 30)
        g.rhythm(self.par_grade, self.x, self.y - 135, 'parry')
        g.score_add(200 if perfect else 100, self.x, self.y - 190)
        if hasattr(src, 'on_parried'):
            src.on_parried(g, perfect)
            src.hitstop = .12

    # ---- visuals
    def update_pose(self, g, dt):
        if self.act == 'atk':
            a = ATK[self.atk]
            w, h = POSES[a['poses'][0]], POSES[a['poses'][1]]
            base = POSES['fall'] if not self.on_ground else POSES['idle']
            t = self.act_t
            su, ac, rc = self.su, self.ac, self.rc
            if t < su:
                p = t / su
                tgt = lerp_pose(base, w, ease_out(p * 2)) if p < .5 else lerp_pose(w, h, smooth((p - .5) * 2) * .35)
            elif t < su + ac:
                tgt = lerp_pose(w, h, smooth((t - su) / .04))
            else:
                tgt = lerp_pose(h, base, smooth((t - su - ac) / rc))
            self.pose_to(tgt, dt, 60)
            return
        if self.act == 'dodge':
            tgt = POSES['dodge']
        elif self.act == 'hurt':
            tgt = POSES['hurt']
        elif self.act == 'special':
            tgt = lerp_pose(POSES['w_special'], POSES['h_special'], smooth((self.act_t - .3) / .15))
        elif not self.on_ground:
            tgt = POSES['jump'] if self.vy < 0 else POSES['fall']
        elif self.par_t > 0:
            tgt = POSES['parry']
        elif self.block:
            tgt = POSES['block']
        elif abs(self.vx) > 40:
            tgt = run_pose(self.walk * 1.0, min(1, abs(self.vx) / 330))
            if self.vx * self.f < 0:
                tgt = dict(tgt)
                tgt['lean'] = 4
        else:
            tgt = POSES['idle']
        self.pose_to(tgt, dt, 30)

    def update_scarf(self, dt):
        pts = self.scarf
        if self.pts:
            hx, hy = self.pts['hc']
            anchor = (hx + self._camx, hy - 2)
        else:
            anchor = (self.x, self.y - 100)
        pts[0] = anchor
        k = min(1, dt * 20)
        for i in range(1, len(pts)):
            px, py = pts[i - 1]
            qx, qy = pts[i]
            tx = px - self.f * 7 - self.vx * .014
            ty = py + 3 + i * .6 - min(self.vy, 0) * .004 + self.vy * .006
            pts[i] = (qx + (tx - qx) * k, qy + (ty - qy) * k)

    _camx = 0

    def draw(self, surf, fx, camx, ct, phase):
        self._camx = camx
        gfx.shadow(surf, self.x - camx, GROUND - 2 if self.y >= GROUND - 1 else self._shadow_y(), 70, 1)
        # afterimages
        for x, y, f, pose, life in self.ghosts:
            draw_stick(fx, x - camx, y, f, pose, shade(CYAN, life * 1.3), 1.0, 0, (0, 0, 0))
        blink = self.inv > 0 and self.act == 'hurt' or (self.inv > 0 and self.act is None and int(self.t * 30) % 2 == 0 and self.hurt_t > -1 and self.inv < .85 and self.act != 'dodge')
        if blink and not self.dead:
            pass
        bob = 0
        if self.act is None and self.on_ground and abs(self.vx) < 40:
            bob = -3 * (1 - phase) ** 3
        flash = clamp(self.flash * 8, 0, 1)
        self.pts = draw_stick(surf, self.x - camx, self.y + bob, self.f, self.pose, self.col, 1.0, flash)
        # scarf
        sc = [(x - camx, y) for x, y in self.scarf]
        for i in range(1, len(sc)):
            w = max(2, 6 - i)
            pygame.draw.line(surf, (255, 60, 150), sc[i - 1], sc[i], w)
        # glow
        cx, cy = self.pts['pel'][0], self.pts['pel'][1] - 30
        inten = .28 + .25 * (1 - phase) ** 2 + (.35 if self.act == 'special' else 0)
        blit_glow(fx, cx, cy, 70, shade(self.col, inten))
        if self.trail:
            self.draw_trail(fx, camx, GOLD if self.atk_j == 'perfect' else CYAN)
        if self.counter_t > 0:
            blit_glow(fx, cx, cy, 90 + 10 * math.sin(self.t * 20), (120, 90, 20))
        if self.par_t > 0:
            pygame.draw.circle(fx, (200, 200, 120), (int(cx + self.f * 30), int(cy - 20)), 40, 3)

    def _shadow_y(self):
        best = GROUND - 2
        return best


# ============================================================ enemies
def S(**k):
    d = dict(kind='melee', dmg=8, hb=(0, -92, 66, 36), blockable=True, kb=(170, 0), stun=.3, lunge=0,
             pose='h_jab', sfx='whoosh', act=.11)
    d.update(k)
    return d


EA = {
    'punch': dict(wind=.42, rec=.34, wpose='w_jab', rng=80, hits=[(0, S(dmg=8, lunge=140))]),
    'combo': dict(wind=.5, rec=.42, wpose='w_jab', rng=80, hits=[(0, S(dmg=7, lunge=120)), (1, S(dmg=9, pose='h_hook', hb=(0, -95, 74, 44), kb=(260, -40), lunge=140))]),
    'bash': dict(wind=.65, rec=.5, wpose='w_bash', rng=95, hits=[(0, S(dmg=12, pose='h_bash', hb=(0, -100, 92, 90), kb=(380, -40), stun=.4, lunge=200))]),
    'flurry': dict(wind=.36, rec=.4, wpose='w_jab', rng=150, hits=[(0, S(dmg=5, lunge=280)), (.5, S(dmg=5, pose='h_cross', lunge=100)), (1, S(dmg=6, pose='h_hook', kb=(260, -30)))]),
    'shot': dict(wind=.5, rec=.45, wpose='w_gun', rng=560, hits=[(0, S(kind='proj', dmg=8, pose='h_gun', spd=640))]),
    'burst': dict(wind=.6, rec=.6, wpose='w_gun', rng=560, hits=[(0, S(kind='proj', dmg=7, pose='h_gun', spd=620)), (.5, S(kind='proj', dmg=7, pose='h_gun', spd=620)), (1, S(kind='proj', dmg=7, pose='h_gun', spd=620))]),
    'charge': dict(wind=.95, rec=.2, wpose='w_charge', armor=True, rng=460, hits=[(0, S(kind='charge', dmg=20, blockable=False, dur=.7, spd=780, hb=(-10, -100, 80, 100), kb=(600, -200), stun=.6, pose='h_charge'))]),
    'sync': dict(wind=.45, rec=.4, off=True, wpose='w_cross', rng=90, hits=[(0, S(dmg=7)), (1, S(dmg=7, pose='h_cross')), (1.5, S(dmg=9, pose='h_hook', kb=(260, -40)))]),
    'triple': dict(wind=.7, rec=.6, wpose='w_hook', armor=True, rng=100, hits=[(0, S(dmg=10)), (1, S(dmg=10, pose='h_hook')), (2, S(dmg=16, pose='h_kick', blockable=False, hb=(0, -80, 100, 60), kb=(520, -200), stun=.5))]),
    'slam': dict(wind=.9, rec=.8, wpose='w_break', armor=True, rng=110, hits=[(0, S(kind='slam', dmg=18, blockable=False, r=170, pose='h_break', kb=(360, -420), stun=.6))]),
}

ET = {
    'g': dict(name='THUG', hp=44, spd=175, sc=1.0, col=(255, 70, 110), poise=1, prefer=170, reach=70, atks=(('punch', 3), ('combo', 2)), cd=(.5, 1.3)),
    'd': dict(name='GUARD', hp=78, spd=115, sc=1.08, col=(255, 170, 60), poise=25, prefer=190, reach=80, atks=(('bash', 1),), cd=(.9, 1.8), guard=True),
    'r': dict(name='RUNNER', hp=30, spd=330, sc=.92, col=(190, 255, 70), poise=1, prefer=210, reach=100, atks=(('flurry', 1),), cd=(.4, 1.0)),
    's': dict(name='GUNNER', hp=32, spd=150, sc=.98, col=(255, 120, 255), poise=1, prefer=470, reach=520, atks=(('shot', 3), ('burst', 1)), cd=(.8, 1.6), ranged=True),
    'c': dict(name='CHARGER', hp=96, spd=140, sc=1.2, col=(255, 100, 50), poise=40, prefer=300, reach=420, atks=(('charge', 1),), cd=(1.4, 2.4)),
    'y': dict(name='SYNCOPATOR', hp=52, spd=200, sc=1.0, col=(255, 235, 90), poise=1, prefer=200, reach=85, atks=(('sync', 1),), cd=(.5, 1.1)),
    'e': dict(name='ENFORCER', hp=230, spd=120, sc=1.35, col=(255, 60, 60), poise=70, prefer=180, reach=95, atks=(('triple', 2), ('slam', 1)), cd=(.8, 1.6), elite=True),
}
POINTS = {'g': 100, 'd': 200, 'r': 150, 's': 150, 'c': 300, 'y': 250, 'e': 800}


class Enemy(Fighter):
    is_boss = False

    def __init__(self, g, code, x):
        cfg = ET[code]
        super().__init__(x, GROUND, cfg['col'], cfg['sc'])
        self.code = code
        self.cfg = cfg
        self.maxhp = self.hp = cfg['hp'] * g.diff['hp'] * g.hp_scale
        self.maxpoise = self.poise = cfg['poise']
        self.state = 'spawn'
        self.st = 0.0
        self.f = -1 if x > g.player.x else 1
        self.cd = random.uniform(.6, 1.6)
        self.plan = None
        self.token = False
        self.strike_t = 0
        self.wprog = 0
        self.strafe = random.uniform(0, 6.28)
        self.ring = random.random()
        self.juggle = 0
        self.spec = None
        self.active_until = 0
        self.did = True
        self.charge_end = 0
        self.dead_t = 0
        self.air_t = 0
        self.broken = 0
        self.force = None
        self.armored = False
        self.show_hp = 0
        self.age = 0
        self.armor_plan = False
        self.no_token = False

    # -- geometry
    def hurtbox(self):
        s = self.sc
        if self.state == 'down':
            return (self.x - 46 * s, self.y - 34 * s, 92 * s, 34 * s)
        return (self.x - 18 * s, self.y - 102 * s, 36 * s, 102 * s)

    def center(self):
        return (self.x, self.y - (20 if self.state == 'down' else 62 * self.sc))

    def hb_world(self, hb):
        s = self.sc
        return hbox(self.x, self.y, self.f, (hb[0] * s, hb[1] * s, hb[2] * s, hb[3] * s))

    # -- update
    def update(self, g, dt):
        self.t += dt
        self.age += dt
        self.flash -= dt
        self.cd -= dt
        self.strike_t -= dt
        self.broken -= dt
        self.show_hp -= dt
        if self.hitstop > 0:
            self.hitstop -= dt
            return
        st = self.state
        if st == 'spawn':
            self.st += dt
            if self.st > .55:
                self.state = 'idle'
            return
        if st == 'idle':
            self.ai(g, dt)
        elif st == 'attack':
            self.upd_attack(g, dt)
        elif st in ('stagger', 'crash'):
            self.st -= dt
            self.vx = approach(self.vx, 0, 1200 * dt)
            if self.st <= 0:
                self.state = 'idle'
                self.cd = random.uniform(.2, .6)
        elif st == 'air':
            self.air_t += dt
            self.grav = 1 + self.juggle * .08
            if self.on_ground and self.air_t > .06:
                if self.vy == 0:
                    g.particles.dust(self.x, self.y, 6)
                    g.shake(3)
                self.state = 'down'
                self.st = .6
                self.grav = 1
                self.juggle = 0
        elif st == 'down':
            self.st -= dt
            self.vx = approach(self.vx, 0, 1600 * dt)
            if self.st <= 0:
                self.state = 'getup'
                self.st = .3
        elif st == 'getup':
            self.st -= dt
            if self.st <= 0:
                self.state = 'idle'
                self.cd = random.uniform(.2, .5)
        elif st == 'dead':
            self.dead_t -= dt
            self.vx = approach(self.vx, 0, 200 * dt)
        landed = self.physics(g, dt)
        if landed and st == 'dead':
            self.vy = 0
        if st != 'dead':
            self.separate(g, dt)
        self.regen(dt)
        self.update_pose(g, dt)

    def regen(self, dt):
        if self.state in ('idle', 'stagger') and self.poise < self.maxpoise:
            self.poise = min(self.maxpoise, self.poise + 9 * dt)

    def separate(self, g, dt):
        for o in g.enemies:
            if o is not self and o.state not in ('dead', 'spawn') and abs(o.x - self.x) < 44 and o.on_ground and self.on_ground:
                self.x += sign(self.x - o.x or random.choice((-1, 1))) * 120 * dt

    # -- AI
    def ai(self, g, dt):
        pl = g.player
        dx = pl.x - self.x
        ad = abs(dx)
        cfg = self.cfg
        spd = cfg['spd']
        if pl.dead:
            self.vx = approach(self.vx, 0, 900 * dt)
            return
        self.f = sign(dx) or self.f
        self.strafe += dt * (1.2 + self.ring)
        if not self.token and self.cd <= 0 and not self.no_token and g.request_token(self):
            self.token = True
        move = 0
        code = self.code
        if cfg.get('ranged'):
            if ad < 240:
                move = -sign(dx) * 1.35
            elif ad < cfg['prefer'] - 120:
                move = -sign(dx)
            elif ad > cfg['prefer'] + 130:
                move = sign(dx) * .8
            else:
                move = math.sin(self.strafe) * .25
            if self.token and self.cd <= 0 and 260 < ad < 700:
                self.begin_named(g, self.pick())
                return
        elif code == 'c':
            if self.token:
                if ad > 560:
                    move = sign(dx)
                elif ad < 330:
                    move = -sign(dx) * 1.1
                else:
                    self.begin_named(g, 'charge')
                    return
            else:
                move = self.hover(ad, dx, cfg)
        else:
            if self.token:
                if ad > cfg['reach'] * .85:
                    move = sign(dx)
                else:
                    self.begin_named(g, self.force or self.pick())
                    self.force = None
                    return
            else:
                move = self.hover(ad, dx, cfg)
        self.vx = approach(self.vx, move * spd, 2600 * dt)
        self.walk += abs(self.vx) * dt * .045

    def hover(self, ad, dx, cfg):
        tgt = cfg['prefer'] + self.ring * 140
        if ad > tgt + 30:
            return sign(dx) * .7
        if ad < tgt - 30:
            return -sign(dx) * .7
        return math.sin(self.strafe) * .3

    def pick(self):
        tot = sum(w for _, w in self.cfg['atks'])
        r = random.uniform(0, tot)
        for n, w in self.cfg['atks']:
            r -= w
            if r <= 0:
                return n
        return self.cfg['atks'][0][0]

    def begin_named(self, g, name):
        self.begin(g, EA[name])

    def begin(self, g, a, wind_mul=1.0):
        ct = g.music.t()
        minw = a['wind'] * g.diff['wind'] * wind_mul
        sub = 2 if a.get('off') else 1
        T0 = g.music.next_grid(ct + minw, sub, offbeat=a.get('off', False))
        beat = g.music.beat
        self.plan = dict(a=a, times=[T0 + b * beat for b, _ in a['hits']], specs=[s for _, s in a['hits']],
                         i=0, start=ct, end=0)
        self.state = 'attack'
        self.armor_plan = a.get('armor', False)
        self.cd = 9
        self.did = True
        self.charge_end = 0
        self.active_until = 0
        if not a['hits'][0][1]['blockable']:
            g.sfx('warn', .6)

    def finish(self, g):
        self.state = 'idle'
        self.plan = None
        self.armor_plan = False
        self.release(g)
        self.cd = random.uniform(*self.cfg['cd']) * (0.8 if g.diff['tok'] > 0 else 1.0)

    def release(self, g):
        if self.token:
            self.token = False
            g.release_token(self)

    def upd_attack(self, g, dt):
        p = self.plan
        ct = g.music.t()
        if ct < self.charge_end:
            sp = self.spec
            self.vx = self.f * sp['spd']
            if int(self.t * 40) % 3 == 0:
                g.particles.dust(self.x, self.y, 1)
            self.try_melee(g, sp, box=self.hb_world(sp['hb']))
            lo, hi = g.bounds
            if self.x <= lo + self.bx + 2 or self.x >= hi - self.bx - 2:
                self.crash(g)
                return
        elif self.charge_end and ct >= self.charge_end:
            self.charge_end = 0
            self.state = 'crash'
            self.st = .55
            self.vx *= .3
            self.plan = None
            self.armor_plan = False
            self.release(g)
            self.cd = 1.4
            return
        else:
            self.vx = approach(self.vx, 0, 1400 * dt)
        if ct < self.active_until and not self.did and self.spec and self.spec['kind'] == 'melee':
            self.try_melee(g, self.spec)
        if p['i'] < len(p['times']):
            nxt = p['times'][p['i']]
            prev = p['start'] if p['i'] == 0 else p['times'][p['i'] - 1]
            self.wprog = clamp((ct - prev) / max(.05, nxt - prev), 0, 1)
            if self.wprog < .75:
                self.f = sign(g.player.x - self.x) or self.f
            if ct >= nxt:
                self.fire(g, p['specs'][p['i']], ct)
                p['i'] += 1
                if p['i'] >= len(p['times']):
                    p['end'] = ct + p['a']['rec']
        elif ct >= p['end'] and ct >= self.charge_end and ct >= self.active_until:
            self.finish(g)

    def crash(self, g):
        self.charge_end = 0
        self.state = 'crash'
        self.st = 1.5
        self.vx = -self.f * 120
        self.plan = None
        self.armor_plan = False
        self.release(g)
        self.cd = 1.5
        g.shake(10)
        g.sfx('boom', .7)
        g.particles.burst(self.x + self.f * 30, self.y - 60, (255, 200, 100), 24, 500, math.pi if self.f > 0 else 0, 1.6, .5, 4)
        g.popup('OPEN!', self.x, self.y - 150 * self.sc, GOLD, 28)

    def hitdict(self, sp):
        return dict(dmg=sp['dmg'], kb=sp['kb'], stun=sp['stun'], blockable=sp['blockable'],
                    parry=sp.get('parry', sp['blockable']), kind=sp['kind'])

    def try_melee(self, g, sp, box=None):
        if self.did:
            return
        box = box or self.hb_world(sp['hb'])
        pl = g.player
        if ov(box, pl.hurtbox()):
            r = pl.take_hit(g, self, self.hitdict(sp))
            if r:
                self.did = True

    def fire(self, g, sp, ct):
        k = sp['kind']
        self.strike_t = .14
        self.spec = sp
        g.sfx(sp.get('sfx', 'whoosh'), .6)
        if k == 'melee':
            self.active_until = ct + sp['act']
            self.did = False
            self.vx = self.f * sp.get('lunge', 0)
        elif k == 'proj':
            self.shoot(g, sp)
        elif k == 'charge':
            self.charge_end = ct + sp['dur']
            self.did = False
        elif k == 'slam':
            r = sp['r'] * self.sc / 1.2
            g.shake(9)
            g.sfx('boom', .8)
            g.particles.ring(self.x, self.y - 6, (255, 120, 60), 10, r, .4, 6)
            g.particles.burst(self.x, self.y - 6, (255, 180, 80), 20, 500, -math.pi / 2, math.pi, .5, 3)
            pl = g.player
            if abs(pl.x - self.x) < r and pl.y > GROUND - 46:
                pl.take_hit(g, self, self.hitdict(sp))
        elif k == 'wave':
            for d in (-1, 1):
                g.projs.append(Projectile(self.x + d * 40, GROUND - 22, d * sp.get('spd', 430), 0, sp['dmg'], kind='wave', life=2.2, col=sp.get('col', (255, 140, 60))))
        else:
            self.fire_special(g, sp, ct)

    def fire_special(self, g, sp, ct):
        pass

    def shoot(self, g, sp, ang=0.0, col=(255, 120, 255), kind='bullet', spd=None):
        spd = spd or sp.get('spd', 600)
        px = self.x + self.f * 34 * self.sc
        py = self.y - 80 * self.sc
        pl = g.player
        aim = math.atan2((pl.y - 60) - py, pl.x - px)
        if kind == 'bullet' and self.code == 's':
            aim = 0 if self.f > 0 else math.pi
        a = aim + ang
        g.projs.append(Projectile(px, py, math.cos(a) * spd, math.sin(a) * spd, sp['dmg'], kind=kind, col=col))
        g.particles.burst(px, py, col, 6, 300, a, .6, .2, 2)
        g.sfx('shoot', .5)

    def on_parried(self, g, perfect):
        self.state = 'stagger'
        self.st = 1.6 if perfect else 1.1
        self.broken = self.st
        self.poise = 0
        self.plan = None
        self.charge_end = 0
        self.armor_plan = False
        self.release(g)
        self.cd = .6
        self.vx = -self.f * 150
        g.popup('BROKEN', self.x, self.y - 150 * self.sc, GOLD, 24)

    # -- receiving damage
    def popup_dmg(self, g, dmg, perfect):
        g.popup(str(int(dmg)), self.x + random.uniform(-14, 14), self.y - 120 * self.sc, GOLD if perfect else WHITE,
                26 if perfect else 20, vy=-90)

    def damage_mul(self, h):
        return 1.0

    def receive(self, g, h):
        if self.state in ('spawn', 'dead'):
            return 'miss'
        front = (h['from_x'] - self.x) * self.f > 0
        if (self.cfg.get('guard') and self.state == 'idle' and front and not h['gb'] and not h['launch'] and not h['down']):
            self.vx = -self.f * 170
            self.flash = .05
            self.hitstop = .05
            if random.random() < .55 and self.cd < 1.4:
                self.force = 'bash'
                self.cd = 0
                self.no_token = False
            return 'blocked'
        dmg = h['dmg'] * self.damage_mul(h) * (1.5 if self.broken > 0 else 1) * (.8 if self.state == 'down' else 1)
        self.hp -= dmg
        self.flash = .09
        self.hitstop = .05 + h.get('stun', 0) * .05
        self.show_hp = 2.5
        kbx, kby = h['kb']
        if self.hp <= 0:
            self.die(g, h)
            return 'dead'
        self.poise -= h['poise']
        armored = (self.armor_plan and self.state == 'attack') or (self.is_boss and self.armored)
        stagger = self.poise <= 0 or (not armored and self.cfg['poise'] <= 30 and not (self.cfg.get('guard') and self.state == 'idle'))
        if self.cfg.get('guard') and self.state == 'idle' and self.poise > 0:
            stagger = False
        if self.state == 'down':
            self.st = max(self.st, .35)
            self.vx += kbx * .2
            return 'hit'
        if stagger and not self.is_boss:
            self.release(g)
            self.plan = None
            self.charge_end = 0
            self.armor_plan = False
            self.poise = self.maxpoise * .6 if self.maxpoise > 1 else 1
            if h['launch'] or h['down'] or kby < -300 or not self.on_ground or h.get('spike'):
                if self.state != 'air':
                    self.air_t = 0
                    self.juggle = 0
                self.state = 'air'
                self.vy = kby if kby < 0 else (kby if h.get('spike') else -180)
                if h.get('spike'):
                    self.vy = 720
                self.vx = kbx
                self.juggle += 1
                self.on_ground = False
            else:
                self.state = 'stagger'
                self.st = max(h['stun'], self.st if self.state == 'stagger' else 0)
                self.vx = kbx * .9
        else:
            self.vx += kbx * .12
        return 'hit'

    def die(self, g, h):
        self.state = 'dead'
        self.dead_t = .8
        self.release(g)
        self.plan = None
        self.vx = h['kb'][0] * 1.1 + sign(self.x - h['from_x']) * 120
        self.vy = -560
        self.on_ground = False
        g.enemy_killed(self)

    def hazard_hit(self, g, dmg):
        if self.state in ('dead', 'spawn'):
            return
        h = dict(dmg=dmg, kb=(sign(self.x - g.player.x) * 200, -300), stun=.5, kind='light', gb=False, launch=True, down=False,
                 poise=99, grade='off', perfect=False, counter=False, from_x=self.x - 1, f=1)
        self.receive(g, h)

    # -- visuals
    def update_pose(self, g, dt):
        st = self.state
        pl = g.player
        if st == 'dead':
            p = dict(POSES['flail'])
            p['lean'] = (self.t * 900) % 360
            self.pose = p
            return
        if st == 'attack' and self.plan:
            a = self.plan['a']
            if self.strike_t > 0 and self.spec:
                tgt = POSES[self.spec.get('pose', 'h_jab')]
                self.pose_to(tgt, dt, 60)
            else:
                w = POSES[a['wpose']]
                tgt = lerp_pose(POSES['idle'], w, ease_out(self.wprog))
                self.pose_to(tgt, dt, 40)
            return
        if st in ('stagger', 'crash'):
            tgt = POSES['stagger'] if st == 'stagger' else POSES['getup']
        elif st == 'air':
            tgt = POSES['flail']
        elif st == 'down':
            tgt = POSES['down']
        elif st == 'getup':
            tgt = POSES['getup']
        elif st == 'spawn':
            tgt = POSES['spawn']
        elif abs(self.vx) > 40:
            tgt = run_pose(self.walk, min(1, abs(self.vx) / 300), 12)
        else:
            tgt = POSES['guard'] if self.cfg.get('guard') else POSES['idle']
        self.pose_to(tgt, dt, 22)

    def draw(self, surf, fx, camx, ct, phase):
        sx = self.x - camx
        if sx < -200 or sx > W + 200:
            return
        if self.state == 'spawn':
            k = self.st / .55
            pygame.draw.line(fx, shade(self.col, 1 - k * .3), (sx, self.y - 400 * (1 - k)), (sx, self.y), 6)
            blit_glow(fx, sx, self.y, 60 * k + 20, shade(self.col, .6))
            if k < .5:
                return
        gfx.shadow(surf, sx, GROUND - 2, 70 * self.sc, 1)
        sway = 0
        pulse = 1 - phase
        flash = clamp(self.flash * 9, 0, 1)
        col = self.col
        if self.broken > 0 and int(self.t * 20) % 2 == 0:
            col = mix(col, GOLD, .6)
        y = self.y - (2.5 * pulse ** 3 if self.state == 'idle' else 0)
        self.pts = gfx.draw_stick(surf, sx, y, self.f, self.pose, col, self.sc, flash)
        self.draw_extra(surf, fx, self.pts)
        cx, cy = self.pts['pel'][0], self.pts['pel'][1] - 30 * self.sc
        blit_glow(fx, cx, cy, 60 * self.sc, shade(col, .22 + .16 * pulse ** 2))
        # telegraph
        if self.state == 'attack' and self.plan and self.strike_t <= 0 and self.plan['i'] < len(self.plan['times']):
            sp = self.plan['specs'][self.plan['i']]
            tc = (255, 255, 255) if sp['blockable'] else (255, 50, 50)
            if sp['kind'] in ('wave', 'proj') and sp['blockable']:
                tc = (255, 200, 90)
            r = lerp(90, 16, ease_out(self.wprog)) * min(1.4, self.sc)
            pygame.draw.circle(fx, shade(tc, .35 + .65 * self.wprog), (int(cx + self.f * 30), int(cy - 10)), int(r), 3)
            blit_glow(fx, cx + self.f * 30, cy - 10, 30 + 40 * self.wprog, shade(tc, .25 * self.wprog))
            if not sp['blockable'] and sp['kind'] != 'proj':
                gfx.text(surf, '!', 34, (255, 60, 60), (sx, self.y - 128 * self.sc - 16))
        if self.show_hp > 0 and self.state != 'dead' and not self.is_boss:
            bw = 46
            bx, by = sx - bw / 2, self.y - 116 * self.sc
            pygame.draw.rect(surf, (10, 10, 20), (bx - 1, by - 1, bw + 2, 7))
            pygame.draw.rect(surf, (255, 90, 110), (bx, by, bw * clamp(self.hp / self.maxhp, 0, 1), 5))
        if self.trail:
            pass

    def draw_extra(self, surf, fx, p):
        c = self.col
        if self.code == 'd':
            hx, hy = p['fh']
            pygame.draw.rect(surf, (10, 10, 20), (hx - 8 + self.f * 6, hy - 38, 16, 76), border_radius=6)
            pygame.draw.rect(surf, c, (hx - 6 + self.f * 6, hy - 36, 12, 72), 3, border_radius=6)
            if self.state == 'idle':
                blit_glow(fx, hx + self.f * 6, hy, 40, shade(c, .3))
        elif self.code == 's':
            hx, hy = p['fh']
            pygame.draw.line(surf, (10, 10, 20), (hx, hy), (hx + self.f * 30, hy - 2), 8)
            pygame.draw.line(surf, c, (hx, hy), (hx + self.f * 30, hy - 2), 4)
        elif self.code in ('e', 'c'):
            hx, hy = p['hc']
            for d in (-1, 1):
                pygame.draw.line(surf, c, (hx + d * 8 * self.sc, hy - 8 * self.sc), (hx + d * 16 * self.sc, hy - 22 * self.sc), 4)
        elif self.code == 'y':
            hx, hy = p['hc']
            pygame.draw.circle(surf, c, (int(hx), int(hy - 16)), 5)
        elif self.code == 'r':
            hx, hy = p['hc']
            pygame.draw.line(surf, c, (hx - self.f * 10, hy), (hx - self.f * 30, hy + 8 + math.sin(self.t * 12) * 4), 3)

    def draw_fx(self, fx, camx):
        pass


# ============================================================ projectiles
class Projectile:
    def __init__(self, x, y, vx, vy, dmg, friendly=False, kind='bullet', life=3.0, grav=0.0, col=(255, 120, 255)):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.dmg = dmg
        self.friendly = friendly
        self.kind = kind
        self.life = life
        self.grav = grav
        self.col = col
        self.dead = False
        self.t = 0
        self.owner = None
        self.rot = 0

    def rect(self):
        if self.kind == 'wave':
            return (self.x - 28, GROUND - 46, 56, 46)
        r = 18 if self.kind == 'disc' else 10
        return (self.x - r, self.y - r, r * 2, r * 2)

    def reflect(self, g, by):
        self.friendly = True
        self.vx = -self.vx * 1.5
        self.vy = -self.vy * 1.5
        self.dmg *= 2.5
        self.life = 3
        g.particles.burst(self.x, self.y, WHITE, 12, 400)

    def update(self, g, dt):
        self.t += dt
        self.life -= dt
        self.rot += dt * 12
        self.vy += self.grav * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        lo, hi = g.bounds
        if self.life <= 0 or self.x < lo - 150 or self.x > hi + 150 or self.y > H + 50 or self.y < -200:
            self.dead = True
            return
        if self.kind == 'wave' and int(self.t * 60) % 4 == 0:
            g.particles.dust(self.x, GROUND - 6, 1, (255, 150, 60))
        if self.friendly:
            r = self.rect()
            for e in g.enemies:
                if e.state not in ('dead', 'spawn') and ov(r, e.hurtbox()):
                    h = dict(dmg=self.dmg, kb=(sign(self.vx) * 300, -300), stun=.8, kind='heavy', gb=True, launch=True, down=False,
                             poise=99, grade='good', perfect=False, counter=False, from_x=self.x, f=sign(self.vx), reflected=True)
                    res = e.receive(g, h)
                    if res != 'miss':
                        g.hit_fx(e.x, e.y - 70, 0, True, True, WHITE)
                        g.sfx('hit_h')
                        g.shake(6)
                        g.register_hit(res == 'dead', 'good', self.dmg, e.x, e.y - 70)
                        e.popup_dmg(g, self.dmg, True)
                        if hasattr(e, 'on_disc'):
                            e.on_disc(g)
                        self.dead = True
                        return
            return
        pl = g.player
        if ov(self.rect(), pl.hurtbox()):
            h = dict(dmg=self.dmg, kb=(220, -120), stun=.3, blockable=True, parry=(self.kind != 'wave'), kind='proj')
            if self.kind == 'wave':
                h['blockable'] = False
            r = pl.take_hit(g, self, h)
            if r == 'parry':
                self.reflect(g, pl)
            elif r in ('hit', 'block'):
                self.dead = True
                g.particles.burst(self.x, self.y, self.col, 10, 300)

    def draw(self, surf, fx, camx):
        sx = self.x - camx
        if self.kind == 'wave':
            pygame.draw.polygon(fx, shade(self.col, .9), [(sx - 28, GROUND), (sx, GROUND - 46), (sx + 28, GROUND)], 3)
            blit_glow(fx, sx, GROUND - 20, 44, shade(self.col, .5))
            return
        col = (120, 255, 200) if self.friendly else self.col
        if self.kind == 'disc':
            for i in range(4):
                a = self.rot + i * math.pi / 2
                pygame.draw.line(fx, col, (sx, self.y), (sx + math.cos(a) * 20, self.y + math.sin(a) * 20), 3)
            pygame.draw.circle(fx, col, (int(sx), int(self.y)), 20, 3)
            pygame.draw.circle(surf, (10, 10, 20), (int(sx), int(self.y)), 18)
            pygame.draw.circle(surf, col, (int(sx), int(self.y)), 18, 3)
            pygame.draw.circle(surf, col, (int(sx), int(self.y)), 4)
        else:
            pygame.draw.circle(surf, (10, 10, 20), (int(sx), int(self.y)), 10)
            pygame.draw.circle(surf, col, (int(sx), int(self.y)), 8)
            pygame.draw.circle(surf, WHITE, (int(sx), int(self.y)), 4)
            pygame.draw.line(fx, shade(col, .7), (sx, self.y), (sx - self.vx * .03, self.y - self.vy * .03), 5)
        blit_glow(fx, sx, self.y, 32, shade(col, .5))


# ============================================================ hazards & props
class Hazard:
    """Beat-locked floor/ceiling hazards."""

    def __init__(self, kind, x, w=70, period=4, phase=0, active=.5, dmg=12, h=120):
        self.kind, self.x, self.w, self.period, self.phase, self.active, self.dmg, self.h = kind, x, w, period, phase, active, dmg, h
        self.cool = {}
        self.was = False
        self.state_cache = (0, 0)
        self.state_t = 0

    def state(self, g):
        c = (g.music.bf() - self.phase) % self.period
        if c < self.active:
            return 2, c
        if c > self.period - 1:
            return 1, c - (self.period - 1)
        return 0, c

    def rect(self):
        if self.kind == 'laser':
            return (self.x - self.w / 2, 0, self.w, GROUND)
        return (self.x - self.w / 2, GROUND - self.h, self.w, self.h)

    def update(self, g, dt):
        s, c = self.state(g)
        self.state_cache = (s, c)
        self.state_t = c
        if s == 2 and not self.was:
            g.sfx('laser' if self.kind == 'laser' else 'boom', .4)
            g.shake(2)
        self.was = s == 2
        for k in list(self.cool):
            self.cool[k] -= dt
        if s != 2:
            return
        r = self.rect()
        pl = g.player
        if self.cool.get('p', 0) <= 0 and ov(r, pl.hurtbox()):
            h = dict(dmg=self.dmg, kb=(0, -420), stun=.35, blockable=False, parry=False, kind='hazard')
            if pl.take_hit(g, self, h):
                self.cool['p'] = .8
        for e in g.enemies:
            if e.state not in ('dead', 'spawn') and self.cool.get(id(e), 0) <= 0 and ov(r, e.hurtbox()):
                e.hazard_hit(g, self.dmg * 1.5)
                self.cool[id(e)] = .8

    def draw(self, surf, fx, camx, phase):
        sx = self.x - camx
        s, c = self.state_cache
        col = {'vent': (255, 130, 40), 'rail': (90, 200, 255), 'laser': (255, 60, 90)}[self.kind]
        if self.kind == 'laser':
            if s == 1:
                pygame.draw.line(fx, shade(col, .35 + .35 * math.sin(c * 30)), (sx, 0), (sx, GROUND), 2)
            elif s == 2:
                pygame.draw.rect(fx, col, (sx - self.w / 2, 0, self.w, GROUND))
                pygame.draw.rect(fx, (255, 255, 255), (sx - self.w / 6, 0, self.w / 3, GROUND))
            pygame.draw.rect(surf, (20, 14, 30), (sx - 16, 0, 32, 26))
            pygame.draw.circle(fx, shade(col, .8 if s else .3), (int(sx), 26), 8)
            return
        # floor grate
        pygame.draw.rect(surf, (12, 8, 20), (sx - self.w / 2, GROUND - 4, self.w, 8))
        pygame.draw.rect(surf, shade(col, .3 + (.5 if s == 1 else 0)), (sx - self.w / 2, GROUND - 4, self.w, 8), 2)
        if s == 1:
            k = (c * 40) % 2
            pygame.draw.rect(fx, shade(col, .25 + .5 * (int(c * 16) % 2)), (sx - self.w / 2, GROUND - 6, self.w, 8))
            gfx.text(surf, '!', 24, col, (sx, GROUND - 40))
        elif s == 2:
            hh = self.h * (0.6 + 0.4 * math.sin(self.state_t * 40))
            for i in range(5):
                w = self.w * (1 - i * .16)
                pygame.draw.rect(fx, shade(col, .95 - i * .15), (sx - w / 2, GROUND - hh * (1 - i * .1), w, hh * (1 - i * .1)))
            blit_glow(fx, sx, GROUND - hh / 2, 90, shade(col, .5))


class Speaker:
    """Interactive bass speaker: hit it (on beat!) to fire a shockwave that hurts enemies."""

    def __init__(self, x):
        self.x = x
        self.cool = 0.0
        self.shake = 0.0

    def rect(self):
        return (self.x - 32, GROUND - 96, 64, 96)

    def update(self, g, dt):
        self.cool -= dt
        self.shake -= dt

    def hit(self, g, perfect):
        if self.cool > 0:
            return
        self.cool = 6.0
        self.shake = .3
        mult = 1.6 if perfect else 1.0
        g.sfx('boom', .9)
        g.shake(10)
        g.flash((255, 60, 190), 50)
        g.particles.ring(self.x, GROUND - 50, (255, 60, 190), 20, 320, .5, 8)
        g.particles.ring(self.x, GROUND - 50, WHITE, 10, 220, .35, 4)
        g.particles.burst(self.x, GROUND - 50, (255, 120, 220), 24, 600)
        for e in list(g.enemies):
            if e.state not in ('dead', 'spawn') and abs(e.x - self.x) < 330:
                d = dict(dmg=26 * mult * (.5 if e.is_boss else 1), kb=(sign(e.x - self.x or 1) * 420, -420), stun=1.0, kind='heavy', gb=True,
                         launch=True, down=False, poise=99, grade='good', perfect=False, counter=False, from_x=self.x, f=1)
                res = e.receive(g, d)
                if res != 'miss':
                    e.popup_dmg(g, d['dmg'], perfect)
                    g.register_hit(res == 'dead', 'good', d['dmg'], e.x, e.y - 70)
        if abs(g.player.x - self.x) < 200:
            pass

    def draw(self, surf, fx, camx, phase):
        sx = self.x - camx + (random.uniform(-3, 3) if self.shake > 0 else 0)
        pulse = (1 - phase) ** 3
        pygame.draw.rect(surf, (14, 10, 26), (sx - 32, GROUND - 96, 64, 96), border_radius=6)
        ready = self.cool <= 0
        col = (255, 60, 190) if ready else (90, 60, 110)
        pygame.draw.rect(surf, col, (sx - 32, GROUND - 96, 64, 96), 3, border_radius=6)
        for cy, r in ((GROUND - 66, 15), (GROUND - 28, 21)):
            rr = r + (4 * pulse if ready else 0)
            pygame.draw.circle(surf, (6, 4, 12), (int(sx), cy), int(rr))
            pygame.draw.circle(surf, col, (int(sx), cy), int(rr), 3)
            pygame.draw.circle(surf, col, (int(sx), cy), int(rr * .35))
        if ready:
            blit_glow(fx, sx, GROUND - 50, 80, shade(col, .25 + .3 * pulse))


class Pickup:
    def __init__(self, x, y, kind='hp'):
        self.x, self.y = x, y
        self.vy = -420
        self.vx = random.uniform(-80, 80)
        self.kind = kind
        self.t = 0
        self.dead = False

    def update(self, g, dt):
        self.t += dt
        self.vy += 1800 * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        if self.y >= GROUND - 14:
            self.y = GROUND - 14
            self.vy = 0
            self.vx = 0
        lo, hi = g.bounds
        self.x = clamp(self.x, lo + 20, hi - 20)
        pl = g.player
        if abs(pl.x - self.x) < 40 and abs(pl.y - 40 - self.y) < 70 and not pl.dead:
            self.dead = True
            if self.kind == 'hp':
                pl.hp = min(pl.maxhp, pl.hp + 18)
                g.popup('+18 HP', self.x, self.y - 40, (120, 255, 160), 22)
            else:
                pl.heat = min(100, pl.heat + 25)
                g.popup('+HEAT', self.x, self.y - 40, GOLD, 22)
            g.sfx('pickup')
            g.particles.burst(self.x, self.y, (120, 255, 160), 10, 300)
        if self.t > 14:
            self.dead = True

    def draw(self, surf, fx, camx):
        sx = self.x - camx
        col = (90, 255, 140) if self.kind == 'hp' else GOLD
        b = math.sin(self.t * 6) * 3
        pygame.draw.circle(surf, (10, 14, 20), (int(sx), int(self.y + b)), 12)
        pygame.draw.circle(surf, col, (int(sx), int(self.y + b)), 12, 3)
        pygame.draw.line(surf, col, (sx - 5, self.y + b), (sx + 5, self.y + b), 3)
        if self.kind == 'hp':
            pygame.draw.line(surf, col, (sx, self.y + b - 5), (sx, self.y + b + 5), 3)
        blit_glow(fx, sx, self.y + b, 30, shade(col, .4))
