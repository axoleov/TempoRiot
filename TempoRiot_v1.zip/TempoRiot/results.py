"""Results screen: rank, stats, progression rewards."""
import math

import pygame

import gfx
from core import *
from stages import STAGES, ABILITY_UNLOCK, ABILITY_NAMES
from ui import MenuList, MenuBG, Scene, GOLD, CYAN, WHITE_

RANK_COL = {'S': (255, 214, 80), 'A': (120, 255, 160), 'B': (90, 200, 255), 'C': (200, 200, 220), 'D': (255, 100, 100)}
RANK_BONUS = {'S': 8, 'A': 5, 'B': 3, 'C': 1, 'D': 0}
RANK_ORDER = 'DCBAS'


def compute_rank(g):
    st = g.stats
    j = max(1, st['judged'])
    perf = st['perfect'] / j
    ontime = (st['perfect'] + st['good']) / j
    dmgf = clamp(1 - st['dmg'] / (g.player.maxhp * 2.5), 0, 1)
    score = (perf * .45 + ontime * .25 + dmgf * .30) * 100 + min(10, g.max_combo / 5)
    r = 'S' if score >= 78 else 'A' if score >= 62 else 'B' if score >= 46 else 'C' if score >= 30 else 'D'
    if g.continues and RANK_ORDER.index(r) > RANK_ORDER.index('B'):
        r = 'B'
    return r, score


class Results(Scene):
    def __init__(self, app, g):
        self.app = app
        self.bg = MenuBG()
        self.t = 0
        self.g = g
        sv = app.save.d
        self.mode = g.mode
        self.rank, self.rscore = compute_rank(g)
        self.time = g.time
        self.new_best = False
        self.unlock_msgs = []
        self.reward = 0
        self.stamped = False
        stt = sv['stats']
        stt['max_combo'] = max(stt['max_combo'], g.max_combo)
        if g.mode == 'gauntlet':
            self.title = 'GAUNTLET OVER'
            self.rank = None
            waves = max(0, g.gwave - 1)
            if waves > sv['gauntlet']:
                sv['gauntlet'] = waves
                self.new_best = True
            self.extra = f'WAVES SURVIVED  {waves}'
            self.reward = int(g.score / 600 * g.diff['pts'])
        elif g.mode == 'bossrush':
            self.title = 'BOSS RUSH COMPLETE' if g.player.hp > 0 else 'BOSS RUSH FAILED'
            self.rank = None
            if g.player.hp > 0 and (not sv['bossrush'] or g.time < sv['bossrush']):
                sv['bossrush'] = g.time
                self.new_best = True
            self.extra = f'TIME  {int(g.time // 60)}:{int(g.time % 60):02d}'
            self.reward = int(g.score / 500 * g.diff['pts']) if g.player.hp > 0 else 0
        else:
            self.title = 'STAGE CLEAR'
            self.extra = f'{g.stage.name}'
            idx = g.stage.idx
            key = str(idx)
            old = sv['best'].get(key)
            better = (not old) or (g.score > old['score'])
            if better:
                self.new_best = old is not None
                sv['best'][key] = dict(score=g.score, rank=self.rank if (not old or RANK_ORDER.index(self.rank) >= RANK_ORDER.index(old['rank'])) else old['rank'],
                                       combo=g.max_combo)
            elif RANK_ORDER.index(self.rank) > RANK_ORDER.index(old['rank']):
                old['rank'] = self.rank
            before = sv['unlocked']
            first = str(idx) not in [k for k in sv['best'] if False]
            sv['unlocked'] = max(sv['unlocked'], min(7, idx + 2))
            stt['stages'] += 1
            for ab, need in ABILITY_UNLOCK.items():
                if before < need <= sv['unlocked']:
                    self.unlock_msgs.append('NEW ABILITY: ' + ABILITY_NAMES[ab])
            if before < 4 <= sv['unlocked']:
                self.unlock_msgs.append('GAUNTLET MODE UNLOCKED')
            if before < 7 <= sv['unlocked']:
                self.unlock_msgs.append('BOSS RUSH UNLOCKED')
            self.reward = int(g.score / 400 * g.diff['pts']) + RANK_BONUS[self.rank]
        sv['points'] += self.reward
        app.save.store()
        nxt = g.mode in ('campaign', 'select') and g.stage.idx < 5
        items = []
        if nxt:
            items.append(dict(label='NEXT STAGE', fn=self.next))
        items += [dict(label='RETRY', fn=self.retry), dict(label='UPGRADES', fn=self.upgrades), dict(label='MAIN MENU', fn=self.menu_)]
        self.menu = MenuList(app, items, x=W - 250, y=470, gap=50, size=30)
        app.audio.start('menu')

    def next(self):
        from game import Gameplay
        self.app.audio.stop(200)
        self.app.replace(Gameplay(self.app, 'campaign', self.g.stage.idx + 1))

    def retry(self):
        from game import Gameplay
        self.app.audio.stop(200)
        self.app.replace(Gameplay(self.app, self.g.mode, self.g.stage_idx))

    def upgrades(self):
        from ui import UpgradeScene
        self.app.push(UpgradeScene(self.app, self.bg))

    def menu_(self):
        from ui import MainMenu
        self.app.replace(MainMenu(self.app))

    def event(self, ev):
        if self.t > 1.2:
            self.menu.event(ev)

    def update(self, dt):
        self.t += dt
        if self.rank and self.t > 1.6 and not self.stamped:
            self.stamped = True
            self.app.audio.play('stamp')

    def draw(self, s):
        g = self.g
        self.bg.draw(s, self.app.audio, self.t, dancer=False)
        gfx.text(s, self.title, 64, WHITE_, (W // 2, 70))
        gfx.text(s, self.extra, 24, (200, 200, 230), (W // 2, 122))
        st = g.stats
        j = max(1, st['judged'])
        k = clamp(self.t / 1.2, 0, 1)
        rows = [('SCORE', f'{int(g.score * k):,}'), ('MAX COMBO', f'{int(g.max_combo * k)}'),
                ('PERFECT', f"{int(st['perfect'] / j * 100 * k)}%"), ('GOOD', f"{int(st['good'] / j * 100 * k)}%"),
                ('OFF-BEAT', f"{int(st['off'] / j * 100 * k)}%"), ('PARRIES / EVADES', f"{st['parries']} / {st['evades']}"),
                ('DAMAGE TAKEN', f"{int(st['dmg'])}"), ('KILLS', f"{st['kills']}"),
                ('TIME', f"{int(self.time // 60)}:{int(self.time % 60):02d}")]
        for i, (a, b) in enumerate(rows):
            y = 190 + i * 44
            gfx.text(s, a, 24, (190, 190, 220), (120, y), 'midleft')
            gfx.text(s, b, 26, WHITE_ if a != 'PERFECT' else GOLD, (520, y), 'midright')
        if self.rank:
            a = clamp((self.t - 1.4) / .3, 0, 1)
            sz = int(300 - 120 * gfx.ease_out(a)) if hasattr(gfx, 'ease_out') else 200
            sz = int(300 - 120 * ease_out(a))
            gfx.text(s, self.rank, sz, RANK_COL[self.rank], (W - 250, 250), alpha=int(255 * a), sh=6)
            gfx.text(s, 'RANK', 20, (190, 190, 220), (W - 250, 105))
        if self.new_best:
            gfx.text(s, 'NEW BEST!', 30, GOLD, (W - 250, 410), alpha=int(160 + 90 * math.sin(self.t * 8)))
        gfx.text(s, f'+{self.reward} GROOVE POINTS', 24, GOLD, (W // 2 - 150, 610))
        for i, m in enumerate(self.unlock_msgs):
            gfx.text(s, m, 22, CYAN, (W // 2 - 150, 645 + i * 28))
        if self.t > 1.2:
            self.menu.draw(s, self.t, self.app.audio.phase())
