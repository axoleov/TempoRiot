"""Boss encounters. Each has its own rhythm gimmick, phases and music."""
import math
import random

import pygame

import gfx
from core import *
from entities import Enemy, ET, S, Projectile, Hazard, GOLD, WHITE, RED
from gfx import blit_glow


class Boss(Enemy):
    is_boss = True
    name = 'BOSS'
    title = ''
    hp_base = 1200
    scale = 1.6
    color = (255, 255, 255)
    spd = 130
    prefer = 200
    thresholds = ()
    tracks = ()
    hint = ''

    def __init__(self, g, x):
        super().__init__(g, 'g', x)
        self.cfg = dict(name=self.name, hp=self.hp_base, spd=self.spd, sc=self.scale, col=self.color, poise=9999,
                        prefer=self.prefer, reach=150, atks=(), cd=(.35, .8))
        self.sc = self.scale
        self.col = self.color
        self.maxhp = self.hp = self.hp_base * g.diff['hp']
        self.phase = 0
        self.trans = 0.0
        self.armored = True
        self.fly = False
        self.bfv = 0.0
        self.cd = 1.5
        self.maxpoise = self.poise = 9999

    def physics(self, g, dt):
        if self.fly:
            self.x += self.vx * dt
            self.y += (self.fy - self.y) * min(1, dt * 4)
            lo, hi = g.bounds
            self.x = clamp(self.x, lo + 60, hi - 60)
            self.on_ground = False
            return False
        return super().physics(g, dt)

    fy = GROUND

    def update(self, g, dt):
        self.bfv = g.music.bf()
        super().update(g, dt)
        if self.state == 'dead':
            return
        if self.phase < len(self.thresholds) and self.hp / self.maxhp < self.thresholds[self.phase]:
            self.next_phase(g)
        self.extra_update(g, dt)

    def extra_update(self, g, dt):
        pass

    def next_phase(self, g):
        self.phase += 1
        self.trans = 2.2
        self.plan = None
        self.state = 'idle'
        self.charge_end = 0
        self.active_until = 0
        self.armor_plan = False
        self.flash = .3
        g.boss_phase(self)
        self.on_phase(g)

    def on_phase(self, g):
        pass

    def receive(self, g, h):
        if self.trans > 0:
            return 'miss'
        return super().receive(g, h)

    def die(self, g, h):
        super().die(g, h)
        self.dead_t = 2.2

    def ai(self, g, dt):
        pl = g.player
        dx = pl.x - self.x
        ad = abs(dx)
        if self.trans > 0:
            self.trans -= dt
            self.vx = approach(self.vx, 0, 1500 * dt)
            return
        if pl.dead:
            self.vx = approach(self.vx, 0, 900 * dt)
            return
        self.f = sign(dx) or self.f
        self.move(g, dt, dx, ad)
        if self.cd <= 0:
            self.choose(g, ad, dx)

    def move(self, g, dt, dx, ad):
        want = self.prefer
        m = 0
        if ad > want + 50:
            m = sign(dx)
        elif ad < want - 70:
            m = -sign(dx) * .8
        self.vx = approach(self.vx, m * self.spd, 1800 * dt)
        self.walk += abs(self.vx) * dt * .04

    def choose(self, g, ad, dx):
        pass

    def broken_time(self, perfect):
        return 2.4 if perfect else 1.7

    def on_parried(self, g, perfect):
        super().on_parried(g, perfect)
        self.st = self.broken_time(perfect)
        self.broken = self.st

    def draw(self, surf, fx, camx, ct, phase):
        super().draw(surf, fx, camx, ct, phase)
        if self.pts is not None and self.state != 'spawn':
            self.draw_boss(surf, fx, camx, phase)

    def draw_boss(self, surf, fx, camx, phase):
        pass

    def spawn_adds(self, g, codes):
        lo, hi = g.bounds
        for i, c in enumerate(codes):
            g.spawn_enemy(c, lo + 50 if i % 2 == 0 else hi - 50)


# ---------------------------------------------------------------- METRONOME
class Metronome(Boss):
    name = 'THE METRONOME'
    title = 'PERFECT HITS ONLY - PARRY THE SWINGS'
    hp_base = 1500
    scale = 1.75
    color = (255, 190, 60)
    thresholds = (.55, .25)
    tracks = ('b1a', 'b1b', 'b1b')
    prefer = 210

    def damage_mul(self, h):
        return {'perfect': 1.5, 'good': .9, 'off': .3}.get(h.get('grade', 'good'), 1.0) * (1 if self.state != 'attack' else .85)

    def receive(self, g, h):
        r = super().receive(g, h)
        if r == 'hit' and h.get('grade') == 'off' and not h.get('reflected'):
            g.popup('RESISTED', self.x, self.y - 210, (170, 170, 190), 22)
        return r

    def on_phase(self, g):
        if self.phase == 1:
            self.spawn_adds(g, ['g', 'g'])

    def pend(self, g):
        lo, hi = g.bounds
        cx = (lo + hi) / 2
        amp = (hi - lo) / 2 - 130
        P = (8, 8, 4)[min(self.phase, 2)] if self.phase else 0
        if not P:
            return None
        return cx, cx + amp * math.sin(2 * math.pi * self.bfv / P)

    def extra_update(self, g, dt):
        pd = self.pend(g)
        if pd and self.state != 'spawn':
            x = pd[1]
            r = (x - 32, GROUND - 100, 64, 100)
            pl = g.player
            self.pcool = getattr(self, 'pcool', 0) - dt
            if self.pcool <= 0 and ov(r, pl.hurtbox()):
                h = dict(dmg=14, kb=(sign(pl.x - x) * 380, -380), stun=.35, blockable=False, parry=False, kind='hazard')
                if pl.take_hit(g, self, h):
                    self.pcool = .9

    def choose(self, g, ad, dx):
        ph = self.phase
        r = random.random()
        arc = dict(kind='melee', dmg=16, hb=(-50, -140, 250, 140), blockable=True, kb=(520, -260), stun=.5, pose='h_break', act=.14, sfx='whoosh_h')
        if ad < 300 and r < .45:
            hits = [(0, S(**arc))]
            if ph >= 1:
                hits.append((1, S(**dict(arc, dmg=14, pose='h_round'))))
            self.begin(g, dict(wind=.9, rec=.7, wpose='w_break', hits=hits, armor=True))
        elif ad < 240 and r < .8:
            n = 4 if ph < 2 else 8
            step = 1 if ph < 2 else .5
            hits = [(i * step, S(dmg=8 if ph < 2 else 6, hb=(0, -105, 110, 60), lunge=100, pose='h_jab' if i % 2 == 0 else 'h_cross')) for i in range(n)]
            self.begin(g, dict(wind=.7, rec=.6, wpose='w_jab', hits=hits, armor=True))
        elif r < .9 or ad >= 300:
            self.begin(g, dict(wind=.9, rec=.7, wpose='w_break', hits=[(0, S(kind='wave', dmg=14, blockable=False, spd=440 + 60 * ph, pose='h_break', kb=(300, -300)))], armor=True))
        else:
            if ad > 250:
                self.vx = sign(dx) * 400

    def draw_boss(self, surf, fx, camx, phase):
        sx = self.x - camx
        cx = sx - self.f * 46
        y = self.y
        col = self.color
        pts = [(cx - 42, y), (cx + 42, y), (cx + 18, y - 200), (cx - 18, y - 200)]
        pygame.draw.polygon(surf, (16, 10, 8), pts)
        pygame.draw.polygon(surf, shade(col, .55), pts, 3)
        ang = math.sin(math.pi * self.bfv) * 32 * DEG
        ex, ey = cx + math.sin(ang) * 170, y - 40 - math.cos(ang) * 170
        pygame.draw.line(surf, col, (cx, y - 40), (ex, ey), 4)
        pygame.draw.circle(surf, col, (int(ex), int(ey)), 10)
        blit_glow(fx, ex, ey, 40, shade(col, .35 * (1 - phase) + .15))
        # pendulum hazard
        pd = self.pend_draw
        if pd:
            pass

    pend_draw = None

    def draw(self, surf, fx, camx, ct, phase):
        super().draw(surf, fx, camx, ct, phase)
        pd = None
        try:
            pd = self.pend(self._g)
        except AttributeError:
            pd = None
        if pd:
            cx, x = pd
            sx, pcx = x - camx, cx - camx
            col = (255, 190, 60)
            pygame.draw.line(surf, (10, 8, 6), (pcx, 20), (sx, GROUND - 60), 9)
            pygame.draw.line(surf, col, (pcx, 20), (sx, GROUND - 60), 4)
            pygame.draw.rect(surf, (10, 8, 6), (sx - 32, GROUND - 100, 64, 100), border_radius=8)
            pygame.draw.rect(surf, col, (sx - 32, GROUND - 100, 64, 100), 4, border_radius=8)
            blit_glow(fx, sx, GROUND - 50, 80, shade(col, .35))
            pygame.draw.line(fx, shade(col, .4), (sx - 32, GROUND + 4), (sx + 32, GROUND + 4), 4)
            gfx.text(surf, 'JUMP', 16, col, (sx, GROUND - 120), alpha=180)

    _g = None

    def update(self, g, dt):
        self._g = g
        super().update(g, dt)


# ---------------------------------------------------------------- DJ VORTEX
class DJVortex(Boss):
    name = 'DJ VORTEX'
    title = 'PARRY DISCS BACK AT HIM'
    hp_base = 1300
    scale = 1.4
    color = (255, 70, 220)
    thresholds = (.5,)
    tracks = ('b2a', 'b2b')
    prefer = 330
    spd = 170

    def __init__(self, g, x):
        super().__init__(g, x)
        self.fly = True
        self.fy = GROUND - 150
        self.y = GROUND - 150
        self.mark = None
        self.shock_warn = False
        self.disc_rot = 0

    def damage_mul(self, h):
        if h.get('reflected'):
            return 1.0
        return .55 if self.state not in ('crash', 'stagger') else 1.0

    def on_disc(self, g):
        self.state = 'crash'
        self.st = 2.4
        self.broken = 2.4
        self.fly = False
        self.plan = None
        self.armor_plan = False
        self.vx = 0
        g.popup('CRASHED!', self.x, self.y - 200, GOLD, 30)
        g.sfx('crash', .6)
        g.shake(10)

    def on_parried(self, g, perfect):
        super().on_parried(g, perfect)
        self.fly = False

    def on_phase(self, g):
        self.spawn_adds(g, ['s', 'r'])

    def extra_update(self, g, dt):
        self.disc_rot += dt * 6
        if self.state in ('idle', 'attack', 'spawn') and self.state != 'crash':
            self.fly = True
        if self.state == 'idle' and self.trans <= 0 or self.trans > 0:
            self.fy = GROUND - 150 + math.sin(self.t * 2.4) * 14

    def move(self, g, dt, dx, ad):
        m = 0
        if ad > self.prefer + 80:
            m = sign(dx)
        elif ad < self.prefer - 100:
            m = -sign(dx)
        self.vx = approach(self.vx, m * self.spd, 1800 * dt)

    def choose(self, g, ad, dx):
        ph = self.phase
        pl = g.player
        r = random.random()
        disc = lambda ang=0: S(kind='special', sub='disc', dmg=12, pose='h_gun', spd=470 + 60 * ph, ang=ang)
        if r < .38:
            if ph == 0:
                hits = [(0, disc()), (1, disc()), (2, disc())]
            else:
                hits = [(0, disc(-.25)), (0, disc(0)), (0, disc(.25)), (1, disc(-.4)), (1, disc(.4)), (2, disc(0))]
            self.begin(g, dict(wind=.8, rec=.5, wpose='w_gun', hits=hits))
        elif r < .62:
            hits = [(0, S(kind='special', sub='shock', dmg=18, blockable=False, pose='h_break'))]
            if ph:
                hits.append((.5, S(kind='special', sub='shock', dmg=18, blockable=False, pose='h_break')))
            self.begin(g, dict(wind=1.6, rec=.8, wpose='w_break', hits=hits, name='drop'))
            self.plan['name'] = 'drop'
        elif r < .86:
            side = random.choice((-1, 1))
            self.mark = clamp(pl.x + side * 150, g.bounds[0] + 60, g.bounds[1] - 60)
            hits = [(0, S(kind='special', sub='tele', dmg=0)),
                    (.5, S(dmg=14, hb=(-30, -120, 170, 120), blockable=False, kb=(420, -240), stun=.4, pose='h_kick', act=.12))]
            if ph:
                hits.append((1.5, S(dmg=12, hb=(-30, -120, 170, 120), blockable=True, kb=(320, -200), pose='h_round', act=.12)))
            self.begin(g, dict(wind=.9, rec=.5, wpose='w_counter', hits=hits))
            self.plan['name'] = 'scratch'
        elif ph and len([e for e in g.enemies if not e.is_boss and e.state != 'dead']) < 2:
            self.spawn_adds(g, ['g', 's'])
            self.cd = 2
        else:
            self.cd = .4

    def fire_special(self, g, sp, ct):
        sub = sp['sub']
        if sub == 'disc':
            self.shoot(g, sp, sp.get('ang', 0), (255, 70, 220), 'disc', sp['spd'])
            g.sfx('disc', .6)
        elif sub == 'shock':
            g.shake(14)
            g.sfx('drop')
            g.flash((255, 60, 200), 70)
            lo, hi = g.bounds
            for i in range(0, int(hi - lo), 60):
                g.particles.burst(lo + i, GROUND, (255, 70, 220), 3, 500, -math.pi / 2, .8, .5, 4)
            g.particles.ring(self.x, GROUND - 4, WHITE, 20, 600, .6, 6)
            pl = g.player
            if pl.y > GROUND - 50:
                pl.take_hit(g, self, dict(dmg=sp['dmg'], kb=(300 * sign(pl.x - self.x or 1), -420), stun=.4, blockable=False, parry=False, kind='hazard'))
        elif sub == 'tele':
            if self.mark is not None:
                self.x = self.mark
                self.y = GROUND - 100
                self.fy = GROUND - 100
                g.particles.ring(self.x, self.y - 40, (255, 70, 220), 10, 90, .3, 4)
                g.sfx('whoosh_h')
                self.f = sign(g.player.x - self.x) or self.f

    def draw(self, surf, fx, camx, ct, phase):
        if self.state == 'attack' and self.plan and self.plan.get('name') == 'scratch' and self.plan['i'] == 0:
            sx = (self.mark or self.x) - camx
            pygame.draw.line(fx, shade((255, 70, 220), .4 + .6 * self.wprog), (sx, GROUND - 200), (sx, GROUND), 3)
            pygame.draw.circle(fx, (255, 70, 220), (int(sx), GROUND), int(50 * (1 - self.wprog) + 8), 3)
            gfx.text(surf, '!', 36, RED, (sx, GROUND - 210))
            return
        if self.state == 'attack' and self.plan and self.plan.get('name') == 'drop':
            k = .3 + .7 * (int(self.wprog * 12) % 2)
            lo, hi = self._g.bounds if self._g else (0, W)
            pygame.draw.rect(fx, shade((255, 40, 120), k * .8), (lo - camx, GROUND - 6, hi - lo, 12))
            gfx.text(surf, 'JUMP!', 34, RED, (W // 2, 120), alpha=int(150 + 100 * k))
        super().draw(surf, fx, camx, ct, phase)

    _g = None

    def update(self, g, dt):
        self._g = g
        super().update(g, dt)

    def draw_boss(self, surf, fx, camx, phase):
        sx = self.x - camx
        col = self.color
        gy = self.y + 8
        pygame.draw.ellipse(surf, (14, 8, 22), (sx - 80, gy - 12, 160, 30))
        pygame.draw.ellipse(surf, shade(col, .7), (sx - 80, gy - 12, 160, 30), 3)
        for i in range(4):
            a = self.disc_rot + i * 1.57
            pygame.draw.line(fx, shade(col, .6), (sx, gy + 3), (sx + math.cos(a) * 70, gy + 3 + math.sin(a) * 12), 2)
        blit_glow(fx, sx, gy, 110, shade(col, .2 + .3 * (1 - phase) ** 2))
        hx, hy = self.pts['hc']
        pygame.draw.arc(surf, col, (hx - 20, hy - 22, 40, 36), 0, math.pi, 4)


# ---------------------------------------------------------------- CONDUCTOR
class Conductor(Boss):
    name = 'THE CONDUCTOR'
    title = '3 PARRIES BREAK HIS CADENCE'
    hp_base = 1900
    scale = 1.65
    color = (255, 236, 170)
    thresholds = (.66, .33)
    tracks = ('b3a', 'b3b', 'b3c')
    prefer = 220
    spd = 150

    def __init__(self, g, x):
        super().__init__(g, x)
        self.cadence = 0
        self.xs = []

    def damage_mul(self, h):
        return .85

    def on_parried(self, g, perfect):
        super().on_parried(g, perfect)
        self.cadence += 1
        if self.cadence >= 3:
            self.cadence = 0
            self.st = 3.4
            self.broken = 3.4
            g.popup('CADENCE BREAK!', self.x, self.y - 230, GOLD, 34)
            g.flash(GOLD, 90)
            g.shake(14)
            g.sfx('crash', .7)
        else:
            g.popup(f'CADENCE {self.cadence}/3', self.x, self.y - 210, GOLD, 22)

    def on_phase(self, g):
        self.cadence = 0
        self.spawn_adds(g, ['s', 's', 'r'] if self.phase == 1 else ['y', 'e'] if self.phase == 2 and g.diff['name'] != 'CHILL' else ['y'])
        g.set_boss_lasers(self.phase)

    def choose(self, g, ad, dx):
        ph = self.phase
        pl = g.player
        r = random.random()
        f = 1 if ph < 2 else .5
        if ad < 260 and r < .4:
            n = 4 if ph < 2 else 8
            hits = [(i * f, S(dmg=9, hb=(0, -120, 190, 80), lunge=110, pose='h_hook' if i % 2 else 'h_jab')) for i in range(n)]
            last = hits[-1][1]
            last.update(blockable=False, dmg=15, pose='h_break', kb=(520, -260), hb=(0, -140, 210, 140))
            self.begin(g, dict(wind=.9, rec=.7, wpose='w_hook', hits=hits, armor=True))
        elif r < .65:
            note = lambda ang: S(kind='special', sub='note', dmg=9, pose='h_gun', spd=430, ang=ang)
            angs = (-.25, 0, .25) if ph == 0 else (-.4, -.2, 0, .2, .4)
            hits = [(i, note(a)) for i, a in enumerate(angs)] if ph == 0 else [(i * .5, note(a)) for i, a in enumerate(angs)]
            self.begin(g, dict(wind=.9, rec=.6, wpose='w_gun', hits=hits))
        elif r < .8 and ad > 300:
            self.begin(g, dict(wind=1.0, rec=.2, wpose='w_charge', armor=True,
                               hits=[(0, S(kind='charge', dmg=16, blockable=False, dur=.55, spd=900, hb=(-10, -110, 100, 110), kb=(600, -200), stun=.6, pose='h_charge'))]))
        elif ph >= 2 and r < .95:
            lo, hi = g.bounds
            xs = [clamp(pl.x + random.uniform(-260, 260), lo + 60, hi - 60) for _ in range(3)]
            self.xs = xs
            hits = [(0, S(kind='special', sub='rain', dmg=10, pose='h_break')), (1, S(kind='special', sub='rain', dmg=10, pose='h_break'))]
            self.begin(g, dict(wind=1.2, rec=.6, wpose='w_break', hits=hits))
            self.plan['name'] = 'rain'
        elif ph >= 1 and len([e for e in g.enemies if not e.is_boss and e.state != 'dead']) < 2 and r > .95:
            self.spawn_adds(g, ['s'])
        else:
            self.cd = .3

    def fire_special(self, g, sp, ct):
        sub = sp['sub']
        if sub == 'note':
            self.shoot(g, sp, sp.get('ang', 0), (255, 236, 170), 'note', sp['spd'])
        elif sub == 'rain':
            g.sfx('laser', .5)
            for x in self.xs:
                g.projs.append(Projectile(x, -30, 0, 720, sp['dmg'], kind='note', col=(255, 236, 170), life=2))
            lo, hi = g.bounds
            self.xs = [clamp(g.player.x + random.uniform(-260, 260), lo + 60, hi - 60) for _ in range(3)]

    def draw(self, surf, fx, camx, ct, phase):
        if self.state == 'attack' and self.plan and self.plan.get('name') == 'rain':
            for x in self.xs:
                sx = x - camx
                pygame.draw.line(fx, shade((255, 90, 90), .3 + .5 * self.wprog), (sx, 0), (sx, GROUND), 2)
                pygame.draw.circle(fx, (255, 90, 90), (int(sx), GROUND), int(30 * (1 - self.wprog) + 6), 3)
        super().draw(surf, fx, camx, ct, phase)

    def draw_boss(self, surf, fx, camx, phase):
        p = self.pts
        hx, hy = p['fh']
        col = self.color
        ex = hx + self.f * 55 * (1.0 if self.state != 'attack' else 1.3)
        ey = hy - 40
        pygame.draw.line(surf, (10, 8, 10), (hx, hy), (ex, ey), 6)
        pygame.draw.line(surf, col, (hx, hy), (ex, ey), 3)
        blit_glow(fx, ex, ey, 26, shade(col, .5))
        # tails
        sx, sy = p['pel']
        pygame.draw.polygon(surf, shade(col, .35), [(sx, sy + 4), (sx - self.f * 34 - 10, sy + 44), (sx - self.f * 8, sy + 46)])
        # cadence pips
        for i in range(3):
            c = GOLD if i < self.cadence else (60, 50, 40)
            pygame.draw.circle(surf, c, (int(sx - 18 + i * 18), int(self.y - 205 * self.sc / 1.65)), 5)
        if self.phase:
            blit_glow(fx, sx, sy - 40, 120, shade((255, 40, 60), .15 + .1 * self.phase))


BOSSES = {'metronome': Metronome, 'dj': DJVortex, 'conductor': Conductor}
