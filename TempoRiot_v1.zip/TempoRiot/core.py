"""Shared constants, math helpers, persistence."""
import copy
import json
import math
import os

W, H = 1280, 720
GROUND = 610
DEG = math.pi / 180.0


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t):
    return a + (b - a) * t


def sign(v):
    return (v > 0) - (v < 0)


def ease_out(t):
    t = clamp(t, 0.0, 1.0)
    return 1 - (1 - t) ** 3


def ease_in(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * t


def smooth(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * (3 - 2 * t)


def mix(c1, c2, t):
    t = clamp(t, 0.0, 1.0)
    return (int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t))


def shade(c, k):
    return (int(clamp(c[0] * k, 0, 255)), int(clamp(c[1] * k, 0, 255)), int(clamp(c[2] * k, 0, 255)))


def approach(v, target, step):
    if v < target:
        return min(target, v + step)
    return max(target, v - step)


def ov(a, b):
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


def hbox(x, y, f, hb):
    ox, oy, w, h = hb
    return (x + ox if f > 0 else x - ox - w, y + oy, w, h)


SAVE_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "TempoRiot")
SAVE_PATH = os.path.join(SAVE_DIR, "save.json")

UPGRADES = [
    ("vit", "VITALITY", "+15 max health"),
    ("pow", "POWER", "+8% damage"),
    ("grv", "GROOVE", "+15% heat from timing"),
    ("syn", "SYNC", "wider timing windows"),
    ("rec", "RECOVERY", "heal when you parry"),
]
UPGRADE_MAX = 5

DIFFS = [
    dict(name="CHILL", win=1.35, edmg=0.65, tok=-1, wind=1.25, hp=0.8, pts=0.7),
    dict(name="STANDARD", win=1.0, edmg=1.0, tok=0, wind=1.0, hp=1.0, pts=1.0),
    dict(name="HARDCORE", win=0.8, edmg=1.4, tok=1, wind=0.85, hp=1.25, pts=1.5),
]

DEFAULTS = dict(
    settings=dict(master=0.8, music=0.7, sfx=0.9, shake=1.0, offset=0, difficulty=1,
                  fullscreen=False, flashes=True),
    unlocked=1,
    best={},
    points=0,
    upgrades={k: 0 for k, _, _ in UPGRADES},
    stats=dict(play_time=0.0, hits=0, perfects=0, kills=0, deaths=0, max_combo=0,
               stages=0, parries=0, evades=0),
    gauntlet=0,
    bossrush=0.0,
    seen_hints=[],
)


def _merge(base, new):
    for k, v in new.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _merge(base[k], v)
        else:
            base[k] = v


class Save:
    def __init__(self):
        self.d = copy.deepcopy(DEFAULTS)
        try:
            with open(SAVE_PATH, "r", encoding="utf-8") as f:
                _merge(self.d, json.load(f))
        except Exception:
            pass

    @property
    def s(self):
        return self.d["settings"]

    def store(self):
        try:
            os.makedirs(SAVE_DIR, exist_ok=True)
            with open(SAVE_PATH, "w", encoding="utf-8") as f:
                json.dump(self.d, f)
        except Exception:
            pass
