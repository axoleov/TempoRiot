"""Procedural audio: synthesized music loops, sound effects and the beat conductor."""
import math
import random
import time

import numpy as np
import pygame

from core import clamp

SR = 44100
_rng = np.random.default_rng(20260929)


# ----------------------------------------------------------------- synth basics
def _t(d):
    return np.arange(int(SR * d)) / SR


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def _noise(d):
    return _rng.standard_normal(int(SR * d))


def _hp(x, k=0.95):
    y = np.empty_like(x)
    y[0] = x[0]
    y[1:] = x[1:] - k * x[:-1]
    return y


def _lp(x, n):
    return np.convolve(x, np.ones(n) / n, mode="same")


def sweep(f0, f1, d, decay=6.0, rate=None, wave=0):
    t = _t(d)
    rate = rate or 6.0 / max(d, 0.01)
    f = f1 + (f0 - f1) * np.exp(-t * rate)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) if wave == 0 else np.sign(np.sin(ph)) * 0.5 if wave == 1 else (2 * ((ph / (2 * np.pi)) % 1) - 1) * 0.6
    return s * np.exp(-t * decay)


def nz(d, decay=20.0, hp=0.9):
    t = _t(d)
    return _hp(_noise(d), hp) * np.exp(-t * decay)


def kick(p=1.0):
    t = _t(.42)
    f = 44 + 135 * np.exp(-t * 32)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7.5)
    s += _noise(.42) * np.exp(-t * 180) * .3
    return np.tanh(s * 1.8 * p)


def snare():
    t = _t(.3)
    n = _hp(_noise(.3), .5)
    return np.tanh((n * np.exp(-t * 18) * .9 + np.sin(2 * np.pi * 185 * t) * np.exp(-t * 30) * .7) * 1.5)


def hat(o=False):
    d = .22 if o else .06
    return _hp(_noise(d), .98) * np.exp(-_t(d) * (18 if o else 70)) * .45


def clap():
    t = _t(.3)
    n = _hp(_noise(.3), .7)
    e = np.exp(-t * 22) * .5
    for o in (0, .012, .024):
        e += np.where(t >= o, np.exp(-np.maximum(t - o, 0) * 90), 0) * .5
    return n * e * .8


_nc = {}


def _tone(f, d, harm, decay, atk=.004, rel=.03):
    key = (round(f, 2), round(d, 3), harm, decay)
    if key in _nc:
        return _nc[key]
    t = _t(d)
    s = np.zeros_like(t)
    for k in harm:
        s += np.sin(2 * np.pi * f * k * t) / k
    env = np.minimum(1, t / atk) * np.exp(-t * decay) * np.minimum(1, np.maximum(d - t, 0) / rel)
    r = s * env
    _nc[key] = r
    return r


def bass_note(f, d):
    return np.tanh(_tone(f, d, (1, 2, 3, 4), 3.0) * 1.6) * .8 + _tone(f, d, (1,), 2.5) * .5


def lead_note(f, d):
    return _tone(f, d, (1, 3, 5, 7), 4.5) * .35 + _tone(f * 1.005, d, (1, 2), 4.5) * .25


def arp_note(f, d):
    return _tone(f, d, (1, 2, 3), 9.0, atk=.002) * .35


def pad_note(f, d):
    t = _t(d)
    env = np.minimum(1, t / .25) * np.minimum(1, np.maximum(d - t, 0) / .25)
    return (np.sin(2 * np.pi * f * t) + np.sin(2 * np.pi * f * 1.004 * t) * .8) * env * .16


# ----------------------------------------------------------------- tracks
def T(bpm, root, k, sn, hh, bs, ar, ld, prog=None, lead_from=2, drive=.6, bars=8, clap_=False, oh=''):
    return dict(bpm=bpm, root=root, k=k, sn=sn, hh=hh, bs=bs, ar=ar, ld=ld, bars=bars,
                prog=prog or [(0, 'm'), (8, 'M'), (3, 'M'), (10, 'M')], lead_from=lead_from,
                drive=drive, clap=clap_, oh=oh)


FOUR = 'x...x...x...x...'
TRACKS = {
    'menu': T(100, 45, 'x.......x.......', '....x.......x...', '..x...x...x...x.', 'x.....x.x.......', 'x.xxx.xxx.xxx.xx', 'x...x...x.x.....', drive=.4),
    's1': T(116, 45, FOUR, '....x.......x...', 'x.x.x.x.x.x.x.x.', 'x..x..x.x..x..x.', 'x.xxx.xxx.xxx.xx', 'x.x...x.x..x....', lead_from=2, oh='......x.......x.'),
    's2': T(124, 43, FOUR, '....x.......x...', '..x...x...x...x.', 'x.x.x.x.x.x.x.x.', 'xxxxxxxxxxxxxxxx', 'x..x..x...x.x...', prog=[(0, 'm'), (5, 'M'), (7, 'm'), (10, 'M')], clap_=True),
    'b1a': T(128, 40, 'x..xx..xx..xx.x.', '....x.......x...', 'x.x.x.x.x.x.x.x.', 'x.xxx.xxx.xxx.xx', 'x.x.x.x.x.x.x.x.', 'x...x...x...xx..', prog=[(0, 'm'), (0, 'm'), (8, 'M'), (7, 'M')], lead_from=0, drive=.8, bars=4),
    'b1b': T(128, 40, FOUR, '....x.......x.x.', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'x.xx.x.xx.xx.x.x', prog=[(0, 'm'), (1, 'm'), (8, 'M'), (7, 'M')], lead_from=0, drive=1.0, bars=4, clap_=True),
    's3': T(128, 41, 'x...x...x...x..x', '....x.......x...', '..x...x...x...x.', 'x.xxx.x.x.xxx.x.', 'x.x.xx.x.x.xx.x.', 'x..x..x...x.....', prog=[(0, 'm'), (0, 'm'), (5, 'm'), (7, 'M')], drive=.8),
    's4': T(132, 46, FOUR, '....x.......x...', 'x.x.x.x.x.x.x.x.', 'x.x.x.x.x.x.x.x.', 'x.xxx.xxx.xxx.xx', 'x.x.x...x.x.....', prog=[(0, 'm'), (3, 'M'), (8, 'M'), (7, 'M')], clap_=True, oh='..x...x...x...x.'),
    'b2a': T(140, 42, 'x...x...x...x...', '....x.......x...', 'x.x.x.x.x.x.x.x.', 'xx.xx.xx.xx.xx..', 'xxxxxxxxxxxxxxxx', 'x.x.x..xx.x.x...', prog=[(0, 'm'), (8, 'M'), (5, 'm'), (10, 'M')], lead_from=0, drive=.9, bars=4, clap_=True),
    'b2b': T(140, 42, 'x.x.x.x.x.x.x.x.', '....x...x...x.x.', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xx.xx.xxxx.xx.x.', prog=[(0, 'm'), (8, 'M'), (5, 'm'), (10, 'M')], lead_from=0, drive=1.2, bars=4, clap_=True),
    's5': T(136, 44, 'x..xx..xx..xx..x', '....x.......x...', '..x.x.x...x.x.x.', 'x.xx.xx.x.xx.xx.', 'xx.xx.xx.xx.xx.x', 'x.x..x.x..x.x...', prog=[(0, 'm'), (0, 'm'), (8, 'M'), (5, 'M')], drive=1.0),
    's6': T(140, 43, FOUR, '....x.......x...', 'x.x.x.x.x.x.x.x.', 'x.xxx.xxx.xxx.xx', 'xxxxxxxxxxxxxxxx', 'x.x.x.xx.x.x.x..', prog=[(0, 'm'), (8, 'M'), (3, 'M'), (7, 'M')], drive=1.0, clap_=True),
    'b3a': T(144, 38, 'x...x...x...x...', '....x.......x...', 'x.x.x.x.x.x.x.x.', 'x.xxx.xxx.xxx.xx', 'xxxxxxxxxxxxxxxx', 'x..x..x..x..x...', prog=[(0, 'm'), (0, 'm'), (8, 'M'), (7, 'M')], lead_from=0, drive=.9, bars=4),
    'b3b': T(144, 38, FOUR, '....x.......x.x.', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xx.xx.xx.xx.xx.x', prog=[(0, 'm'), (5, 'M'), (8, 'M'), (7, 'M')], lead_from=0, drive=1.1, bars=4, clap_=True),
    'b3c': T(144, 38, 'x.x.x.x.x.x.x.x.', '....x...x...x.xx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', prog=[(0, 'm'), (1, 'm'), (8, 'M'), (7, 'M')], lead_from=0, drive=1.3, bars=4, clap_=True),
}
STAGE_TRACK_ALIAS = {'gaunt': 's4'}
CHORD = {'m': (0, 3, 7, 12, 15, 19), 'M': (0, 4, 7, 12, 16, 19)}
SCALE = [0, 3, 5, 7, 10, 12, 15, 17, 19]

_drum = {}


def _d(name, fn):
    if name not in _drum:
        _drum[name] = fn()
    return _drum[name]


def render_track(name):
    name = STAGE_TRACK_ALIAS.get(name, name)
    c = TRACKS[name]
    rs = random.Random(name)
    beat = 60.0 / c['bpm']
    step = beat / 4
    n = int(round(c['bars'] * 16 * step * SR))
    L = np.zeros(n)
    R = np.zeros(n)
    bs_ = np.zeros(n)
    pad_ = np.zeros(n)

    def put(bufs, sig, s, g=1.0):
        i = int(round(s * step * SR)) % n
        m = sig.size
        for b in bufs:
            if i + m <= n:
                b[i:i + m] += sig * g
            else:
                k = n - i
                b[i:] += sig[:k] * g
                b[:m - k] += sig[k:] * g

    K, S_, H_, OH, CL = _d('k', kick), _d('s', snare), _d('h', hat), _d('oh', lambda: hat(True)), _d('cl', clap)
    mel = []
    idx = 3
    for bar in range(4):
        row = []
        for s in range(16):
            if c['ld'][s] == 'x':
                idx = int(clamp(idx + rs.choice([-2, -1, -1, 0, 1, 1, 2]), 0, len(SCALE) - 1))
                row.append(idx)
            else:
                row.append(None)
        mel.append(row)
    for bar in range(c['bars']):
        base = bar * 16
        off, q = c['prog'][bar % len(c['prog'])]
        root = c['root'] + off
        ch = CHORD[q]
        fill = (bar % 8 == 7) and c['bars'] >= 8 or (bar % 4 == 3 and c['bars'] == 4)
        for s in range(16):
            st = base + s
            if fill and s >= 8:
                if s % 2 == 0:
                    put([L, R], S_, st, .55 + s * .03)
            else:
                if c['k'][s] == 'x':
                    put([L, R], K, st, 1.0)
                if c['sn'][s] == 'x':
                    put([L, R], S_, st, .8)
                    if c['clap']:
                        put([L, R], CL, st, .5)
            if c['hh'][s] == 'x' and not (fill and s >= 8):
                put([L, R], H_, st, .55 if s % 4 else .8)
            if c['oh'] and c['oh'][s] == 'x':
                put([L, R], OH, st, .5)
            if c['bs'][s] == 'x' and not (fill and s >= 12):
                nlen = step * (2 if s % 4 == 0 else 1.5)
                put([bs_], bass_note(midi(root - 12 + (12 if (s % 8 == 6) else 0)), nlen), st, .75)
        pd = [midi(root + x) for x in ch[:3]]
        for f in pd:
            put([pad_], pad_note(f, step * 16), base, 1.0)
        if bar >= c['lead_from'] or c['lead_from'] == 0:
            arp = c['ar']
            for s in range(16):
                if arp[s] == 'x':
                    tone = ch[(s // 2 + bar) % len(ch)] if s % 2 == 0 else ch[(s + 2) % len(ch)]
                    pan = .35 if s % 4 < 2 else -.35
                    sig = arp_note(midi(root + 12 + tone), step * 1.6)
                    put([L], sig, st := base + s, .8 - pan)
                    put([R], sig, st, .8 + pan)
            row = mel[bar % 4]
            for s in range(16):
                if row[s] is not None:
                    sig = lead_note(midi(root + 24 + SCALE[row[s]]), step * 2.5)
                    put([L, R], sig, base + s, .8)
    # sidechain pump on bass & pads
    bsamp = int(beat * SR)
    ph = (np.arange(n) % bsamp) / bsamp
    duck = 1 - .75 * np.exp(-ph * 9)
    mixL = L + bs_ * duck + pad_ * duck
    mixR = R + bs_ * duck + pad_ * duck
    out = np.stack([mixL, mixR], axis=1)
    out = np.tanh(out * (.9 + .4 * c['drive']))
    out *= .9 / max(1e-6, np.max(np.abs(out)))
    return (out * 32000).astype(np.int16), c['bpm']


# ----------------------------------------------------------------- sfx
def _fit(*sigs):
    n = max(s.size for s in sigs)
    o = np.zeros(n)
    for s in sigs:
        o[:s.size] += s
    return o


def build_sfx():
    S = {}

    def add(name, sig, vol=1.0, pan=0.0):
        sig = sig / max(1e-6, np.max(np.abs(sig))) * .85 * vol
        st = np.stack([sig * (1 - max(0, pan)), sig * (1 + min(0, pan))], axis=1)
        S[name] = pygame.sndarray.make_sound(np.ascontiguousarray((np.clip(st, -1, 1) * 32000).astype(np.int16)))

    add('hit_l', _fit(sweep(260, 90, .14, 22), nz(.09, 45) * .6))
    add('hit_l2', _fit(sweep(310, 110, .13, 24), nz(.08, 50) * .6))
    add('hit_h', _fit(sweep(170, 45, .3, 12), nz(.16, 25) * .8, sweep(90, 40, .3, 9) * .8))
    add('hit_p', _fit(sweep(190, 40, .35, 10), nz(.18, 22) * .8, sweep(2400, 1500, .35, 10, wave=0) * .4, sweep(3200, 2000, .3, 12) * .25))
    add('whoosh', nz(.16, 14, .7) * np.sin(np.linspace(0, np.pi, int(SR * .16))) * .5)
    add('whoosh_h', nz(.26, 9, .6) * np.sin(np.linspace(0, np.pi, int(SR * .26))) * .6)
    add('dodge', nz(.22, 10, .5) * np.linspace(1, 0, int(SR * .22)) * .6)
    add('pdodge', _fit(nz(.3, 8, .5) * .5, sweep(1500, 700, .3, 9) * .5))
    add('parry', _fit(sweep(2100, 1900, .5, 7) * .5, sweep(3100, 2900, .4, 9) * .35, sweep(4700, 4500, .3, 12) * .25, nz(.03, 90) * .8))
    add('pparry', _fit(sweep(2100, 1900, .6, 5) * .5, sweep(3100, 2900, .5, 7) * .35, sweep(120, 45, .4, 9) * .9, nz(.05, 60) * .8))
    add('block', _fit(sweep(150, 70, .15, 22), nz(.06, 60, .5) * .6))
    add('hurt', _fit(sweep(160, 50, .3, 10, wave=2) * .6, nz(.2, 22) * .7))
    add('jump', sweep(180, 420, .16, 12, rate=10) * .5)
    add('land', _fit(sweep(90, 45, .12, 25), nz(.05, 70, .3) * .4))
    add('shoot', _fit(sweep(1200, 220, .15, 18, wave=1) * .5, nz(.05, 60) * .4))
    add('die', _fit(nz(.5, 7) * .6, sweep(320, 40, .5, 6) * .8))
    add('bossdie', _fit(nz(1.4, 2.2) * .5, sweep(200, 25, 1.4, 2.4) * .9, sweep(1200, 60, 1.2, 3, wave=2) * .3))
    add('drop', _fit(sweep(130, 26, 1.1, 2.8) * 1.2, nz(.9, 4, .3) * .5))
    add('special', _fit(sweep(90, 900, .5, 2, rate=2) * .4, nz(.5, 3, .6) * np.linspace(0, 1, int(SR * .5)) * .5))
    add('boom', _fit(sweep(140, 24, .9, 3.5) * 1.2, nz(.7, 5) * .7))
    add('ui_move', sweep(700, 640, .05, 40) * .4)
    add('ui_ok', _fit(sweep(660, 655, .07, 30) * .5, np.concatenate([np.zeros(int(SR * .05)), sweep(990, 985, .12, 20) * .5])))
    add('ui_back', sweep(500, 300, .09, 25) * .5)
    add('warn', np.concatenate([sweep(1000, 990, .05, 30), np.zeros(int(SR * .02)), sweep(1000, 990, .05, 30)]) * .5)
    add('spawn', sweep(200, 1200, .3, 8, rate=4) * .4)
    add('crash', nz(1.2, 3, .5) * .7)
    add('laser', sweep(900, 300, .35, 6, wave=2) * .5)
    add('pickup', np.concatenate([sweep(700, 690, .06, 20), sweep(1000, 990, .12, 14)]) * .5)
    add('gameover', sweep(400, 60, 1.4, 2.4, wave=2) * .7)
    add('stamp', _fit(sweep(150, 40, .4, 8) * 1.0, nz(.2, 22) * .6))
    add('tick', sweep(1800, 1700, .03, 90) * .8)
    for i in range(4):
        add(f'ping{i}', sweep(600 * 2 ** (i / 4.0 * 1.0), 590 * 2 ** (i / 4.0), .18, 14) * .5)
    add('disc', _fit(sweep(600, 300, .2, 10, wave=1) * .3, nz(.15, 30, .8) * .3))
    add('reflect', _fit(sweep(2600, 1800, .3, 8) * .5, sweep(1300, 900, .3, 8) * .4, nz(.04, 80) * .5))
    return S


# ----------------------------------------------------------------- manager
class Audio:
    """Sound effects + music with a beat clock (works silently if no device)."""

    def __init__(self, save):
        self.save = save
        self.ok = False
        self.sfx = {}
        self.tracks = {}
        self.name = None
        self.beat = .5
        self.bpm = 120
        self.t0 = time.perf_counter()
        self.paused = False
        self.pause_t = 0.0
        self.ch = None
        self.loops = 0
        try:
            pygame.mixer.pre_init(44100, -16, 2, 512)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(28)
            pygame.mixer.set_reserved(1)
            self.ch = pygame.mixer.Channel(0)
            self.sfx = build_sfx()
            self.ok = True
        except Exception as e:  # no audio device
            print("audio disabled:", e)
        self.apply_volume()

    # -- volume
    def apply_volume(self):
        s = self.save.s
        if self.ok and self.ch:
            self.ch.set_volume(s['master'] * s['music'])

    def play(self, name, vol=1.0):
        if not self.ok:
            return
        snd = self.sfx.get(name)
        if snd is None:
            return
        s = self.save.s
        snd.set_volume(clamp(vol * s['master'] * s['sfx'], 0, 1))
        snd.play()

    # -- music
    def prepare(self, name):
        name = STAGE_TRACK_ALIAS.get(name, name)
        if name not in self.tracks:
            data, bpm = render_track(name)
            snd = pygame.sndarray.make_sound(np.ascontiguousarray(data)) if self.ok else None
            self.tracks[name] = (snd, bpm)
        return self.tracks[name]

    def start(self, name):
        name = STAGE_TRACK_ALIAS.get(name, name)
        snd, bpm = self.prepare(name)
        self.name = name
        self.bpm = bpm
        self.beat = 60.0 / bpm
        self.paused = False
        if self.ok and snd:
            self.apply_volume()
            self.ch.play(snd, loops=-1)
        self.t0 = time.perf_counter()

    def stop(self, fade=300):
        if self.ok and self.ch:
            self.ch.fadeout(fade)
        self.name = None

    def pause(self):
        if not self.paused:
            self.paused = True
            self.pause_t = time.perf_counter()
            if self.ok and self.ch:
                self.ch.pause()

    def resume(self):
        if self.paused:
            self.paused = False
            self.t0 += time.perf_counter() - self.pause_t
            if self.ok and self.ch:
                self.ch.unpause()

    # -- clock
    def t(self):
        return (self.pause_t if self.paused else time.perf_counter()) - self.t0

    def bf(self):
        return self.t() / self.beat

    def phase(self):
        b = self.bf()
        return b - math.floor(b)

    def judge(self, ct, pw, gw):
        """-> (grade, signed offset seconds). grade in perfect/good/off."""
        x = ct / self.beat
        nb = round(x)
        db = abs(x - nb) * self.beat
        dh = abs(x - (math.floor(x) + .5)) * self.beat
        signed = (x - nb) * self.beat
        if db <= pw:
            return 'perfect', signed
        if db <= gw:
            return 'good', signed
        if dh <= pw * .9:
            return 'good', (x - (math.floor(x) + .5)) * self.beat
        return 'off', signed if db < dh else (x - (math.floor(x) + .5)) * self.beat

    def next_grid(self, after, sub=1, offbeat=False):
        g = self.beat / sub
        k = math.ceil(after / g - 1e-9)
        if offbeat and sub == 2 and k % 2 == 0:
            k += 1
        return k * g
