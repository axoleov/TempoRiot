# TEMPO RIOT
Rhythm-driven stickman action. Python 3.12 + pygame + numpy. No external assets: all art and audio are generated.

Run: `run.bat` (Windows) or `pip install -r requirements.txt && python main.py`

Controls
- Move A/D or arrows | Jump Space (x2) | Drop through platform: S + Space
- Light J/Z | Heavy K/X | Dodge L/C | Block/Parry I/V/Shift | Drop the Bass O/E/F
- Launcher W+J | Sweep S+K | Dive S+K (air) | Pause Esc/P | Fullscreen F11

Rules of rhythm
- Every attack, dodge and parry is judged against the beat: PERFECT / GOOD / OFF.
- Enemy strikes always land on the beat. The ring closes on the hit. White = parry. Red = dodge/jump.
- Settings > Timing Offset compensates audio latency.
