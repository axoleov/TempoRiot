"""Stage definitions and procedural, beat-reactive backgrounds."""
import math
import random

import pygame

import gfx
from core import *
from entities import Hazard, Speaker
from gfx import blit_glow

ARENA_STEP = W + 700
ARENA_X0 = 300


def wv(s):
    out = []
    for tok in s.split():
        out.append((tok[0], int(tok[1:])))
    return out


class Arena:
    def __init__(self, i, waves=(), boss=None, platforms=(), hazards=(), props=(), hints=()):
        self.i = i
        self.x0 = ARENA_X0 + i * ARENA_STEP
        self.waves = [wv(w) for w in waves]
        self.boss = boss
        self.platforms = [(self.x0 + dx, y, w) for dx, y, w in platforms]
        self.hazards = [(k, self.x0 + dx, kw) for k, dx, kw in hazards]
        self.props = [self.x0 + dx for dx in props]
        self.hints = list(hints)


P1, P2 = GROUND - 125, GROUND - 235


class StageDef:
    def __init__(self, idx, name, sub, theme, music, arenas, boss_key=None):
        self.idx = idx
        self.name, self.sub, self.theme, self.music = name, sub, theme, music
        self.arenas = arenas
        self.boss_key = boss_key
        self.width = ARENA_X0 + len(arenas) * ARENA_STEP + 200


def _vent(dx, per=4, ph=0):
    return ('vent', dx, dict(w=70, period=per, phase=ph, active=.6, dmg=12, h=120))


def _rail(dx, per=4, ph=1):
    return ('rail', dx, dict(w=200, period=per, phase=ph, active=.6, dmg=10, h=26))


def _laser(dx, per=4, ph=0):
    return ('laser', dx, dict(w=46, period=per, phase=ph, active=.5, dmg=15))


STAGES = [
    StageDef(0, 'NEON ALLEY', 'Learn the rhythm', 'alley', 's1', [
        Arena(0, ['g2', 'g3'], platforms=[(220, P1, 220), (850, P1, 220)], props=[640],
              hints=['MOVE  A / D    JUMP  SPACE', 'J = LIGHT   K = HEAVY.  HIT ON THE BEAT FOR PERFECT DAMAGE',
                     'CHAIN J J J J.  HIT THE SPEAKER FOR A SHOCKWAVE']),
        Arena(1, ['g2 r1', 'g3 r1'], platforms=[(300, P1, 200), (780, P1, 200)],
              hints=['HOLD I / SHIFT TO BLOCK.  TAP IT ON THE BEAT TO PARRY',
                     'L = DODGE.  DODGE THROUGH ATTACKS FOR A COUNTER']),
    ]),
    StageDef(1, 'ROOFTOP RAVE', 'Guards and gunners', 'roof', 's2', [
        Arena(0, ['g2 d1', 'd1 r2 g1'], platforms=[(120, P1, 200), (960, P1, 200)], hazards=[_vent(640)], props=[300],
              hints=['GUARDS BLOCK HEAD-ON.  K (HEAVY) BREAKS GUARD - OR DODGE BEHIND THEM']),
        Arena(1, ['s2 g2', 'd2 s1 r1'], platforms=[(200, P1, 240), (840, P1, 240), (520, P2, 240)], hazards=[_vent(640, 4, 2)],
              hints=['PARRY BULLETS TO REFLECT THEM AT ENEMIES']),
        Arena(2, boss='metronome', props=[160], hints=[]),
    ], 'metronome'),
    StageDef(2, 'SUBWAY STATIC', 'Off-beat and unblockable', 'subway', 's3', [
        Arena(0, ['g3 s1', 'y1 g2'], platforms=[(300, P1, 220), (760, P1, 220)], hazards=[_rail(640)],
              hints=['YELLOW DANCERS STRIKE ON THE OFF-BEAT']),
        Arena(1, ['c1 g2', 'd2 s2 r1'], platforms=[(150, P1, 200), (930, P1, 200)], hazards=[_rail(400, 4, 0), _rail(880, 4, 2)],
              hints=['RED RING = UNBLOCKABLE.  DODGE (L) OR JUMP']),
        Arena(2, ['y2 r2', 'c1 s2 d1'], platforms=[(240, P1, 200), (840, P1, 200), (540, P2, 200)], props=[640]),
    ]),
    StageDef(3, 'CLUB INFERNO', 'The floor is fire', 'club', 's4', [
        Arena(0, ['g3 r2', 's2 y1 c1'], platforms=[(200, P1, 220), (860, P1, 220)], hazards=[_vent(420), _vent(860, 4, 2)]),
        Arena(1, ['e1 g2', 'e1 s2 d2'], platforms=[(300, P1, 220), (780, P1, 220)], hazards=[_vent(640, 4, 1)], props=[100]),
        Arena(2, boss='dj', platforms=[(200, P1, 200), (880, P1, 200)], hazards=[]),
    ], 'dj'),
    StageDef(4, 'DATA CATHEDRAL', 'Lasers on the downbeat', 'cath', 's5', [
        Arena(0, ['y2 s2 c1', 'e1 r3'], platforms=[(200, P1, 220), (860, P1, 220)], hazards=[_laser(440, 4, 0), _laser(840, 4, 2)]),
        Arena(1, ['d2 c2 s2', 'e2 g3'], platforms=[(100, P1, 200), (980, P1, 200), (540, P2, 200)], hazards=[_laser(360, 4, 0), _laser(920, 4, 0)], props=[640]),
        Arena(2, ['e1 y2 c1 s2', 'e2 r3 d1'], platforms=[(300, P1, 220), (760, P1, 220)], hazards=[_laser(300, 2, 0), _laser(640, 2, 1), _laser(980, 2, 0)]),
    ]),
    StageDef(5, 'GRAND STAGE', 'The final movement', 'stage', 's6', [
        Arena(0, ['e1 y2 r2 d1', 'c2 s3 g3'], platforms=[(200, P1, 220), (860, P1, 220)], props=[640]),
        Arena(1, ['e2 y2 c1', 'e2 d2 s3 r2'], platforms=[(120, P1, 200), (960, P1, 200), (540, P2, 200)], hazards=[_laser(640, 4, 0)]),
        Arena(2, boss='conductor', platforms=[(140, P1, 220), (920, P1, 220)]),
    ], 'conductor'),
]

ABILITY_UNLOCK = {'launcher': 2, 'special': 3, 'dive': 4}
ABILITY_NAMES = {'launcher': 'LAUNCHER  (UP + J)', 'special': 'DROP THE BASS  (O / E when HEAT is full)', 'dive': 'DIVE KICK  (DOWN + K in air)'}

TH = {
    'alley': dict(sky=((26, 8, 56), (255, 84, 120)), acc=[(255, 60, 140), (60, 240, 255), (255, 220, 80)], far=(44, 20, 78), mid=(26, 12, 52), near=(12, 8, 26), floor=((30, 14, 52), (8, 6, 18)), grid=(255, 60, 140), dyn='sun'),
    'roof': dict(sky=((4, 6, 26), (34, 44, 120)), acc=[(90, 200, 255), (255, 80, 200), (255, 240, 120)], far=(20, 26, 70), mid=(14, 18, 48), near=(8, 10, 28), floor=((20, 26, 56), (6, 8, 20)), grid=(90, 200, 255), dyn='stars'),
    'subway': dict(sky=((8, 16, 22), (22, 44, 58)), acc=[(90, 255, 200), (255, 200, 80), (255, 80, 90)], far=(14, 30, 40), mid=(10, 22, 30), near=(6, 12, 18), floor=((20, 34, 44), (6, 10, 14)), grid=(90, 255, 200), dyn='tunnel'),
    'club': dict(sky=((20, 4, 30), (70, 8, 80)), acc=[(255, 60, 220), (60, 255, 240), (255, 230, 60)], far=(40, 10, 60), mid=(26, 6, 40), near=(12, 4, 20), floor=((40, 10, 60), (10, 4, 16)), grid=(255, 60, 220), dyn='beams'),
    'cath': dict(sky=((2, 18, 24), (6, 64, 76)), acc=[(60, 255, 220), (160, 120, 255), (255, 255, 255)], far=(6, 40, 50), mid=(4, 28, 36), near=(2, 14, 18), floor=((6, 40, 50), (2, 10, 14)), grid=(60, 255, 220), dyn='data'),
    'stage': dict(sky=((30, 4, 10), (100, 12, 34)), acc=[(255, 214, 90), (255, 60, 80), (255, 255, 255)], far=(60, 10, 24), mid=(44, 6, 16), near=(20, 3, 8), floor=((70, 14, 28), (16, 4, 8)), grid=(255, 214, 90), dyn='spot'),
}


class Background:
    def __init__(self, theme):
        self.name = theme
        self.th = th = TH[theme]
        rs = random.Random(theme)
        self.rs = rs
        # sky
        self.sky = pygame.Surface((W, H))
        for y in range(H):
            self.sky.fill(mix(th['sky'][0], th['sky'][1], (y / GROUND) ** 1.3), (0, y, W, 1))
        if th['dyn'] in ('stars', 'cath'):
            for _ in range(140):
                c = rs.randint(120, 255)
                self.sky.set_at((rs.randrange(W), rs.randrange(int(GROUND * .7))), (c, c, min(255, c + 30)))
        if th['dyn'] == 'sun':
            pygame.draw.circle(self.sky, (255, 190, 90), (W // 2, 330), 190)
            for i in range(9):
                y = 330 + i * 22
                pygame.draw.rect(self.sky, mix(th['sky'][0], th['sky'][1], y / GROUND), (W // 2 - 200, y, 400, 3 + i * 2))
        self.layers = []
        for par, col, hmin, hmax, wmin, wmax, tile in ((.22, th['far'], 140, 360, 60, 140, 1800), (.5, th['mid'], 80, 300, 80, 200, 2100)):
            s = pygame.Surface((tile, GROUND), pygame.SRCALPHA)
            neon = pygame.Surface((tile, GROUND))
            x = 0
            while x < tile:
                w = rs.randint(wmin, wmax)
                h = rs.randint(hmin, hmax)
                if theme in ('cath', 'stage') and par > .3:
                    h = rs.randint(260, 420)
                    w = rs.randint(40, 70)
                pygame.draw.rect(s, col + (255,), (x, GROUND - h, w, h))
                pygame.draw.rect(s, shade(col, 1.5) + (255,), (x, GROUND - h, w, 3))
                for wy in range(GROUND - h + 14, GROUND - 10, 22):
                    for wx in range(x + 8, x + w - 8, 16):
                        if rs.random() < .25:
                            pygame.draw.rect(s, shade(th['acc'][rs.randrange(3)], .5) + (255,), (wx, wy, 6, 9))
                if par > .3 and rs.random() < .5:
                    a = th['acc'][rs.randrange(3)]
                    sy = GROUND - h + rs.randint(20, max(21, h - 40))
                    sw = min(w - 12, 22)
                    pygame.draw.rect(neon, shade(a, .7), (x + w // 2 - sw // 2, sy, sw, 44), 0, 3)
                    pygame.draw.rect(neon, shade(a, .35), (x + w // 2 - sw // 2 - 3, sy - 3, sw + 6, 50), 2, 4)
                x += w + rs.randint(0, 24)
            dim = neon.copy()
            dim.fill((90, 90, 90), special_flags=pygame.BLEND_MULT)
            self.layers.append((par, s, neon, dim, tile))
        near = pygame.Surface((2400, GROUND), pygame.SRCALPHA)
        for x in range(120, 2400, rs.randint(360, 520)):
            pygame.draw.rect(near, th['near'] + (255,), (x, 80, 26, GROUND - 80))
            pygame.draw.rect(near, th['near'] + (255,), (x - 14, 70, 54, 14))
            pygame.draw.rect(near, shade(th['acc'][0], .55) + (255,), (x - 14, 66, 54, 4))
        self.near = near
        # floor
        self.floor = pygame.Surface((W, H - GROUND))
        for y in range(H - GROUND):
            self.floor.fill(mix(th['floor'][0], th['floor'][1], y / (H - GROUND)), (0, y, W, 1))
        self.hz = [0] * 3

    def draw(self, surf, fx, camx, t, phase, bf, prog, tint):
        th = self.th
        surf.blit(self.sky, (0, 0))
        pulse = (1 - phase) ** 2
        if th['dyn'] == 'sun':
            blit_glow(fx, W // 2, 330, 260 + 30 * pulse, shade((255, 90, 120), .25 + .15 * pulse))
        for par, s, neon, dim, tile in self.layers:
            ox = -int(camx * par) % tile
            for k in (ox - tile, ox):
                if k < W:
                    surf.blit(s, (k, 0))
                    fx.blit(neon if phase < .3 or int(bf) % 2 == 0 else dim, (k, 0), special_flags=pygame.BLEND_ADD) if par > .3 else None
        self.dyn(surf, fx, camx, t, phase, bf)
        ox = -int(camx * .8) % 2400
        for k in (ox - 2400, ox):
            if k < W:
                surf.blit(self.near, (k, 0))
        surf.blit(self.floor, (0, GROUND))
        # grid
        gc = th['grid']
        for i in range(1, 7):
            y = GROUND + int((H - GROUND) * (i / 7) ** 1.7)
            pygame.draw.line(fx, shade(gc, .12 + .1 * i / 7), (0, y), (W, y), 1)
        step = 150
        off = int(camx) % step
        for x in range(-step, W + step, step):
            xx = x - off
            pygame.draw.line(fx, shade(gc, .16), (xx * .6 + W * .2 + (xx - W / 2) * .0, GROUND), (xx * 1.5 - W * .25, H), 1)
        pygame.draw.line(fx, shade(gc, .55 + .45 * pulse), (0, GROUND), (W, GROUND), 2)
        if tint:
            fx.fill(shade(tint, .12 * prog), special_flags=pygame.BLEND_ADD)

    def dyn(self, surf, fx, camx, t, phase, bf):
        th = self.th
        d = th['dyn']
        a0, a1, a2 = th['acc']
        pulse = (1 - phase) ** 2
        if d == 'stars':
            for i in range(2):
                ang = math.sin(t * .4 + i * 2) * .5
                bx = W * (.25 + .5 * i)
                pygame.draw.polygon(fx, shade(a0, .10), [(bx, GROUND), (bx + math.sin(ang) * 900 - 40, 0), (bx + math.sin(ang) * 900 + 40, 0)])
        elif d == 'beams':
            for i in range(7):
                ang = math.sin(t * .8 + i) * .6 + (i - 3) * .18
                x0 = W * (i + .5) / 7
                c = (a0, a1, a2)[i % 3]
                x1 = x0 + math.sin(ang) * 800
                pygame.draw.polygon(fx, shade(c, .10 + .18 * pulse), [(x0 - 6, 0), (x0 + 6, 0), (x1 + 50, GROUND), (x1 - 50, GROUND)])
            for i in range(28):
                h = 20 + 60 * abs(math.sin(t * 3 + i * .7)) * (.5 + .5 * pulse)
                pygame.draw.rect(fx, shade(a1, .35), (i * 46 + 6, GROUND - 60 - h, 34, h))
        elif d == 'tunnel':
            ox = -int(camx * .6) % 260
            for x in range(-260, W + 260, 260):
                xx = x + ox
                on = (int(bf) + (x // 260)) % 4 == 0
                pygame.draw.rect(fx, shade(a1 if on else a0, .55 if on else .18), (xx, 40, 150, 10))
            tp = (t * 260) % 3200 - 800
            if int(t / 8) % 2 == 0:
                for i in range(8):
                    pygame.draw.rect(fx, shade(a1, .3), (tp + i * 170, 300, 130, 80), 0, 6)
        elif d == 'data':
            rs = random.Random(3)
            for i in range(46):
                x = (rs.randrange(W * 2) - camx * (.3 + rs.random() * .3)) % W
                y = (t * (100 + rs.random() * 260) + rs.random() * 900) % (GROUND + 100) - 100
                pygame.draw.line(fx, shade(a0, .15 + .35 * rs.random()), (x, y), (x, y + 60), 2)
            pygame.draw.circle(fx, shade(a1, .14 + .2 * pulse), (W // 2, 300), 210 + 14 * pulse, 4)
        elif d == 'spot':
            for i in range(5):
                x0 = W * (i + .5) / 5
                pygame.draw.polygon(fx, shade(a0, .07 + .1 * pulse), [(x0 - 8, 0), (x0 + 8, 0), (W / 2 + 90, GROUND), (W / 2 - 90, GROUND)])
            for i in range(0, W, 90):
                pygame.draw.rect(surf, shade((90, 10, 30), .6 + .4 * math.sin(i)), (i, 0, 40, 90))
        elif d == 'sun':
            for i in range(0, W, 210):
                pass


def make_arena_state(g, stage, arena):
    """Return platforms/hazards/props for an arena."""
    hz = []
    for kind, x, kw in arena.hazards:
        hz.append(Hazard(kind, x, **kw))
    return list(arena.platforms), hz, [Speaker(x) for x in arena.props]
